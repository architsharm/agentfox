"""Detector interface — the build-vs-reuse seam for Pillar 3.

Every runtime primitive, ours or wrapped OSS, implements :class:`Detector`. That is
what makes "wrap the primitive, own the interface" a tested
property rather than an aspiration: swapping Presidio for something else, or
dropping a project that gets archived, touches one adapter file.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from agentfox.core.vocab import SURFACES

log = logging.getLogger(__name__)


@dataclass(slots=True)
class Detection:
    """One located finding inside a piece of content.

    ``sample`` is redacted at construction: we store enough to explain
    the decision to a human and never enough to re-leak the value.
    """

    entity_type: str
    score: float
    start: int = 0
    end: int = 0
    sample: str = ""
    owasp_id: str | None = None
    atlas_id: str | None = None
    detail: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class DetectionContext:
    """Everything a detector may need beyond the raw string."""

    surface: str = "input"
    agent_slug: str | None = None
    trace_id: str | None = None
    tool_key: str | None = None
    tool_impact: str = "read"
    intent: str | None = None
    taint_source: str = "user"
    schema: dict[str, Any] | None = None
    prior_tools: list[str] = field(default_factory=list)
    extra: dict[str, Any] = field(default_factory=dict)
    #: The detectors this workspace runs (`detector_settings.enabled_for`); None
    #: means the deployment's `enabled_detectors`. Read by the pipeline's selection.
    enabled_detectors: frozenset[str] | None = None


@dataclass(slots=True)
class DetectorResult:
    detector_key: str
    version: str
    score: float = 0.0
    detections: list[Detection] = field(default_factory=list)
    status: str = "ok"  # ok | timeout | error | skipped_budget | unavailable
    duration_ms: float = 0.0
    raw: dict[str, Any] = field(default_factory=dict)

    @property
    def triggered(self) -> bool:
        return bool(self.detections)


@runtime_checkable
class Detector(Protocol):
    key: str
    version: str
    surfaces: tuple[str, ...]
    timeout_ms: int | None

    def available(self) -> bool:
        """False when an optional dependency or model weight is absent.

        Unavailable detectors degrade the pipeline rather than failing it — that is
        what makes the offline default work without pretending coverage exists.
        """
        ...

    def warm(self) -> None:
        """Pay any first-call cost now, off the request path. No-op for most
        detectors; see :meth:`BaseDetector.warm`."""
        ...

    def detect(self, content: str, context: DetectionContext) -> DetectorResult: ...


class BaseDetector:
    """Convenience base: subclasses implement :meth:`_detect`."""

    key: str = "base"
    version: str = "1"
    surfaces: tuple[str, ...] = SURFACES

    #: Set by detectors that normalise internally, so this class does not do it twice.
    handles_views: bool = False

    #: Published threat identifiers this detector looks for — OWASP LLM / Agentic
    #: and MITRE ATLAS. Declared rather than inferred from the `owasp_id` it happens
    #: to stamp on a detection, because the coverage question is "is anything
    #: watching for this", and a detector that has never fired still is.
    #:
    #: Empty is a real answer: several adapters wrap a third-party check whose threat
    #: mapping is somebody else's to assert. An undeclared detector is reported as
    #: contributing no coverage rather than being quietly credited with some.
    covers_threats: tuple[str, ...] = ()

    #: None means "use the pipeline's default (`detector_timeout_ms`)". A detector
    #: that genuinely needs longer — a real model forward pass, not a regex scan —
    #: declares that here rather than the pipeline granting everyone more rope,
    #: which would blunt the whole point of a per-detector budget. It is a floor:
    #: a larger configured `detector_timeout_ms` wins, and the run's budget caps
    #: both (`pipeline.detector_allowance_ms`).
    timeout_ms: int | None = None

    def available(self) -> bool:  # pragma: no cover - overridden by adapters
        return True

    def warm(self) -> None:
        """Pay any first-call cost (loading a model into memory, say) now, off the
        request path. No-op by default; a detector backed by something with real
        startup cost overrides this. `detector_timeout_ms` is short enough
        that a detector which only gets slow once, on its very first call, would
        otherwise silently degrade the first real request after every process
        start — see :meth:`warm_all`."""

    def detect(self, content: str, context: DetectionContext) -> DetectorResult:
        detections = self._detect(content or "", context)
        if not self.handles_views:
            detections.extend(self._detect_obfuscated(content or "", context, detections))
        score = max((d.score for d in detections), default=0.0)
        return DetectorResult(
            detector_key=self.key,
            version=self.version,
            score=score,
            detections=detections,
        )

    def _detect_obfuscated(
        self, content: str, context: DetectionContext, already: list[Detection]
    ) -> list[Detection]:
        """Re-run this detector over de-obfuscated readings of the same content.

        Every detector inherits evasion resistance here rather than implementing it,
        which matters because the blindness was not confined to injection: a
        base64-encoded API key or a zero-width-salted SSN passed the DLP detectors
        untouched, which is an exfiltration path with a governance layer watching.

        Ordinary content normalises to a single view, so this costs nothing on the
        common path. Spans are mapped back to the original text, because a detection
        reported at coordinates in a decoded string would point at characters the user
        never sent — and redaction would then corrupt the payload.
        """
        from agentfox.capabilities.detection.normalize import normalize

        normalised = normalize(content)
        if len(normalised.views) <= 1:
            return []

        seen = {(d.entity_type, d.start, d.end) for d in already}
        extra: list[Detection] = []
        # Every view whose text differs from what `_detect` already saw. Skipping the
        # primary view was wrong: it is the *cleaned* one, so zero-width-salted content
        # was normalised and then never re-scanned.
        for view in normalised.views:
            if view.text == content:
                continue
            for found in self._detect(view.text, context):
                start, end = view.origin(found.start, found.end)
                key = (found.entity_type, start, end)
                if key in seen:
                    continue
                seen.add(key)
                found.start, found.end = start, end
                found.sample = redact_sample(content[start:end])
                found.detail = {**found.detail, "view": view.kind, "obfuscated": True}
                # Content that had to be decoded before it matched is worse than
                # content that matched as written: nobody base64-encodes a credential
                # they intend to handle correctly.
                found.score = min(1.0, found.score + 0.1)
                extra.append(found)
        return extra

    def _detect(self, content: str, context: DetectionContext) -> list[Detection]:
        raise NotImplementedError


# --------------------------------------------------------------------------
# Redaction — applied at capture, never after the fact
# --------------------------------------------------------------------------

_WS = re.compile(r"\s+")


def redact_sample(value: str, keep: int = 4, max_len: int = 80) -> str:
    """Return a sample safe to persist.

    Keeps a short prefix so a human can recognise *what kind* of thing matched,
    masks the rest. An audit log that stores the SSN it detected is a new
    liability, not a control.
    """
    value = _WS.sub(" ", (value or "").strip())
    if not value:
        return ""
    if len(value) <= keep:
        return "*" * len(value)
    visible = value[:keep]
    masked = "*" * min(len(value) - keep, max_len - keep)
    return f"{visible}{masked}"


def snippet(value: str, start: int, end: int, window: int = 40) -> str:
    """A redacted window around a match, for explaining a block to a developer."""
    lo = max(0, start - window)
    hi = min(len(value), end + window)
    before = _WS.sub(" ", value[lo:start])
    after = _WS.sub(" ", value[end:hi])
    return f"…{before}[{redact_sample(value[start:end])}]{after}…"


# --------------------------------------------------------------------------
# Registry
# --------------------------------------------------------------------------

_REGISTRY: dict[str, Detector] = {}


def register_detector(detector: Detector) -> Detector:
    _REGISTRY[detector.key] = detector
    return detector


def _resolve(detector: Detector | None) -> Detector | None:
    """The detector, or its model-server stand-in when `model_server_url` routes it
    there (`detection.remote`). Every way of getting a detector goes through this, so
    the pipeline, `doctor` and the catalogue all see the same one."""
    from agentfox.capabilities.detection.remote import resolve

    return resolve(detector)


def get_detector(key: str) -> Detector | None:
    return _resolve(_REGISTRY.get(key))


def all_detectors() -> dict[str, Detector]:
    return {k: _resolve(d) for k, d in _REGISTRY.items()}


def available_detectors() -> dict[str, Detector]:
    return {k: d for k, d in all_detectors().items() if d.available()}


def _keys_to_warm() -> frozenset[str]:
    """What `warm_all()` warms: the detectors some workspace may run. If the database
    cannot say which ones workspaces switched on, the deployment's list. That is the
    normal case for a script that calls `warm_all()` with no gateway database."""
    from agentfox.core.config import get_settings

    try:
        from agentfox.capabilities.detection.detector_settings import enabled_anywhere
        from agentfox.core.db import session_scope

        with session_scope() as session:
            return enabled_anywhere(session)
    except Exception as exc:
        log.info("warming the deployment's detectors; workspace settings unread: %s", exc)
        return frozenset(get_settings().enabled_detectors)


def warm_all() -> None:
    """Call once at process startup (see `gateway.app.lifespan`). Only detectors
    with real first-call cost do anything here; everything else is a no-op.

    Only detectors something can call are warmed: the deployment's list, plus any a
    workspace switched on. Weights being present is not enough. The gateway image
    carries Granite Guardian's, and loading those at every boot cost about 10GB of
    memory for a detector nobody had enabled. A workspace that turns one on later
    pays its load on that detector's first call, which the pipeline already bounds.

    A detector that fails to warm is logged and left cold rather than raised: this
    runs inside the gateway's startup, and one broken model (an incomplete weights
    download, an architecture the installed transformers rejects) used to take the
    whole process down with it. The same failure on a request is recorded as that
    detector's `error`, which is where it belongs."""
    warn_unrunnable(enabled_only=True)
    from agentfox.capabilities.detection import warmup

    warmup.startup_warned = True  # a later in-process warm-up need not say it again
    for key in sorted(_keys_to_warm()):
        detector = get_detector(key)
        if detector is None:
            continue
        try:
            if detector.available():
                detector.warm()
                from agentfox.capabilities.detection.warmup import mark_warmed

                mark_warmed(key)
        except Exception:
            log.exception("detector %s failed to warm; it stays cold", key)


def _already_warned(key: str, reason: str) -> bool:
    """Whether this installation already said that ``key`` cannot run, for the same
    reason, and records that it now has. Kept in the run directory (`run_dir`), so
    a changed reason (a different missing package) is said again."""
    import json

    from agentfox.core.config import run_dir

    path = run_dir() / "unrunnable-detectors.json"
    try:
        said = json.loads(path.read_text())
    except (OSError, ValueError):
        said = {}
    if not isinstance(said, dict):
        said = {}
    if said.get(key) == reason:
        return True
    said[key] = reason
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(said, sort_keys=True))
    except OSError:
        pass  # unwritable state: warn every time rather than never
    return False


def warn_unrunnable(*, enabled_only: bool = True, once: bool = False) -> list[str]:
    """Log each enabled detector that cannot run here, with the fix. Returns their keys.

    The pipeline skips such a detector without a word, which is right per request
    and wrong at startup: `injection.classifier` is on by default, and a deployment
    without its model would otherwise run regex only while believing otherwise.

    ``once``: for an application governed in-process (`agentfox.auto()`, the SDK),
    where "startup" is every run of somebody's script. The warning is logged the first
    time per installation and reason, then at debug level; `agentfox doctor` keeps
    listing it. A server (the gateway, the hook daemon) warns on every start: its log
    is where an operator looks.
    """
    from agentfox.capabilities.detection.models import models_for
    from agentfox.core.config import get_settings

    enabled = set(get_settings().enabled_detectors)
    missing = []
    for key, detector in all_detectors().items():
        # Model-backed only: a detector like `custom.lists` is unavailable simply
        # because nothing is configured for it yet, which is not worth a warning.
        if (enabled_only and key not in enabled) or not models_for(detector):
            continue
        try:
            if detector.available():
                continue
            reason = getattr(detector, "unavailable_reason", None)
            reason = reason() if callable(reason) else reason
        except Exception as exc:  # noqa: BLE001 - a startup warning must never raise
            reason = str(exc)
        missing.append(key)
        reason = str(reason or "its dependency is not installed")
        if once and _already_warned(key, reason):
            log.debug("agentfox: detector %s cannot run here (%s); skipped.", key, reason)
            continue
        # What running without it means, when the detector says (the classifier: prompt
        # attacks are then found by the pattern heuristic alone, and blocked on it).
        without = getattr(detector, "without_it", "") or ""
        log.warning(
            "agentfox: detector %s is enabled but cannot run here (%s); it is skipped%s.%s",
            key,
            reason,
            f": {without}" if without else "",
            " Said once; `agentfox doctor` lists it." if once else "",
        )
    return missing
