"""Multi-agent structure, read statically: which agents a repository defines, which
tools each one is handed, and which agent hands work to which.

The repo scanner (:mod:`agentfox.capabilities.discovery.repo`) answers "where does this
code talk to a model". For a multi-agent system that answer is not enough to govern
it: a triage agent that can hand off to a refunds agent is two things with two tool
sets, and a guardrail meant for "the refunds agent and everything it delegates to" has
nothing to attach to until the parts have names. Before this, the only source of that
structure was runtime traffic (``derive_lineage`` turning ``subagent`` spans into
``delegates_to`` edges), so a freshly scanned repository came out as one blob per
directory and the hierarchy appeared only after the system had already run ungoverned.

Same rules as the rest of discovery: **no import, no execution**. Python is read with
``ast``; TypeScript and JavaScript with a small brace-aware reader over the source,
for the one shape that is unambiguous there (OpenAI Agents SDK's ``new Agent({...})``).
A constructor counts only when the file imported it from the framework it belongs to,
because ``Agent`` and ``Crew`` are names any codebase may define for itself.

What is recognised, per framework:

* **OpenAI Agents SDK** — ``Agent(name=..., tools=[...], handoffs=[...])``;
  ``handoff(agent)`` inside ``handoffs``; ``other.as_tool(...)`` inside ``tools``.
* **LangGraph** — ``create_react_agent`` / ``create_agent``; ``create_supervisor``
  (supervisor delegates to each worker); ``create_swarm`` (members, plus
  ``create_handoff_tool(agent_name=...)`` handoffs); ``StateGraph`` nodes, where a node
  is an agent when it *is* one (a react agent, a compiled subgraph), calls one, or binds
  tools to a model, and a node that routes to agent nodes (conditional edges or
  ``Command(goto=...)``) is their supervisor.
* **CrewAI** — ``Agent(role=..., tools=[...])``, ``Crew(agents=[...])`` (members, or
  delegation under a hierarchical process or a ``manager_agent``), ``allow_delegation``,
  and the ``@CrewBase`` class layout (``@agent`` methods, ``agents=self.agents``).
* **AutoGen** — AgentChat's ``AssistantAgent`` and friends with ``tools`` and Swarm
  ``handoffs``; ``RoundRobinGroupChat`` / ``SelectorGroupChat`` / ``Swarm`` /
  ``MagenticOneGroupChat`` teams; AG2's ``GroupChat`` and the ``GroupChatManager``
  that runs it.
* **Google ADK** — ``Agent`` / ``LlmAgent`` ``sub_agents`` and ``AgentTool``, and the
  ``Sequential``/``Parallel``/``Loop`` workflow agents.
* **Voice agents** — LiveKit Agents' ``class Assistant(Agent)`` (its ``@function_tool``
  methods and ``super().__init__(tools=[...])``) or ``Agent(instructions=..., tools=...)``;
  a Pipecat ``Pipeline``, whose tools are what its LLM service registers
  (``register_function("name", ...)``); OpenAI's ``RealtimeAgent``.
* **Frameworks known by constructor** (:data:`_KNOWN_AGENTS`) — Pydantic AI, Strands,
  Agno, smolagents, LlamaIndex, Semantic Kernel, Microsoft Agent Framework, Haystack,
  DSPy and the Claude Agent SDK's ``ClaudeAgentOptions``: read with the generic keyword
  rules below, reported at high confidence under their own name.
* **LangChain (pre-1.0)** — ``create_tool_calling_agent(llm, tools, prompt)`` and the
  other ``create_*_agent`` constructors, ``initialize_agent(tools, llm)``, and the
  ``AgentExecutor(agent=..., tools=...)`` that runs one: executor and agent are one.
* **A hand-written loop** — ``client.chat.completions.create(tools=...)``,
  ``responses.create``, Anthropic's ``messages.create`` and LiteLLM's ``completion``,
  its tools read from the JSON schemas. Counted only when the repository has no
  framework agent: beside one it is a script, a demo or a helper.

Across all of them:

* A typed constructor (``Agent[Context](...)``) is the constructor.
* Lists changed after construction count: ``a.handoffs = [...]``,
  ``a.handoffs.append(x)`` / ``.extend([...])`` / ``.insert(i, x)`` / ``+=``, the same
  for ``tools``, in the agent's file or a wiring module. They add to the agent's.
* A tool list need not be inline: a name bound to a list, a helper of the file whose
  ``return`` is one (``tools=build_tools()``), ``tools or ALL_TOOLS``, ``A if c else
  B``, and a list or helper exactly one other file defines. A list that cannot be read
  adds nothing; it is never reported as a tool named after the helper.
* Tools made by a call (``function_tool(fn)``, ``function_tool(name_override="x")(fn)``,
  imported ``tool(fn)``, ``StructuredTool.from_function(fn)``) are named as the code
  names them, and carry their function's docstring and argument names.
* An agent's ``name=`` may be a module constant; its model (:attr:`AgentSpec.model`) a
  literal, a constant, an f-string of constants, an ``os.getenv`` default, or a
  chat-model object (``ChatOpenAI(model=...)``, ``init_chat_model("openai:gpt-4o")``).
  Anything only running the code would tell, such as a ``build_model()`` helper, is None.
* Test, mock and fixture files (:func:`is_test_path`) are not read for agents or tools.

A variable is resolved to the agent it holds inside its own file first, then by a
repository-wide lookup of that name when exactly one file defines it, which covers the
common ``from .billing import billing_agent`` layout without following imports.
Anything that cannot be resolved is left out rather than guessed: a wrong edge in a
delegation graph widens what an "apply to sub-agents" policy reaches.
"""

from __future__ import annotations

import ast
import re
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from agentfox.core import naming

#: How a parent hands work to a child, strongest claim first: when the same pair is
#: related twice (a crew member that is also the manager's delegate), the first wins.
#:
#: * ``handoff`` — the parent passes the conversation over (OpenAI handoffs, Swarm).
#: * ``as_tool`` — the parent calls the child like a tool and keeps the conversation.
#: * ``delegates`` — the parent decides which child works next (a supervisor, a
#:   hierarchical crew's manager, ADK ``sub_agents``).
#: * ``member`` — the child is one of a team the parent runs (a crew, a group chat, a
#:   graph's agent nodes).
RELATIONS = ("handoff", "as_tool", "delegates", "member")

#: What this module recognises, per framework, in a line each: what `agentfox init`
#: prints under "Missing something?". Keep it in step with the docstring above.
RECOGNISED = (
    ("OpenAI Agents SDK", "Agent(name=..., tools=[...], handoffs=[...]), agent.as_tool(...)"),
    ("LangGraph", "create_react_agent / create_agent, create_supervisor, create_swarm, StateGraph"),
    ("LangChain", "@tool, create_tool_calling_agent / initialize_agent, AgentExecutor"),
    ("CrewAI", "Agent(role=..., tools=[...]), Crew(agents=[...]), @CrewBase"),
    ("AutoGen / AG2", "AssistantAgent(tools=...), group chats, Swarm handoffs"),
    ("Google ADK", "Agent / LlmAgent(sub_agents=[...]), AgentTool, workflow agents"),
    (
        "Voice agents in code",
        "LiveKit class X(Agent) with @function_tool, Pipecat Pipeline + register_function, "
        "OpenAI RealtimeAgent",
    ),
    (
        "Pydantic AI, Strands, Agno, smolagents, LlamaIndex, Semantic Kernel, Microsoft "
        "Agent Framework, Haystack, DSPy, Claude Agent SDK",
        "their agent constructors given tools=[...] (ClaudeAgentOptions(allowed_tools=...))",
    ),
    (
        "Hand-written loops",
        "chat.completions.create / responses.create / messages.create / litellm "
        "completion(tools=[...]) with JSON tool schemas",
    ),
    (
        "TypeScript / JavaScript",
        "new XAgent({...}) (Mastra, VoltAgent, Strands, LiveKit voice.Agent), create…Agent({...}), "
        "streamText/generateText with tools, responses/messages.create with tools, Claude "
        "Agent SDK query()",
    ),
    (
        "Any other framework",
        "an imported constructor given tools and instructions, a model or a name; a class "
        "extending *Agent or *Role; a LangGraph graph whose nodes call a model; code that "
        "only calls a model is reported at low confidence",
    ),
)


@dataclass
class AgentSpec:
    """One agent (or the crew, team or graph that runs several) found in code."""

    #: Unique within one scan and stable across scans while the name is unchanged:
    #: the proposed agent's slug is built from it.
    key: str
    name: str
    framework: str
    #: agent | supervisor | crew | team | graph
    kind: str
    file: str
    line: int
    tools: list[str] = field(default_factory=list)
    #: The model id the code gives it (``model="gpt-4o"``, a module constant, an
    #: ``os.getenv`` default, a chat-model object's ``model=``), or None when the code
    #: does not say it in a way that can be read without running it. Never guessed.
    model: str | None = None
    #: True when the constructor gives no model at all and the framework then picks
    #: its own (an Agents SDK `Agent` without `model=`, a CrewAI `Agent` without
    #: `llm=`). Different from :attr:`model` being None because the code chose one in
    #: a way a static read cannot follow (`model=build_model(settings)`): there the
    #: model is unknown; here it is the framework's default, whichever that is.
    default_model: bool = False
    #: Where a local runner finds the live object: the importable module, the name in
    #: it, and how to use that name — ``object`` (the agent itself), ``factory`` (call
    #: it to get the agent) or ``function`` (it runs a function-calling loop). A
    #: ``Class.method`` name is a method of a ``@CrewBase`` class: the factory builds
    #: the class with no arguments and calls the method.
    module: str | None = None
    attr: str | None = None
    attr_kind: str | None = None
    #: What each of :attr:`tools` says about itself, where the code says it: the
    #: description (a docstring or ``description=``) and argument names.
    tool_details: list[dict[str, Any]] = field(default_factory=list)
    #: False when the code gives the agent no name of its own (``name=``, ``role=``)
    #: and :attr:`name` is only the variable or function it was found under.
    named: bool = True
    #: The agent's instructions or system prompt, when the code says them as a string
    #: that can be read without running anything. Local only: never serialised, never
    #: part of a submission; a caller may derive a label from it (who the agent serves).
    instructions: str | None = field(default=None, repr=False)
    #: How sure the scan is that this is an agent: ``high`` for a framework constructor
    #: it knows, ``medium`` for an agent-shaped call or a hand-written loop it does
    #: not, ``low`` for a class that only looks like one or an app that only calls a
    #: model. ``evidence`` is the rule that matched.
    confidence: str = "high"
    evidence: str = ""
    #: The variable the code holds the agent in, wherever it is assigned (a function's
    #: local included): how the repo scan recognises `agent.run_sync(...)` as running
    #: it. Local only, never serialised.
    var: str | None = field(default=None, repr=False, compare=False)

    @property
    def top_dir(self) -> str:
        parts = Path(self.file).parts
        return parts[0] if len(parts) > 1 else "root"

    def to_json(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "name": self.name,
            "framework": self.framework,
            "kind": self.kind,
            "file": self.file,
            "line": self.line,
            "tools": self.tools,
            "model": self.model,
            "default_model": self.default_model,
            "ref": (
                {"module": self.module, "attr": self.attr, "kind": self.attr_kind}
                if self.module and self.attr
                else None
            ),
            "tool_details": self.tool_details,
            "confidence": self.confidence,
            "evidence": self.evidence,
        }


@dataclass
class AgentEdge:
    """``parent`` hands work to ``child`` (both :attr:`AgentSpec.key`)."""

    parent: str
    child: str
    relation: str
    #: For ``as_tool``: the name of the tool the parent's model calls to run the child
    #: (``tool_name=``, else the framework's default from the child's name), or None
    #: when the code does not say it in a way that can be read without running it.
    tool: str | None = None

    def to_json(self) -> dict[str, str]:
        out = {"parent": self.parent, "child": self.child, "relation": self.relation}
        if self.tool:
            out["tool"] = self.tool
        return out


def _as_tool_name(child: _Raw) -> str | None:
    """The tool name a framework gives an agent used as a tool when the code gives
    none: the Agents SDK's ``as_tool()`` snake-cases the agent's name
    (``transform_string_function_style``); AutoGen's and Google ADK's ``AgentTool``
    use it as is. Python only: elsewhere the call that names it is not read."""
    if not child.name or not child.file.endswith(".py"):
        return None
    if child.framework == "OpenAI Agents SDK":
        return re.sub(r"[^a-zA-Z0-9_]", "_", child.name.replace(" ", "_")).lower()
    if child.framework in ("AutoGen", "Google ADK"):
        return child.name
    return None


# ---------------------------------------------------------------------------
# Raw extraction — one file at a time, references left unresolved
# ---------------------------------------------------------------------------

#: A reference to an agent, resolved once every file has been read:
#: ("idx", n) a raw definition; ("var", name) a variable or factory function;
#: ("label", text) an agent's or graph node's own name; ("class", name) every
#: ``@agent`` method of a CrewBase class.
Ref = tuple[str, Any]


@dataclass
class _Raw:
    idx: int
    framework: str
    kind: str
    file: str
    line: int
    name: str | None = None
    var: str | None = None
    cls: str | None = None
    tools: list[tuple[str, str]] = field(default_factory=list)  # ("name"|"var", text)
    children: list[tuple[Ref, str]] = field(default_factory=list)
    #: CrewAI: this agent may ask the crew's other members for help.
    allow_delegation: bool = False
    #: AG2: the GroupChat a GroupChatManager runs; its members become the manager's.
    absorbs: Ref | None = None
    #: CrewAI: a crew's ``manager_agent``, who delegates to the crew's ``members``.
    manager: Ref | None = None
    members: list[Ref] = field(default_factory=list)
    #: Set when a raw turns out to be nothing worth reporting (an AG2 GroupChat folded
    #: into its manager, a graph with no agent nodes).
    dropped: bool = False
    #: The model id, when read in this file; else a name imported into this file that
    #: may be a module constant elsewhere (resolved by the repository-wide lookup).
    model: str | None = None
    model_var: str | None = None
    #: See AgentSpec.default_model.
    default_model: bool = False
    #: The module-level name a runner reaches this agent by, and how (see AgentSpec).
    attr: str | None = None
    attr_kind: str | None = None
    #: The code names the agent itself (see AgentSpec.named), and what it instructs it.
    named: bool = False
    instructions: str | None = None
    #: ``triage.handoffs.append(x)`` / ``a.tools += [...]``: this raw is no agent but
    #: more of the agent ``extends`` names. Its children and tools are that agent's.
    extends: Ref | None = None
    #: LangChain ``AgentExecutor(agent=x)``: the executor and ``x`` are one agent.
    wraps: Ref | None = None
    #: A bare provider-SDK function-calling loop, reported only when the repository
    #: has no framework agent: beside one it is a script, a demo or a helper.
    loop: bool = False
    #: See AgentSpec.confidence / evidence.
    confidence: str = "high"
    evidence: str = ""
    #: An ``as_tool`` child -> the tool name the code gives it (``tool_name=``).
    child_tools: dict[Ref, str] = field(default_factory=dict)
    #: The import-resolved constructor or base class (``agents.agent.Agent`` for
    #: ``from agents.agent import Agent``): when a module of the repository's own
    #: defines it, the framework label is not the package's.
    origin: str | None = None


class _Deferred(ast.expr):
    """A list this file does not show: one a call builds (``tools=build_tools()``
    with ``build_tools`` imported; ``kind="call"``) or an imported name on one side of
    ``tools or ALL_TOOLS`` (``kind="list"``). Looked up by name across the repository,
    and never itself taken for a tool."""

    _fields = ()

    def __init__(self, name: str, kind: str = "call") -> None:
        super().__init__()
        self.name = name
        self.kind = kind


@dataclass
class _Node:
    name: str
    #: What the node runs, as an agent reference when it can be one.
    ref: Ref | None
    func: ast.FunctionDef | ast.AsyncFunctionDef | None
    #: Names the node function reads: an agent among them is the agent it runs.
    loads: set[str] = field(default_factory=set)
    #: Tools the node function binds to its model, or None when it binds none.
    bound_tools: list[tuple[str, str]] | None = None


@dataclass
class _Graph:
    raw: int
    file: str
    nodes: dict[str, _Node] = field(default_factory=dict)
    #: (source, target, how) with how in "edge" | "route"
    routes: list[tuple[str, str, str]] = field(default_factory=list)
    #: Nodes whose function calls a model (`.invoke`, `.ainvoke`, a chat model): a
    #: graph of such nodes with no tool-bound model is a workflow agent, not nothing.
    llm_nodes: int = 0


@dataclass
class _FileResult:
    file: str
    raws: list[_Raw] = field(default_factory=list)
    graphs: list[_Graph] = field(default_factory=list)
    #: variable -> raw index, for this file
    vars: dict[str, int] = field(default_factory=dict)
    #: function or variable name -> tool name, for this file
    tool_defs: dict[str, str] = field(default_factory=dict)
    #: module-level variable names this file defines (for cross-file lookup)
    exported: set[str] = field(default_factory=set)
    #: `triage = build_triage()` — a variable holding what a factory returns
    aliases: dict[str, str] = field(default_factory=dict)
    #: The importable module this file is (Python only).
    module: str | None = None
    #: tool name -> (description, argument names), for tools this file defines
    tool_info: dict[str, tuple[str, list[str]]] = field(default_factory=dict)
    #: module-level list variable -> the tool references it holds
    tool_lists: dict[str, list[tuple[str, str]]] = field(default_factory=dict)
    #: ``to_x = create_handoff_tool(agent_name="x")`` -> "x": a hand-off, not a tool
    handoff_vars: dict[str, str] = field(default_factory=dict)
    #: ``x_tool = AgentTool(x)`` / ``x_tool = x.as_tool(...)`` -> that call: an agent
    #: used as a tool, passed to ``tools=[...]`` by name
    agent_tool_vars: dict[str, ast.Call] = field(default_factory=dict)
    #: module-level function -> the tool references in the list it returns
    tool_helpers: dict[str, list[tuple[str, str]]] = field(default_factory=dict)
    #: module-level string constant -> its value (``MODEL = "gpt-4o"``)
    consts: dict[str, str] = field(default_factory=dict)
    #: module-level function -> (description, argument names), and tool name -> the
    #: function in another module it wraps: what `function_tool(mod.fn)` says.
    func_info: dict[str, tuple[str, list[str]]] = field(default_factory=dict)
    tool_fn: dict[str, str] = field(default_factory=dict)
    #: Every module-level function this file defines: a bare name in a tools list
    #: is a tool only when some file defines a function by it (else it is a list
    #: or a parameter, and naming a tool after it would invent one).
    functions: set[str] = field(default_factory=set)
    #: Every module-level class this file defines: a constructor imported from a
    #: module of the repository's own is its class, not a framework's.
    classes: set[str] = field(default_factory=set)
    #: Local name -> (module, name) it was imported as (``from .tools import TOOLS``,
    #: relative imports made absolute), and local name -> (module, "") for
    #: ``import a.b as c``: how a name two modules define is followed to the one this
    #: file means, rather than dropped as ambiguous.
    imports: dict[str, tuple[str, str]] = field(default_factory=dict)
    #: Attribute -> the imported module name it was read off (``support_tools.TOOLS``).
    #: Empty when this file reads it off two different modules.
    attr_modules: dict[str, str] = field(default_factory=dict)


#: Constructor -> (framework, role). Matched on the import-resolved dotted path's root
#: package and final name, so `from crewai import Agent` and `crewai.Agent` both match
#: and a local `Agent` class does not.
_AUTOGEN_CHAT_AGENTS = {
    "AssistantAgent",
    "UserProxyAgent",
    "CodeExecutorAgent",
    "SocietyOfMindAgent",
}
_AG2_AGENTS = {"AssistantAgent", "UserProxyAgent", "ConversableAgent"}
_LC_AGENT_FACTORIES = {
    "create_tool_calling_agent",
    "create_openai_tools_agent",
    "create_openai_functions_agent",
    "create_react_agent",
    "create_structured_chat_agent",
    "create_json_chat_agent",
    "create_xml_agent",
}

#: Where a role's tools and model sit when passed positionally.
_TOOLS_ARG = {"react_agent": 1, "lc_agent": 1, "lc_init": 0}
_MODEL_ARG = {"react_agent": 0, "lc_agent": 0, "lc_init": 1}
#: The keyword each role takes its model by.
_MODEL_KW = {
    "openai_agent": ("model",),
    "adk_agent": ("model",),
    "react_agent": ("model",),
    "supervisor": ("model",),
    "lc_agent": ("llm", "model"),
    "lc_init": ("llm", "model"),
    "crew_agent": ("llm",),
    "autogen_agent": ("model_client", "llm_config"),
    "loop": ("model",),
    "known_agent": ("model", "llm", "model_client", "chat_client", "service", "chat_generator"),
    "known_team": ("model", "llm"),
}
#: Roles whose framework runs a default model when the constructor names none: the
#: Agents SDK (`OPENAI_DEFAULT_MODEL`, else its built-in default) and CrewAI
#: (`OPENAI_MODEL_NAME`, else its built-in default).
_DEFAULT_MODEL_ROLES = {"openai_agent", "crew_agent"}
#: Where each framework takes the agent's instructions (its system prompt).
_INSTRUCTION_KW = (
    "instructions",
    "system_prompt",
    "prompt",
    "system_message",
    "state_modifier",
    "backstory",
    "goal",
)
_TOOL_ROLES = (
    "openai_agent",
    "crew_agent",
    "autogen_agent",
    "adk_agent",
    "react_agent",
    "lc_agent",
    "lc_init",
    "lc_executor",
)

#: An agent-shaped call to a framework the scan has no constructor for: an imported
#: callable given tools (under any of these names) and an instruction, a model or a
#: name. Enough to say "an agent is built here" without knowing the framework.
_GENERIC_TOOLS_KW = (
    "tools",
    "functions",
    "toolsets",
    "toolkits",
    "allowed_tools",
    "mcp_servers",
    "server_names",
    "tool_list",
)
_GENERIC_NAME_KW = ("name", "agent_name", "role")
_GENERIC_MODEL_KW = ("model", "llm", "model_client", "llm_config", "model_name", "client")
_GENERIC_INSTRUCTION_KW = (*_INSTRUCTION_KW, "instruction", "description", "persona", "role")
#: Where such an agent names the agents it works with, and how.
_GENERIC_CHILDREN_KW = {
    "handoffs": "handoff",
    "can_handoff_to": "handoff",
    "sub_agents": "delegates",
    "managed_agents": "delegates",
    "agents": "member",
    "participants": "member",
    "members": "member",
}
#: Calls that take tools but build no agent: a tool node, a toolkit, an MCP server.
#: A task, pack, plugin, chain or pipeline takes tools too and is not the agent.
_NOT_AN_AGENT = re.compile(
    r"(?i)(?:tool(?:node|kit|set|box|pack)?|server|executor|registry|bind_tools|task|pack"
    r"|plugin|chain|pipeline)$"
)
#: A callee named like an agent: a class ending in Agent (`ChatAgent`, `FnCallAgent`),
#: or a factory that makes one (`create_deep_agent`, `define_agent`, `build_agent`).
_AGENT_CALLEE = re.compile(r"(?:Agent$|^(?:create|make|build|define|new|get)_?\w*_?agent$)", re.I)
#: A class that only carries data about an agent: its config, a message, an event.
_AGENT_DATA = re.compile(
    r"(?:Config|Configuration|Message|Event|Output|Result|Request|Response|Schema|Settings"
    r"|Params|Parameters|State|Card|Info|Metadata|Context|Error|Exception|Type|Status)$"
)
#: Base classes that make a class an agent (`class Planner(BaseAgent)`).
_AGENT_BASE = re.compile(r"(?:Agent|Role)$")
#: A method call that hands a class's tools to its model.
_CLASS_TOOL_CALLS = ("set_actions", "add_tools", "register_tools", "set_tools")

#: A provider SDK's own function-calling entry points (`client.<path>(tools=...)`),
#: by the package the file must import for the call to count.
_LOOP_CALLS = {
    "chat.completions.create": ("openai", "OpenAI SDK"),
    "responses.create": ("openai", "OpenAI SDK"),
    "messages.create": ("anthropic", "Anthropic SDK"),
    "completion": ("litellm", "LiteLLM"),
    "acompletion": ("litellm", "LiteLLM"),
}

#: File stems that say nothing about which agent a loop is; its directory names it.
_GENERIC_STEMS = {
    "main",
    "app",
    "agent",
    "agents",
    "__init__",
    "server",
    "index",
    "run",
    "bot",
    "chat",
    "loop",
    "client",
    "api",
}

#: Variable names that say nothing about which agent they hold.
#: Attributes a class keeps its built agent in, which say nothing about the agent.
_HOLDER_VARS = {"graph", "agent", "app", "executor", "agent_executor", "runnable", "chain"}

_GENERIC_VARS = {"agent", "agents", "pipeline", "options", "opts", "config", "team", "workflow"}

#: Directories and file names that hold tests, mocks and fixtures. Code there builds
#: stand-in agents and tools; it is left out of agent and tool attribution (but not of
#: the repo scan's own findings, which still read it).
_TEST_DIRS = {"tests", "test", "testing", "mocks", "fixtures", "__tests__", "__mocks__"}
_TEST_FILE = re.compile(
    r"^(?:test_.*\.py|.*_test\.py|conftest\.py|.*\.(?:test|spec)\.(?:[jt]sx?|mjs))$"
)


def is_test_path(rel: str) -> bool:
    """True for a file under a tests/mocks/fixtures directory, or a test file."""
    parts = Path(rel).parts
    return any(p in _TEST_DIRS for p in parts[:-1]) or bool(parts and _TEST_FILE.match(parts[-1]))


def _module_name(rel: str) -> str | None:
    path = Path(rel)
    if path.suffix != ".py":
        return None
    parts = list(path.with_suffix("").parts)
    if parts and parts[0] == "src":
        parts = parts[1:]
    if parts and parts[-1] == "__init__":
        parts = parts[:-1]
    if not parts or not all(p.isidentifier() for p in parts):
        return None
    return ".".join(parts)


def _dotted(rel: str) -> list[str]:
    """A file's path as module parts, ``__init__`` dropped: matched against an
    import by its tail, so ``src/app/tools.py`` and ``backend/app/tools.py`` are both
    ``app.tools``."""
    parts = list(Path(rel).with_suffix("").parts)
    return parts[:-1] if parts and parts[-1] == "__init__" else parts


def _import_base(rel: str, module: str | None, level: int) -> str | None:
    """The absolute module ``from <level dots><module> import ...`` reads from."""
    if not level:
        return module
    package = _dotted(rel) if Path(rel).stem == "__init__" else _dotted(rel)[:-1]
    if level - 1 > len(package):
        return None
    package = package[: len(package) - (level - 1)]
    return ".".join([*package, *([module] if module else [])]) or None


def _record_imports(tree: ast.Module, rel: str, out: _FileResult) -> None:
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.asname:
                    out.imports[alias.asname] = (alias.name, "")
                else:
                    first = alias.name.split(".")[0]
                    out.imports.setdefault(first, (first, ""))
        elif isinstance(node, ast.ImportFrom):
            base = _import_base(rel, node.module, node.level)
            for alias in node.names:
                if base and alias.name != "*":
                    out.imports[alias.asname or alias.name] = (base, alias.name)


#: Agent constructors of frameworks read with the generic keyword rules (tools,
#: children, name, model and instructions under any of the usual names) but known by
#: name, so an agent built with one is reported at high confidence under its own
#: label. Keyed by the import-resolved package prefix, then the constructor's name.
_KNOWN_AGENTS: dict[str, tuple[str, dict[str, str]]] = {
    "pydantic_ai": ("Pydantic AI", {"Agent": "agent"}),
    "strands": ("Strands Agents", {"Agent": "agent"}),
    "agno": ("Agno", {"Agent": "agent", "Team": "team"}),
    "smolagents": (
        "smolagents",
        {"CodeAgent": "agent", "ToolCallingAgent": "agent", "MultiStepAgent": "agent"},
    ),
    "llama_index": (
        "LlamaIndex",
        {
            "FunctionAgent": "agent",
            "ReActAgent": "agent",
            "CodeActAgent": "agent",
            "AgentWorkflow": "team",
        },
    ),
    "semantic_kernel": (
        "Semantic Kernel",
        {"ChatCompletionAgent": "agent", "AzureAIAgent": "agent", "OpenAIAssistantAgent": "agent"},
    ),
    "agent_framework": ("Microsoft Agent Framework", {"ChatAgent": "agent", "Agent": "agent"}),
    "haystack": ("Haystack", {"Agent": "agent"}),
    "dspy": ("DSPy", {"ReAct": "agent", "CodeAct": "agent"}),
    "claude_agent_sdk": ("Claude Agent SDK", {"ClaudeAgentOptions": "agent"}),
    # A voice agent built in code: `Agent(instructions=..., tools=[...])`, or the
    # class form `class Assistant(Agent)` (see `_Extractor.classes`).
    "livekit.agents": ("LiveKit Agents", {"Agent": "agent"}),
}


def _known_agent(qual: str) -> tuple[str, str] | None:
    last = qual.rsplit(".", 1)[-1]
    for prefix, (label, names) in _KNOWN_AGENTS.items():
        if (qual == prefix or qual.startswith(f"{prefix}.")) and last in names:
            return label, names[last]
    return None


def _constructor(qual: str) -> tuple[str, str] | None:
    root = qual.split(".")[0]
    last = qual.rsplit(".", 1)[-1]
    if root == "agents" and last == "Agent":
        return "OpenAI Agents SDK", "openai_agent"
    if root == "agents" and last == "RealtimeAgent":
        # Same constructor shape, run over a speech-to-speech session.
        return "OpenAI Realtime", "openai_agent"
    if root == "pipecat" and last == "Pipeline":
        # Pipecat has no agent object: the pipeline (transport, STT, LLM, TTS) is the
        # agent, and its tools are what the LLM service registers.
        return "Pipecat", "voice_pipeline"
    if (known := _known_agent(qual)) is not None:
        return known[0], f"known_{known[1]}"
    if root == "crewai":
        if last == "Agent":
            return "CrewAI", "crew_agent"
        if last == "Crew":
            return "CrewAI", "crew"
    if root == "autogen_agentchat":
        if last in _AUTOGEN_CHAT_AGENTS:
            return "AutoGen", "autogen_agent"
        if last in ("RoundRobinGroupChat", "Swarm"):
            return "AutoGen", "team_member"
        if last in ("SelectorGroupChat", "MagenticOneGroupChat"):
            return "AutoGen", "team_delegates"
    if root in ("autogen", "ag2"):
        if last in _AG2_AGENTS:
            return "AutoGen", "autogen_agent"
        if last == "GroupChat":
            return "AutoGen", "groupchat"
        if last == "GroupChatManager":
            return "AutoGen", "gc_manager"
    if qual.startswith("google.adk"):
        if last in ("Agent", "LlmAgent"):
            return "Google ADK", "adk_agent"
        if last in ("SequentialAgent", "ParallelAgent", "LoopAgent"):
            return "Google ADK", "adk_workflow"
    if root == "langgraph":
        if last == "create_react_agent":
            return "LangGraph", "react_agent"
        if last == "StateGraph":
            return "LangGraph", "graph"
    if root == "langchain" and last == "create_agent":
        return "LangGraph", "react_agent"
    if root in ("langchain", "langchain_classic"):
        # The pre-1.0 agent constructors: `create_*_agent(llm, tools, prompt)`, run
        # by an `AgentExecutor`, and the older `initialize_agent(tools, llm)`.
        if last in _LC_AGENT_FACTORIES:
            return "LangChain", "lc_agent"
        if last == "initialize_agent":
            return "LangChain", "lc_init"
        if last in ("AgentExecutor", "from_agent_and_tools"):
            return "LangChain", "lc_executor"
    if root == "langgraph_supervisor" and last == "create_supervisor":
        return "LangGraph", "supervisor"
    if root == "langgraph_swarm" and last == "create_swarm":
        return "LangGraph", "swarm"
    return None


_TOOL_DECORATORS = ("tool", "function_tool", "mcp.tool", "agent.tool", "register_tool")
_TOOL_CONSTRUCTORS = ("Tool", "StructuredTool", "StructuredTool.from_function", "FunctionTool")

#: Cheap pre-filter, so most of a repository is not parsed a second time: a file has
#: to import one of the frameworks above (every constructor is import-gated anyway) or
#: define a decorated tool an agent in another file may name.
_HINT = re.compile(
    r"(?:from|import)\s+(?:agents|crewai|autogen\w*|ag2|google\.adk|langgraph\w*|langchain\w*"
    r"|openai|anthropic|litellm|pydantic_ai|strands|agno|smolagents|llama_index|semantic_kernel"
    r"|agent_framework|haystack|dspy|claude_agent_sdk|livekit|pipecat)\b"
    r"|@openai/agents|@(?:\w+\.)?(?:function_)?tool\b"
    # `triage.handoffs.append(x)` in a file of wiring that imports no framework itself.
    r"|\.(?:handoffs|tools)\s*(?:=|\+=|\.(?:append|extend|insert)\s*\()"
    # Shapes any framework shares: an agent class, a call given tools or sub-agents.
    r"|class\s+\w+\s*\([^)]*(?:Agent|Role)\b"
    r"|\b(?:tools|functions|toolsets|allowed_tools|sub_agents|handoffs|mcp_servers)\s*="
    # The same in TypeScript and JavaScript.
    r"|\b(?:tools|allowedTools|handoffs)\s*:|\bcreate\w*Agent\s*\(|\bnew\s+\w*Agent\s*\("
    r"|\b(?:streamText|generateText)\s*\("
    # `MODEL = os.getenv(...)` in a config module an agent file imports its model from.
    r"|(?m:^[A-Z0-9_]*MODEL[A-Z0-9_]*\s*(?::[^=\n]*)?=)"
    # `TOOLS = [search]` in a module of plain functions that imports no framework: the
    # list a graph's `ToolNode(TOOLS)` and `.bind_tools(TOOLS)` name.
    r"|(?m:^[A-Z0-9_]*TOOLS?[A-Z0-9_]*\s*(?::[^=\n]*)?=)"
)

#: Functions that make a tool out of a function: `function_tool(fn)`, `tool(fn)`,
#: `function_tool(name_override="x")(fn)`. Counted only when imported, since `tool`
#: is a name any codebase may define for itself.
_TOOL_WRAPPERS = ("function_tool", "tool")
#: Parameters a framework fills in, not the model: left out of a tool's argument names.
_CONTEXT_PARAMS = {"self", "cls", "ctx", "context", "run_context", "wrapper", "tool_context"}


def _fn_info(fn: ast.FunctionDef | ast.AsyncFunctionDef) -> tuple[str, list[str]]:
    """A function's description (its docstring's first paragraph) and argument names."""
    doc = (ast.get_docstring(fn) or "").strip().split("\n\n", 1)[0]
    args: list[str] = []
    for a in [*fn.args.posonlyargs, *fn.args.args, *fn.args.kwonlyargs]:
        annotation: ast.AST | None = a.annotation
        if isinstance(annotation, ast.Subscript):
            annotation = annotation.value
        ann = _path(annotation) if annotation is not None else ""
        if a.arg in _CONTEXT_PARAMS or ann.rsplit(".", 1)[-1] in (
            "RunContextWrapper",
            "ToolContext",
            "InjectedToolArg",
        ):
            continue
        args.append(a.arg)
    return " ".join(doc.split())[:300], args


def wrapped_tool(call: ast.Call, imported: set[str]) -> tuple[str, str | None] | None:
    """``(tool name, wrapped function name)`` when ``call`` makes a tool of a function.

    ``function_tool(fn)``, ``function_tool(name_override="x")(fn)``, ``tool(fn)``,
    ``tool("x")(fn)``, ``Tool(name="x", func=fn)``, ``StructuredTool.from_function(fn)``,
    ``FunctionTool(fn)``. The tool's name is the one the code gives it, else the
    function's. ``imported`` is the names the file imports: a bare ``tool`` or
    ``function_tool`` counts only when it is one of them.
    """
    func = call.func
    opts: ast.Call | None = None
    target: ast.AST | None = None
    if isinstance(func, ast.Call):  # curried: function_tool(...)(fn)
        opts, func = func, func.func
        target = call.args[0] if call.args else None
    path = _path(func)
    last = path.rsplit(".", 1)[-1]
    override: str | None = None
    if last in _TOOL_WRAPPERS:
        if path.split(".")[0] not in imported:
            return None
        if opts is None:
            opts = call
            args = list(call.args)
            if args and _str(args[0]) is not None:  # tool("search", fn)
                override = _str(args.pop(0))
            target = args[0] if args else _kw(call, "func")
        else:
            override = _str(opts.args[0]) if opts.args else None
        override = _str(_kw(opts, "name_override", "name")) or override
        if target is None:
            return None  # `@function_tool(name_override="x")`: a decorator, read there
    elif opts is None and (
        path in _TOOL_CONSTRUCTORS
        or any(path.endswith(f".{c}") for c in _TOOL_CONSTRUCTORS)
        or path.endswith("FunctionTool.from_defaults")
    ):
        target = _kw(call, "func", "fn", "coroutine") or (call.args[0] if call.args else None)
        override = _str(_kw(call, "name"))
    else:
        return None
    fn_name = (
        target.id
        if isinstance(target, ast.Name)
        else target.attr
        if isinstance(target, ast.Attribute)
        else None
    )
    name = override or fn_name
    return (name, fn_name) if name else None


def tool_class(node: ast.ClassDef) -> tuple[str, str, list[str]] | None:
    """``(tool name, description, argument names)`` for a tool written as a class: a
    subclass of a ``*Tool`` base (``class FileWriteTool(Tool)``, LangChain's
    ``BaseTool``) that names itself, in its body (``name = "file_write"``) or in its
    constructor (``super().__init__(name="file_write", ...)``). An agent handed
    ``FileWriteTool()`` calls it by that name. None for anything else."""
    bases = [_path(b).rsplit(".", 1)[-1] for b in node.bases]
    if not any(b.endswith("Tool") for b in bases if b):
        return None
    fields: dict[str, ast.AST] = {}
    args: list[str] = []
    for stmt in node.body:
        if isinstance(stmt, ast.Assign):
            for target in stmt.targets:
                if isinstance(target, ast.Name):
                    fields.setdefault(target.id, stmt.value)
        elif isinstance(stmt, ast.AnnAssign) and stmt.value is not None:
            if isinstance(stmt.target, ast.Name):
                fields.setdefault(stmt.target.id, stmt.value)
        elif isinstance(stmt, ast.FunctionDef | ast.AsyncFunctionDef):
            if stmt.name == "__init__":
                for sub in ast.walk(stmt):
                    if (
                        isinstance(sub, ast.Call)
                        and isinstance(sub.func, ast.Attribute)
                        and sub.func.attr == "__init__"
                    ):
                        for kw in sub.keywords:
                            if kw.arg:
                                fields.setdefault(kw.arg, kw.value)
            elif stmt.name in ("execute", "run", "_run", "arun", "_arun", "__call__"):
                args = args or _fn_info(stmt)[1]
    name = _str(fields.get("name"))
    if not name:
        return None
    return name, _str(fields.get("description")) or ast.get_docstring(node) or "", args


def _dict_fields(node: ast.AST | None) -> dict[str, ast.AST]:
    if not isinstance(node, ast.Dict):
        return {}
    return {
        k.value: v
        for k, v in zip(node.keys, node.values, strict=False)
        if isinstance(k, ast.Constant) and isinstance(k.value, str)
    }


def schema_tool(node: ast.AST) -> tuple[str, str, list[str]] | None:
    """``(name, description, argument names)`` of a tool written as a JSON schema:
    Chat Completions ``{"type": "function", "function": {...}}``, the Responses API's
    flattened form, or Anthropic's ``{"name": ..., "input_schema": ...}``."""
    entries = _dict_fields(node)
    if not entries:
        return None
    fields: dict[str, ast.AST] = {}
    params: ast.AST | None = None
    if _str(entries.get("type")) == "function":
        inner = _dict_fields(entries.get("function"))
        fields = inner or (entries if "parameters" in entries else {})
        params = fields.get("parameters")
    elif "input_schema" in entries:
        fields, params = entries, entries.get("input_schema")
    name = _str(fields.get("name"))
    if not name:
        return None
    args = list(_dict_fields(_dict_fields(params).get("properties")))
    return name, _str(fields.get("description")) or "", args


def _path(node: ast.AST) -> str:
    parts: list[str] = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
    else:
        return ""
    return ".".join(reversed(parts))


def _service_model(node: ast.AST | None) -> ast.AST | None:
    """The model a voice framework's LLM service is built with: a string as is, else
    ``model=`` on the call, or on its ``settings=``/``params=`` object."""
    if not isinstance(node, ast.Call):
        return node
    if (model := _kw(node, "model")) is not None:
        return model
    for nested in (_kw(node, "settings"), _kw(node, "params")):
        if isinstance(nested, ast.Call) and (model := _kw(nested, "model")) is not None:
            return model
    return None


def _str(node: ast.AST | None) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


def _strings(node: ast.AST | None) -> list[str]:
    """Every string literal a node is or lists (``"a"``, ``["a", "b"]``)."""
    if node is None:
        return []
    if (s := _str(node)) is not None:
        return [s]
    if isinstance(node, ast.List | ast.Tuple | ast.Set):
        return [s for e in node.elts if (s := _str(e)) is not None]
    return []


def _kw(call: ast.Call, *names: str) -> ast.AST | None:
    for kw in call.keywords:
        if kw.arg in names:
            return kw.value
    return None


def _decorator_name(node: ast.AST) -> str:
    if isinstance(node, ast.Call):
        node = node.func
    return _path(node)


class _Extractor:
    """Reads one Python file into raw definitions with unresolved references."""

    def __init__(self, tree: ast.Module, rel: str, start: int) -> None:
        self.tree = tree
        self.rel = rel
        self.out = _FileResult(file=rel)
        self.next_idx = start
        self.imports: dict[str, str] = {}
        #: id(call) -> (var, enclosing class) for `x = Call(...)` and `return Call(...)`
        self.call_target: dict[int, tuple[str | None, str | None]] = {}
        #: id(call) -> raw index
        self.call_raw: dict[int, int] = {}
        #: variable -> list literal it was assigned (tools = [a, b])
        self.lists: dict[str, ast.AST] = {}
        self.functions: dict[str, ast.FunctionDef | ast.AsyncFunctionDef] = {}
        #: id(call) of every `return Crew(...)` inside a CrewBase `@crew` method
        self.crew_methods: set[int] = set()
        #: id(call) a method of a module-level ``@CrewBase`` class returns -> that
        #: ``Class.method``: how a runner reaches a crew or crew member built there
        #: (the class is built with no arguments, as ``crewai run`` builds it).
        self.crewbase_returns: dict[int, str] = {}
        #: raw index -> (its constructor call, its role)
        self.made: dict[int, tuple[ast.Call, str]] = {}
        #: Every name an import binds, relative imports included.
        self.imported: set[str] = set()
        #: variable -> dict literal it was assigned (a tool schema named once, listed later)
        self.dicts: dict[str, ast.AST] = {}
        #: variable -> the `AgentTool(agent)` / `agent.as_tool(...)` call it holds, so
        #: `tools=[math_tool]` after `math_tool = AgentTool(math_agent)` is a child.
        self.agent_tools: dict[str, ast.Call] = {}
        #: every function by name, for the description and arguments of a tool it becomes
        self.defs: dict[str, ast.FunctionDef | ast.AsyncFunctionDef] = {}
        #: variable -> the model id of the chat-model object it holds
        self.models: dict[str, str] = {}
        #: id(call) assigned to a module-level name, and id(call) a module-level
        #: function returns -> that function: how a runner reaches the agent.
        self.module_calls: set[int] = set()
        self.factory_calls: dict[int, str] = {}
        #: module-level function -> the module-level name its call is assigned to
        #: (`agent = build_agent()`): the live object a runner can take as it is.
        self.factory_objects: dict[str, str] = {}
        #: id(call) -> the module-level function it sits in
        self.enclosing: dict[int, str] = {}
        #: variable -> every call assigned to it (`tools = build_tools(kit)`)
        self.bound_calls: dict[str, list[ast.Call]] = defaultdict(list)
        #: variable -> tools its decorator registers (`@support_agent.tool`)
        self.receiver_tools: dict[str, list[str]] = defaultdict(list)

    # -- pass A: imports, assignments, functions, tools ----------------------

    def collect(self) -> None:
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    self.imports[alias.asname or alias.name.split(".")[0]] = (
                        alias.name if alias.asname else alias.name.split(".")[0]
                    )
                    self.imported.add(alias.asname or alias.name.split(".")[0])
            elif isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    self.imported.add(alias.asname or alias.name)
                    if node.module and not node.level:
                        self.imports[alias.asname or alias.name] = f"{node.module}.{alias.name}"
            elif isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                self.defs.setdefault(node.name, node)
        _record_imports(self.tree, self.rel, self.out)
        self._module_level()
        for stmt in self.tree.body:
            for target in _assigned_names(stmt):
                self.out.exported.add(target)
            if isinstance(stmt, ast.FunctionDef | ast.AsyncFunctionDef):
                self.out.exported.add(stmt.name)
                self.out.functions.add(stmt.name)
            elif isinstance(stmt, ast.ClassDef):
                self.out.classes.add(stmt.name)
                if (made := tool_class(stmt)) is not None:
                    self.out.tool_defs.setdefault(stmt.name, made[0])
                    self.out.tool_info.setdefault(made[0], (made[1], made[2]))
        self._walk_scope(self.tree.body, cls=None)

    def _module_level(self) -> None:
        """Module-level string constants, the calls bound to module-level names, and
        which module-level function each call sits in."""
        ambiguous: set[str] = set()
        stack = [self.tree.body]
        while stack:
            body = stack.pop(0)
            for stmt in body:
                if isinstance(stmt, ast.FunctionDef | ast.AsyncFunctionDef):
                    for sub in ast.walk(stmt):
                        if isinstance(sub, ast.Call):
                            self.enclosing.setdefault(id(sub), stmt.name)
                        if isinstance(sub, ast.Return) and isinstance(sub.value, ast.Call):
                            self.factory_calls.setdefault(id(sub.value), stmt.name)
                    continue
                if isinstance(stmt, ast.ClassDef):
                    continue
                value = getattr(stmt, "value", None)
                names = (
                    _assigned_names(stmt) if isinstance(stmt, ast.Assign | ast.AnnAssign) else []
                )
                if isinstance(value, ast.Call) and names:
                    self.module_calls.add(id(value))
                    if isinstance(value.func, ast.Name) and body is self.tree.body:
                        self.factory_objects.setdefault(value.func.id, names[0])
                for name in names:
                    if name in ambiguous:
                        continue
                    text = self.resolve_str(value)
                    if text is None or self.out.consts.get(name, text) != text:
                        # Assigned twice differently, or to something unreadable.
                        self.out.consts.pop(name, None)
                        ambiguous.add(name)
                        continue
                    self.out.consts[name] = text
                stack.extend(_child_bodies(stmt))

    def resolve_str(self, node: ast.AST | None, depth: int = 0) -> str | None:
        """The string an expression always is, read without running anything: a
        literal, a module constant, an f-string or ``+`` of those, or the default of
        ``os.getenv("X", "default")`` / ``os.environ.get("X", "default")``. An
        expression with any part that cannot be read is None, never a fragment."""
        if node is None or depth > 6:
            return None
        if (s := _str(node)) is not None:
            return s
        if isinstance(node, ast.Name):
            return self.out.consts.get(node.id)
        if isinstance(node, ast.JoinedStr):
            parts: list[str] = []
            for value in node.values:
                if isinstance(value, ast.FormattedValue):
                    if value.format_spec is not None:
                        return None
                    inner = self.resolve_str(value.value, depth + 1)
                else:
                    inner = _str(value)
                if inner is None:
                    return None
                parts.append(inner)
            return "".join(parts)
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            left = self.resolve_str(node.left, depth + 1)
            right = self.resolve_str(node.right, depth + 1)
            return left + right if left is not None and right is not None else None
        if isinstance(node, ast.Call):
            path = _path(node.func)
            if (
                path in ("os.getenv", "getenv", "os.environ.get", "environ.get")
                and len(node.args) >= 2
            ):
                return self.resolve_str(node.args[1], depth + 1)
            if path in ("os.getenv", "os.environ.get") and (d := _kw(node, "default")):
                return self.resolve_str(d, depth + 1)
        return None

    def model_of(self, node: ast.AST | None) -> tuple[str | None, str | None]:
        """``(model id, imported name to look up elsewhere)`` for an agent's model
        argument: a string, a constant, a chat-model object or a variable holding one,
        ``llm or "gpt-4o"`` (the one readable side), an AutoGen ``llm_config``."""
        if node is None:
            return None, None
        if (s := self.resolve_str(node)) is not None:
            return s, None
        if isinstance(node, ast.Name):
            if node.id in self.models:
                return self.models[node.id] or None, None
            if node.id in self.imported:
                return None, node.id
            return None, None
        if isinstance(node, ast.Call):
            return self._chat_model(node), None
        if isinstance(node, ast.Attribute) and _path(node.value) == "self":
            # `self.model = ChatOpenAI(model=...)`, then `create_react_agent(self.model)`.
            return (self.models.get(node.attr) or None), None
        if isinstance(node, ast.BoolOp | ast.IfExp):
            sides = node.values if isinstance(node, ast.BoolOp) else [node.body, node.orelse]
            found = {m for side in sides if (m := self.model_of(side)[0])}
            return (found.pop() if len(found) == 1 else None), None
        if isinstance(node, ast.Dict):  # AutoGen llm_config={"model": ...}
            fields = _dict_fields(node)
            if "model" in fields:
                return self.model_of(fields["model"])
            configs = fields.get("config_list")
            if isinstance(configs, ast.List) and configs.elts:
                found = {m for e in configs.elts if (m := self.model_of(e)[0])}
                return (found.pop() if len(found) == 1 else None), None
        return None, None

    def _chat_model(self, call: ast.Call) -> str | None:
        """``ChatOpenAI(model="gpt-4o")``, ``init_chat_model("openai:gpt-4o")``,
        ``LitellmModel(model=...)``, ``OpenAIChatCompletionClient(model=...)``: a model
        object from an imported class or function. A local helper (``build_model()``)
        is not read: what it returns depends on its arguments."""
        path = _path(call.func)
        if not path or path.split(".")[0] not in self.imported:
            return None
        node = _kw(call, "model", "model_name", "model_id")
        if node is None and path.rsplit(".", 1)[-1] in ("init_chat_model", "LLM") and call.args:
            node = call.args[0]
        return self.resolve_str(node)

    def _walk_scope(self, body: list[ast.stmt], cls: str | None) -> None:
        for stmt in body:
            if isinstance(stmt, ast.ClassDef):
                if body is self.tree.body and any(
                    _decorator_name(d).rsplit(".", 1)[-1] == "CrewBase" for d in stmt.decorator_list
                ):
                    self._crewbase_methods(stmt)
                self._walk_scope(stmt.body, cls=stmt.name)
                continue
            if isinstance(stmt, ast.FunctionDef | ast.AsyncFunctionDef):
                self.functions.setdefault(stmt.name, stmt)
                self._check_tool(stmt)
                decorators = {_decorator_name(d).rsplit(".", 1)[-1] for d in stmt.decorator_list}
                for sub in ast.walk(stmt):
                    if isinstance(sub, ast.Return) and isinstance(sub.value, ast.Call):
                        # `def researcher(self): return Agent(...)` — the agent is named
                        # by its factory, which is how CrewBase and most builders work.
                        self.call_target.setdefault(id(sub.value), (stmt.name, cls))
                        if "crew" in decorators:
                            self.crew_methods.add(id(sub.value))
                self._walk_scope(stmt.body, cls=cls)
                continue
            self._note_assign(stmt, cls)
            for child_body in _child_bodies(stmt):
                self._walk_scope(child_body, cls=cls)

    def _crewbase_methods(self, node: ast.ClassDef) -> None:
        """The calls each method of a ``@CrewBase`` class returns (its ``@agent``
        Agents, its ``@crew`` Crew), each reached as ``Class.method``."""
        for stmt in node.body:
            if isinstance(stmt, ast.FunctionDef | ast.AsyncFunctionDef):
                for sub in ast.walk(stmt):
                    if isinstance(sub, ast.Return) and isinstance(sub.value, ast.Call):
                        self.crewbase_returns.setdefault(id(sub.value), f"{node.name}.{stmt.name}")

    def _note_assign(self, stmt: ast.stmt, cls: str | None) -> None:
        value: ast.AST | None = None
        targets: list[str] = []
        if isinstance(stmt, ast.Assign):
            value = stmt.value
            targets = [_target_name(t) for t in stmt.targets]
        elif isinstance(stmt, ast.AnnAssign) and stmt.value is not None:
            value = stmt.value
            targets = [_target_name(stmt.target)]
        targets = [t for t in targets if t]
        if value is None or not targets:
            return
        var = targets[0]
        if isinstance(value, ast.Call):
            self.call_target[id(value)] = (var, cls)
            self.bound_calls[var].append(value)
            if isinstance(value.func, ast.Name):
                self.out.aliases.setdefault(var, value.func.id)
            path = _path(value.func)
            if path.rsplit(".", 1)[-1] in ("AgentTool", "as_tool", "asTool"):
                self.agent_tools[var] = value
            if path.rsplit(".", 1)[-1] == "create_handoff_tool":
                target = _str(_kw(value, "agent_name")) or (
                    _str(value.args[0]) if value.args else None
                )
                if target:
                    self.out.handoff_vars[var] = target
            elif path.rsplit(".", 1)[-1] in ("AgentTool", "TeamTool") or (
                path.rsplit(".", 1)[-1] in ("as_tool", "asTool")
                and isinstance(value.func, ast.Attribute)
            ):
                self.out.agent_tool_vars[var] = value
                return
            made = wrapped_tool(value, self.imported)
            if made is not None:
                # `lookup = function_tool(fetch)`: the tool is named by the code or by
                # the function, and says what the function's docstring says.
                self.out.tool_defs[var] = made[0]
                self._note_info(made[0], made[1], value)
            elif path in _TOOL_CONSTRUCTORS or any(
                path.endswith(f".{c}") for c in _TOOL_CONSTRUCTORS
            ):
                name = _str(_kw(value, "name"))
                if name:
                    self.out.tool_defs[var] = name
            model = self._chat_model(value)
            if model is not None:
                if self.models.get(var, model) != model:
                    self.models[var] = ""  # two models under one name: neither
                else:
                    self.models[var] = model
        elif isinstance(value, ast.List | ast.Tuple):
            self.lists[var] = value
        elif isinstance(value, ast.Dict):
            self.dicts[var] = value

    def _note_info(self, name: str, fn_name: str | None, call: ast.Call | None) -> None:
        """Record what a tool says about itself, from its function and its options."""
        if name in self.out.tool_info:
            return
        doc, args = "", list[str]()
        if fn_name and fn_name in self.defs:
            doc, args = _fn_info(self.defs[fn_name])
        if call is not None:
            opts = call.func if isinstance(call.func, ast.Call) else call
            doc = _str(_kw(opts, "description_override", "description")) or doc
        if doc or args:
            self.out.tool_info[name] = (doc, args)
        elif fn_name and fn_name not in self.defs:
            # `function_tool(tools.get_ticket)`: the function lives in another module.
            self.out.tool_fn.setdefault(name, fn_name)

    def _check_tool(self, fn: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        for decorator in fn.decorator_list:
            name = _decorator_name(decorator)
            receiver, _, method = name.rpartition(".")
            if (
                receiver.isidentifier()
                and receiver not in self.imports
                and method in ("tool", "tool_plain", "register_tool", "function_tool")
            ):
                # `@support_agent.tool`: a tool of the agent held in that variable (an
                # MCP server's `@mcp.tool` is kept as a tool and attaches to nothing).
                self.receiver_tools[receiver].append(fn.name)
            if any(name.endswith(marker) for marker in _TOOL_DECORATORS):
                explicit = None
                if isinstance(decorator, ast.Call) and decorator.args:
                    explicit = _str(decorator.args[0])
                if isinstance(decorator, ast.Call):
                    explicit = explicit or _str(_kw(decorator, "name_override", "name"))
                self.out.tool_defs[fn.name] = explicit or fn.name
                self._note_info(
                    explicit or fn.name,
                    fn.name,
                    decorator if isinstance(decorator, ast.Call) else None,
                )
                return

    # -- pass B: one raw per recognised constructor -------------------------

    def qual(self, func: ast.AST) -> str:
        # `Agent[Context](...)`: the type parameter wraps the constructor being called.
        if isinstance(func, ast.Subscript):
            func = func.value
        path = _path(func)
        if not path:
            return ""
        head, _, rest = path.partition(".")
        base = self.imports.get(head)
        if base is None:
            return ""
        return f"{base}.{rest}" if rest else base

    def create(self) -> None:
        loop: _Raw | None = None
        for node in ast.walk(self.tree):
            if not isinstance(node, ast.Call):
                continue
            qual = self.qual(node.func)
            match = _constructor(qual)
            if match is None:
                match = self._agent_shaped(node, qual)
            if match is None:
                if _kw(node, "tools") is not None:
                    loop = self._loop(node, loop)
                continue
            framework, role = match
            kwargs = {kw.arg for kw in node.keywords if kw.arg}
            # `agents` is also the name of plenty of local packages; the SDK's Agent is
            # always given a name, and an instruction, tools or handoffs besides.
            if role == "openai_agent" and not (
                "name" in kwargs and kwargs & {"instructions", "tools", "handoffs", "model"}
            ):
                continue
            var, cls = self.call_target.get(id(node), (None, None))
            raw = _Raw(
                idx=self.next_idx,
                framework=framework,
                kind=_KIND[role],
                file=self.rel,
                line=node.lineno,
                var=var,
                cls=cls,
            )
            raw.origin = qual or None
            raw.name = self._name(node, role, var, cls)
            raw.named = raw.name is not None and raw.name not in (var, cls)
            raw.instructions = self.resolve_str(_kw(node, *_INSTRUCTION_KW))
            if role == "generic_agent":
                raw.confidence = "medium"
                raw.evidence = f"agent-shaped call to {qual or _path(node.func)}"
            else:
                raw.evidence = f"{framework} constructor {qual.rsplit('.', 1)[-1]}"
            model_node = _kw(node, *_MODEL_KW.get(role, ()))
            if model_node is None and role in _MODEL_ARG and len(node.args) > _MODEL_ARG[role]:
                model_node = node.args[_MODEL_ARG[role]]
            if model_node is None and node.args and qual.startswith("pydantic_ai."):
                model_node = node.args[0]  # `Agent("openai:gpt-4o", tools=[...])`
            if role == "voice_pipeline":
                model_node = self._pipeline_model()
            raw.model, raw.model_var = self.model_of(model_node)
            # No model keyword, no positional model, no `**kwargs` that could carry one:
            # the framework's own default runs it.
            raw.default_model = (
                model_node is None
                and role in _DEFAULT_MODEL_ROLES
                and not any(kw.arg is None for kw in node.keywords)
            )
            if cls is None and id(node) in self.module_calls:
                raw.attr, raw.attr_kind = var, "object"
            elif id(node) in self.crewbase_returns:
                raw.attr, raw.attr_kind = self.crewbase_returns[id(node)], "factory"
            elif id(node) in self.factory_calls:
                factory = self.factory_calls[id(node)]
                # `agent = build_agent()` at module level: the module already builds it.
                if factory in self.factory_objects:
                    raw.attr, raw.attr_kind = self.factory_objects[factory], "object"
                else:
                    raw.attr, raw.attr_kind = factory, "factory"
            self.next_idx += 1
            self.call_raw[id(node)] = raw.idx
            self.out.raws.append(raw)
            if var:
                self.out.vars.setdefault(var, raw.idx)
            self.made[raw.idx] = (node, role)

    def _agent_shaped(self, call: ast.Call, qual: str) -> tuple[str, str] | None:
        """An agent built by a framework this scan has no constructor for: a call to
        an imported callable that is given tools (or sub-agents) and an instruction,
        a model or a name. A callee named like an agent needs only one of those.
        Provider SDK calls, tool nodes, toolkits and MCP servers are not agents."""
        func = call.func.value if isinstance(call.func, ast.Subscript) else call.func
        path = _path(func)
        head = path.split(".")[0]
        if not path or (not qual and head not in self.imported):
            return None
        last = path.rsplit(".", 1)[-1]
        if _NOT_AN_AGENT.search(last) or any(
            path == suffix or path.endswith(f".{suffix}") for suffix in _LOOP_CALLS
        ):
            return None
        if _AGENT_DATA.search(last):
            return None
        kwargs = {kw.arg for kw in call.keywords if kw.arg}
        has_tools = bool(kwargs & {*_GENERIC_TOOLS_KW, *_GENERIC_CHILDREN_KW})
        says_who = bool(kwargs & {*_GENERIC_NAME_KW, *_GENERIC_MODEL_KW, *_GENERIC_INSTRUCTION_KW})
        agentish = bool(_AGENT_CALLEE.search(last))
        # Something is built, not a helper called: a class (CamelCase) or an agent factory.
        constructs = last[:1].isupper() or agentish
        if not constructs:
            return None
        if not ((has_tools and says_who) or (agentish and (has_tools or says_who))):
            return None
        root = (qual or self.imports.get(head, head) or head).split(".")[0]
        return _framework_label(root), "generic_agent"

    def classes(self) -> None:
        """Agents written as classes: ``class Planner(BaseAgent)``, ``class Architect(Role)``.
        Their tools are what the class body or a method hands over: ``tools = [...]``,
        ``self.tools = [...]``, ``self.set_actions([...])``, ``functions=[...]``."""
        for node in ast.walk(self.tree):
            if not isinstance(node, ast.ClassDef):
                continue
            bases = [_path(b).rsplit(".", 1)[-1] for b in node.bases]
            if not any(_AGENT_BASE.search(b) for b in bases if b):
                continue
            if node.name.startswith(("Base", "Abstract", "Mock", "Fake", "Dummy")):
                continue
            if node.name.endswith(("Base", "Mixin", "Protocol", "Interface")):
                continue
            origins = [
                self.imports[b]
                for b in (_path(x).split(".")[0] for x in node.bases)
                if b in self.imports
            ]
            known = next((k for o in origins if (k := self._known_base(o, node)) is not None), None)
            raw = _Raw(
                idx=self.next_idx,
                framework=known
                or _framework_label(next((o.split(".")[0] for o in origins), "custom")),
                kind="agent",
                file=self.rel,
                line=node.lineno,
                name=node.name,
                cls=node.name,
                confidence="high" if known else "low",
                evidence=f"class {node.name}({', '.join(b for b in bases if b)})",
                origin=None if known else next(iter(origins), None),
            )
            raw.attr, raw.attr_kind = node.name, "factory"
            for sub in ast.walk(node):
                if isinstance(sub, ast.Assign | ast.AnnAssign):
                    targets = sub.targets if isinstance(sub, ast.Assign) else [sub.target]
                    if any(_target_name(t) in ("tools", "functions") for t in targets):
                        self._tools(raw, sub.value)
                elif isinstance(sub, ast.Call):
                    last = _path(sub.func).rsplit(".", 1)[-1]
                    if last in _CLASS_TOOL_CALLS and sub.args:
                        self._tools(raw, sub.args[0])
                    elif (fns := _kw(sub, "functions")) is not None and id(
                        sub
                    ) not in self.call_raw:
                        self._tools(raw, fns)
                    elif (
                        known
                        and isinstance(sub.func, ast.Attribute)
                        and sub.func.attr == "__init__"
                    ):
                        # LiveKit: `super().__init__(instructions=..., tools=[...],
                        # llm=inference.LLM(model="..."))`.
                        self._tools(raw, _kw(sub, "tools"))
                        raw.instructions = raw.instructions or self.resolve_str(
                            _kw(sub, *_INSTRUCTION_KW)
                        )
                        if raw.model is None:
                            raw.model, raw.model_var = self.model_of(
                                _service_model(_kw(sub, "llm"))
                            )
            if known:
                # Methods the framework exposes to the model: `@function_tool async def
                # lookup(self, ...)`, by the name it is given or the method's own.
                for item in node.body:
                    if not isinstance(item, ast.FunctionDef | ast.AsyncFunctionDef):
                        continue
                    for dec in item.decorator_list:
                        target = dec.func if isinstance(dec, ast.Call) else dec
                        if _path(target).rsplit(".", 1)[-1] != "function_tool":
                            continue
                        named = _str(_kw(dec, "name")) if isinstance(dec, ast.Call) else None
                        raw.tools.append(("name", named or item.name))
                        doc, args = _fn_info(item)
                        self.out.tool_info.setdefault(named or item.name, (doc, args))
            self.next_idx += 1
            self.out.raws.append(raw)
            self.made[raw.idx] = (
                ast.Call(func=ast.Name(id=node.name), args=[], keywords=[]),
                "class_agent",
            )

    def _known_base(self, origin: str, node: ast.ClassDef) -> str | None:
        """The framework of a class agent whose base is a known agent class
        (LiveKit's ``Agent``), or None for any other ``*Agent`` base."""
        qual = origin
        for base in node.bases:
            path = _path(base)
            head = path.split(".")[0]
            if self.imports.get(head) == origin:
                rest = path.split(".", 1)[1] if "." in path else ""
                qual = f"{origin}.{rest}" if rest else origin
                break
        known = _known_agent(qual)
        return known[0] if known else None

    def _loop(self, call: ast.Call, loop: _Raw | None) -> _Raw | None:
        """``client.chat.completions.create(..., tools=TOOLS)`` and its Anthropic and
        LiteLLM equivalents: a hand-written agent loop. One per file, its tools the
        union of every such call's; reported only if the repository has no framework
        agent (see :class:`_Linker`)."""
        path = _path(call.func)
        hit = next(
            (
                v
                for suffix, v in _LOOP_CALLS.items()
                if path == suffix or path.endswith(f".{suffix}")
            ),
            None,
        )
        if hit is None:
            return loop
        package, framework = hit
        if not any(v.split(".")[0] == package for v in self.imports.values()):
            return loop
        if loop is None:
            stem = Path(self.rel).stem
            parent = Path(self.rel).parent.name
            name = parent if stem in _GENERIC_STEMS and parent else stem
            loop = _Raw(
                idx=self.next_idx,
                framework=framework,
                kind="agent",
                file=self.rel,
                line=call.lineno,
                name=name,
                loop=True,
                confidence="medium",
                evidence=f"{framework} function-calling call with tools",
            )
            func = self.enclosing.get(id(call))
            if func:
                loop.attr, loop.attr_kind = func, "function"
            self.next_idx += 1
            self.out.raws.append(loop)
            self.made[loop.idx] = (call, "loop")
        if loop.model is None:
            loop.model, loop.model_var = self.model_of(_kw(call, "model"))
        self._tools(loop, _kw(call, "tools"))
        return loop

    def _pipeline_tools(self, raw: _Raw) -> None:
        """A Pipecat pipeline's tools: what its LLM service registers in this file
        (``llm.register_function("lookup", handler)``,
        ``llm.register_direct_function(lookup)``), and ``FunctionSchema(name=...)``."""
        for node in ast.walk(self.tree):
            if not isinstance(node, ast.Call):
                continue
            last = _path(node.func).rsplit(".", 1)[-1]
            if last == "register_function" and node.args:
                if (name := _str(node.args[0])) is not None:
                    raw.tools.append(("name", name))
            elif last == "register_direct_function" and node.args:
                if isinstance(node.args[0], ast.Name):
                    raw.tools.append(("var", node.args[0].id))
            elif last == "FunctionSchema" and (name := _str(_kw(node, "name"))) is not None:
                raw.tools.append(("name", name))

    def _pipeline_model(self) -> ast.AST | None:
        """The model a Pipecat pipeline's LLM service is given in this file: the first
        ``OpenAILLMService(model=...)`` (or ``settings=...Settings(model=...)``) that
        names one."""
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Call) and _path(node.func).endswith("LLMService"):
                if (model := _service_model(node)) is not None:
                    return model
        return None

    def _label(self, node: ast.AST | None) -> str | None:
        """A name the code gives: a literal or a module-level string constant."""
        return self.resolve_str(node) if isinstance(node, ast.Constant | ast.Name) else None

    def _name(self, call: ast.Call, role: str, var: str | None, cls: str | None) -> str | None:
        if role == "crew_agent":
            return self._label(_kw(call, "role")) or var
        if role == "crew":
            if id(call) in self.crew_methods and cls:
                return cls
            return self._label(_kw(call, "name")) or var
        if role == "autogen_agent":
            first = call.args[0] if call.args else None
            return self._label(_kw(call, "name")) or self._label(first) or var
        if role == "supervisor":
            return self._label(_kw(call, "supervisor_name")) or "supervisor"
        if role == "graph":
            return var
        if role == "generic_agent":
            return self._label(_kw(call, *_GENERIC_NAME_KW)) or var
        if role in ("known_agent", "known_team", "voice_pipeline"):
            named = self._label(_kw(call, *_GENERIC_NAME_KW))
            if named:
                return named
            if var and var not in _GENERIC_VARS:
                return var
            # `pipeline = Pipeline([...])`, `options = ClaudeAgentOptions(...)`: the
            # variable says nothing, so the file (or its directory) names the agent.
            stem, parent = Path(self.rel).stem, Path(self.rel).parent.name
            return parent if stem in _GENERIC_STEMS and parent else stem
        named = self._label(_kw(call, "name"))
        if named:
            return named
        if cls and var in _HOLDER_VARS and role in ("react_agent", "lc_agent", "lc_init"):
            # `self.graph = create_react_agent(...)` inside `class CurrencyAgent`: the
            # class is the agent; `graph` only says where it keeps it.
            return cls
        return var

    # -- pass C: tools and children -----------------------------------------

    def link(self) -> None:
        for raw in list(self.out.raws):
            if raw.var and raw.var in self.receiver_tools:
                raw.tools.extend(("var", t) for t in self.receiver_tools[raw.var])
            call, role = self.made[raw.idx]
            if role == "class_agent":
                continue
            if role in ("generic_agent", "known_agent", "known_team"):
                tools = _kw(call, *_GENERIC_TOOLS_KW, "plugins")
                if tools is None and role != "generic_agent" and call.args:
                    # smolagents' `CodeAgent([search, fetch], model)`: tools first.
                    first = call.args[0]
                    tools = first if isinstance(first, ast.List) else None
                self._tools(raw, tools)
                for kw in call.keywords:
                    if kw.arg in _GENERIC_CHILDREN_KW:
                        for elt in self._elements(kw.value):
                            self._child(raw, elt, _GENERIC_CHILDREN_KW[kw.arg])
                continue
            if role == "voice_pipeline":
                self._pipeline_tools(raw)
                continue
            if role in _TOOL_ROLES:
                tools_expr = _kw(call, "tools")
                if tools_expr is None and role in _TOOLS_ARG and len(call.args) > _TOOLS_ARG[role]:
                    tools_expr = call.args[_TOOLS_ARG[role]]
                self._tools(raw, tools_expr)
            if role == "lc_executor":
                inner = _kw(call, "agent") or (call.args[0] if call.args else None)
                raw.wraps = self._ref(inner) if inner is not None else None
            if role == "openai_agent":
                self._handoffs(raw, _kw(call, "handoffs"))
            elif role == "crew_agent":
                delegation = _kw(call, "allow_delegation")
                raw.allow_delegation = isinstance(delegation, ast.Constant) and bool(
                    delegation.value
                )
            elif role == "crew":
                manager = _kw(call, "manager_agent")
                process = _path(_kw(call, "process") or ast.Constant(None))
                members = [
                    ("class", raw.cls) if ref[0] == "class" else ref
                    for elt in self._elements(_kw(call, "agents"))
                    if (ref := self._ref(elt)) is not None
                ]
                if manager is not None:
                    # crew -> its manager -> the members the manager assigns work to.
                    raw.manager = self._ref(manager)
                    raw.members = members
                else:
                    # A hierarchical crew without a named manager gets one from CrewAI
                    # itself, so the crew decides who works next rather than just
                    # running them in order.
                    relation = "delegates" if process.endswith("hierarchical") else "member"
                    raw.children.extend((m, relation) for m in members)
                    if relation == "delegates" and raw.model is None:
                        # The manager CrewAI makes runs on `manager_llm`: the model
                        # the crew itself calls to decide who works next.
                        raw.model, raw.model_var = self.model_of(_kw(call, "manager_llm"))
            elif role == "autogen_agent":
                for label in _strings(_kw(call, "handoffs")):
                    raw.children.append((("label", label), "handoff"))
                for elt in self._elements(_kw(call, "handoffs")):
                    if isinstance(elt, ast.Call):
                        target = _str(_kw(elt, "target")) or (
                            _str(elt.args[0]) if elt.args else None
                        )
                        if target:
                            raw.children.append((("label", target), "handoff"))
            elif role in ("team_member", "team_delegates"):
                members = _kw(call, "participants") or (call.args[0] if call.args else None)
                for elt in self._elements(members):
                    self._child(raw, elt, "member" if role == "team_member" else "delegates")
            elif role == "groupchat":
                members = _kw(call, "agents") or (call.args[0] if call.args else None)
                for elt in self._elements(members):
                    self._child(raw, elt, "delegates")
            elif role == "gc_manager":
                group = _kw(call, "groupchat") or (call.args[0] if call.args else None)
                raw.absorbs = self._ref(group) if group is not None else None
            elif role in ("adk_agent", "adk_workflow"):
                relation = "delegates" if role == "adk_agent" else "member"
                for elt in self._elements(_kw(call, "sub_agents")):
                    self._child(raw, elt, relation)
            elif role in ("supervisor", "swarm"):
                members = _kw(call, "agents") or (call.args[0] if call.args else None)
                for elt in self._elements(members):
                    self._child(raw, elt, "delegates" if role == "supervisor" else "member")
                if role == "supervisor":
                    self._tools(raw, _kw(call, "tools"))
            elif role == "graph":
                self._graph(raw)

    def _handoffs(self, raw: _Raw, expr: ast.AST | None) -> None:
        """OpenAI Agents SDK hand-offs: agents, and ``handoff(agent)`` /
        ``handoff(agent=x, on_handoff=...)`` wrapping one."""
        for elt in self._elements(expr):
            if isinstance(elt, ast.Call) and _path(elt.func).rsplit(".", 1)[-1] == "handoff":
                elt = elt.args[0] if elt.args else _kw(elt, "agent")
            self._child(raw, elt, "handoff")

    # -- pass D: an agent's lists changed after it was built ----------------

    def mutate(self) -> None:
        """``a.handoffs = [...]``, ``a.handoffs.append(x)`` / ``.extend([...])`` /
        ``.insert(i, x)``, ``a.handoffs += [...]``, and the same for ``tools``. Each is
        recorded against the variable it changes and joined to that agent once every
        file is read, so wiring in its own module counts too. Hand-offs added this way
        are added to the agent's, never instead of them."""
        for node in ast.walk(self.tree):
            if (
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Attribute)
                and node.func.attr == "clone"
                and _kw(node, "name") is None
            ):
                # The Agents SDK's `writer.clone(tools=[a.as_tool(...)])`: the same agent,
                # under the same name, handed more tools or agents. Read as more of it.
                for kw in node.keywords:
                    if kw.arg in ("tools", "handoffs"):
                        self._extend(node.func.value, kw.arg, kw.value, node.lineno)
                continue
            owner: ast.AST | None = None
            attr = ""
            value: ast.AST | None = None
            if isinstance(node, ast.Assign | ast.AugAssign):
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                if isinstance(node, ast.AugAssign) and not isinstance(node.op, ast.Add):
                    continue
                for target in targets:
                    if isinstance(target, ast.Attribute) and target.attr in ("handoffs", "tools"):
                        owner, attr, value = target.value, target.attr, node.value
            elif (
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Attribute)
                and node.func.attr in ("append", "extend", "insert")
                and isinstance(node.func.value, ast.Attribute)
                and node.func.value.attr in ("handoffs", "tools")
            ):
                owner, attr = node.func.value.value, node.func.value.attr
                args = node.args[1:] if node.func.attr == "insert" else node.args[:1]
                if not args:
                    continue
                value = args[0] if node.func.attr == "extend" else ast.List(elts=[args[0]])
            if owner is None or value is None:
                continue
            self._extend(owner, attr, value, getattr(node, "lineno", 0))

    def _extend(self, owner: ast.AST, attr: str, value: ast.AST, line: int) -> None:
        """Record ``value`` as more ``attr`` ("tools" or "handoffs") of the agent
        ``owner`` names, joined to it once every file is read."""
        ref = self._ref(owner) if isinstance(owner, ast.Name | ast.Attribute) else None
        if ref is None or ref[0] != "var":
            return
        if ref[1] not in self.out.vars and ref[1] not in self.imported:
            # Neither an agent of this file nor a name imported into it: some other
            # object with a `tools` list, not an agent elsewhere that shares a name.
            return
        change = _Raw(
            idx=self.next_idx,
            framework="",
            kind="change",
            file=self.rel,
            line=line,
            dropped=True,
            extends=ref,
        )
        self.next_idx += 1
        if attr == "handoffs":
            self._handoffs(change, value)
        else:
            self._tools(change, value)
        if change.children or change.tools:
            self.out.raws.append(change)

    # -- pass E: what other files may look up by name ------------------------

    def export(self) -> None:
        """Module-level tool lists and list-returning helpers, as tool references, for
        an agent in another file that names them (``tools=ALL_TOOLS``,
        ``tools=build_tools()`` after ``from .tools import ...``), and what each
        module-level function says about itself, for a tool another file makes of it."""
        for stmt in self.tree.body:
            if isinstance(stmt, ast.FunctionDef | ast.AsyncFunctionDef):
                doc, args = _fn_info(stmt)
                if doc or args:
                    self.out.func_info.setdefault(stmt.name, (doc, args))
        for var, value in self.lists.items():
            if var in self.out.exported:
                probe = _Raw(idx=-1, framework="", kind="", file="", line=0)
                self._tools(probe, value)
                if probe.tools:
                    self.out.tool_lists[var] = probe.tools
        for stmt in self.tree.body:
            if isinstance(stmt, ast.FunctionDef | ast.AsyncFunctionDef):
                seq = self._returned(stmt, 0)
                if seq:
                    probe = _Raw(idx=-1, framework="", kind="", file="", line=0)
                    self._tool_elements(probe, seq)
                    if probe.tools:
                        self.out.tool_helpers[stmt.name] = probe.tools

    def _elements(self, expr: ast.AST | None) -> list[ast.AST]:
        if expr is None:
            return []
        seq = self._sequence(expr, 0)
        return seq if seq is not None else [expr]

    def _sequence(self, expr: ast.AST, depth: int) -> list[ast.AST] | None:
        """The elements of ``expr`` when it is a list this file shows, else None.

        A literal, ``a + b``, a name bound to one, ``tools or ALL_TOOLS`` and
        ``A if c else B`` (every side that is a list), and a call to a function of this
        file whose ``return`` is one. A call to anything else is a list this file does
        not show: it stands as a :class:`_Deferred` the repository-wide lookup may
        resolve, and is never itself taken for a tool or an agent.
        """
        if depth > 4:
            return None
        if isinstance(expr, ast.List | ast.Tuple | ast.Set):
            out: list[ast.AST] = []
            for elt in expr.elts:
                if isinstance(elt, ast.Starred):
                    out.extend(self._sequence(elt.value, depth + 1) or [elt.value])
                else:
                    out.append(elt)
            return out
        if isinstance(expr, ast.BinOp) and isinstance(expr.op, ast.Add):
            left = self._sequence(expr.left, depth + 1)
            right = self._sequence(expr.right, depth + 1)
            return (left or [expr.left]) + (right or [expr.right])
        if isinstance(expr, ast.Name) and expr.id in self.lists:
            return self._sequence(self.lists[expr.id], depth + 1)
        if (
            isinstance(expr, ast.Attribute)
            and _path(expr.value) == "self"
            and expr.attr in self.lists
        ):
            # `self.tools = [get_rate]` then `create_react_agent(llm, tools=self.tools)`
            # in a class that builds its agent: the list the class keeps.
            return self._sequence(self.lists[expr.attr], depth + 1)
        if isinstance(expr, ast.Name) and len(self.bound_calls.get(expr.id, ())) == 1:
            # `tools = build_tools(kit)` then `tools=tools`: what that helper of this
            # file returns. Bound to anything else, the name is left as it was.
            call = self.bound_calls[expr.id][0]
            func = call.func
            if isinstance(func, ast.Name) and func.id in self.functions:
                return self._returned(self.functions[func.id], depth + 1) or []
            return None
        if isinstance(expr, ast.BoolOp | ast.IfExp):
            sides = expr.values if isinstance(expr, ast.BoolOp) else [expr.body, expr.orelse]
            found: list[list[ast.AST]] = []
            for side in sides:
                seq = self._sequence(side, depth + 1)
                if seq is None and isinstance(side, ast.Name) and side.id in self.imported:
                    seq = [_Deferred(side.id, "list")]  # a list another module holds
                if seq is not None:
                    found.append(seq)
            # A side that is no list this file shows (a `tools` parameter) adds nothing.
            return [e for s in found for e in s] if found else None
        if isinstance(expr, ast.Call) and id(expr) not in self.call_raw:
            func = expr.func
            name = ""
            if isinstance(func, ast.Name):
                name = func.id
            elif isinstance(func, ast.Attribute) and _path(func.value) == "self":
                name = func.attr
            if name and name in self.functions:
                return self._returned(self.functions[name], depth + 1) or []
            if (
                isinstance(func, ast.Name | ast.Attribute)
                and wrapped_tool(expr, self.imported) is None
            ):
                return [_Deferred(name or _path(func).rsplit(".", 1)[-1])]
        return None

    def _returned(
        self, fn: ast.FunctionDef | ast.AsyncFunctionDef, depth: int
    ) -> list[ast.AST] | None:
        out: list[ast.AST] | None = None
        for sub in ast.walk(fn):
            if isinstance(sub, ast.Return) and sub.value is not None:
                seq = self._sequence(sub.value, depth + 1)
                if seq is not None:
                    out = (out or []) + seq
        return out

    def _ref(self, expr: ast.AST | None) -> Ref | None:
        if expr is None:
            return None
        if isinstance(expr, ast.Call):
            if id(expr) in self.call_raw:
                return ("idx", self.call_raw[id(expr)])
            func = expr.func
            if isinstance(func, ast.Name):
                return ("var", func.id)
            if isinstance(func, ast.Attribute) and _path(func.value) == "self":
                return ("var", func.attr)
            return None
        if isinstance(expr, ast.Name):
            return ("var", expr.id)
        if isinstance(expr, ast.Attribute):
            if _path(expr.value) == "self":
                return ("class", None) if expr.attr == "agents" else ("var", expr.attr)
            self._note_attr(expr)
            return ("var", expr.attr)
        if (s := _str(expr)) is not None:
            return ("label", s)
        return None

    def _note_attr(self, expr: ast.AST) -> None:
        """``mod.name`` with ``mod`` an imported module: remember which module."""
        if isinstance(expr, ast.Attribute) and isinstance(expr.value, ast.Name):
            base = expr.value.id
            if base in self.out.imports:
                if self.out.attr_modules.get(expr.attr, base) != base:
                    self.out.attr_modules[expr.attr] = ""
                else:
                    self.out.attr_modules[expr.attr] = base

    def _child(
        self, raw: _Raw, expr: ast.AST | None, relation: str, tool: str | None = None
    ) -> None:
        ref = self._ref(expr)
        if ref is None:
            return
        if ref[0] == "class":
            ref = ("class", raw.cls)
        raw.children.append((ref, relation))
        if tool:
            raw.child_tools[ref] = tool

    def _tools(self, raw: _Raw, expr: ast.AST | None) -> None:
        if isinstance(expr, ast.Name | ast.Attribute) and self._sequence(expr, 0) is None:
            # `tools=tools`, `tools=final_tools`, `tools=self.tools`: the whole list sits
            # in a name this file does not show (a parameter, a list built elsewhere). It
            # is looked up as a list; it is never itself a tool named after the variable.
            name = expr.id if isinstance(expr, ast.Name) else expr.attr
            self._note_attr(expr)
            if not (isinstance(expr, ast.Name) and expr.id in self.dicts):
                raw.tools.append(("list", name))
                return
        self._tool_elements(raw, self._elements(expr))

    def _tool_elements(self, raw: _Raw, elements: list[ast.AST]) -> None:
        for elt in elements:
            if isinstance(elt, _Deferred):
                raw.tools.append((elt.kind, elt.name))
                continue
            if isinstance(elt, ast.Dict):
                schema = schema_tool(elt)
                if schema is not None:
                    raw.tools.append(("name", schema[0]))
                    self.out.tool_info.setdefault(schema[0], (schema[1], schema[2]))
                continue
            if isinstance(elt, ast.Name) and elt.id in self.dicts:
                self._tool_elements(raw, [self.dicts[elt.id]])
                continue
            if isinstance(elt, ast.Name) and elt.id in self.agent_tools:
                self._tool_elements(raw, [self.agent_tools[elt.id]])
                continue
            if isinstance(elt, ast.Call):
                made = wrapped_tool(elt, self.imported)
                if made is not None:
                    # `function_tool(fn)`, `function_tool(needs_approval=True)(mod.fn)`
                    self._note_info(made[0], made[1], elt)
                    if made[1] and made[0] == made[1]:
                        raw.tools.append(("var", made[1]))  # may be named elsewhere
                    else:
                        raw.tools.append(("name", made[0]))
                    continue
                path = _path(elt.func)
                last = path.rsplit(".", 1)[-1]
                if last in ("tools", "get_tools", "list_tools", "load_tools", "as_tools"):
                    # `fs.tools(...)`, `toolkit.get_tools()`: a list a call returns.
                    raw.tools.append(("call", last))
                    continue
                if last in ("as_tool", "asTool") and isinstance(elt.func, ast.Attribute):
                    named = _str(_kw(elt, "tool_name")) or _str(_kw(elt, "toolName"))
                    self._child(raw, elt.func.value, "as_tool", named)
                    continue
                if last == "AgentTool":
                    self._child(
                        raw, _kw(elt, "agent") or (elt.args[0] if elt.args else None), "as_tool"
                    )
                    continue
                if last == "create_handoff_tool":
                    target = _str(_kw(elt, "agent_name")) or (
                        _str(elt.args[0]) if elt.args else None
                    )
                    if target:
                        raw.children.append((("label", target), "handoff"))
                    continue
                if last in ("function_tool", "tool", "FunctionTool") and (elt.args or elt.keywords):
                    inner = elt.args[0] if elt.args else _kw(elt, "func")
                    name = _str(_kw(elt, "name", "name_override"))
                    if name:
                        raw.tools.append(("name", name))
                    elif isinstance(inner, ast.Name):
                        raw.tools.append(("var", inner.id))
                    continue
                name = _str(_kw(elt, "name"))
                if name and (path in _TOOL_CONSTRUCTORS or last in _TOOL_CONSTRUCTORS):
                    raw.tools.append(("name", name))
                elif last:
                    # `SerperDevTool()` — a library tool, named by its class; or a
                    # tool class of the repository's own, by the name it gives itself
                    # (`tool_class`), resolved once every file is read.
                    raw.tools.append(("var", last))
            elif isinstance(elt, ast.Name) and elt.id in self.out.agent_tool_vars:
                # `math_tool = AgentTool(math_agent)`, passed by name.
                self._tool_elements(raw, [self.out.agent_tool_vars[elt.id]])
            elif isinstance(elt, ast.Name) and elt.id in self.out.handoff_vars:
                # `transfer_to_x = create_handoff_tool(agent_name="x")`, passed by name.
                raw.children.append((("label", self.out.handoff_vars[elt.id]), "handoff"))
            elif isinstance(elt, ast.Name):
                raw.tools.append(("var", elt.id))
            elif isinstance(elt, ast.Attribute):
                self._note_attr(elt)
                raw.tools.append(("var", elt.attr))
            elif (s := _str(elt)) is not None:
                raw.tools.append(("name", s))

    # -- LangGraph StateGraph ------------------------------------------------

    def _graph(self, raw: _Raw) -> None:
        graph = _Graph(raw=raw.idx, file=self.rel)
        names = {raw.var} if raw.var else set()
        ctor = self.made[raw.idx][0]
        for node in ast.walk(self.tree):
            if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute):
                continue
            receiver = _path(node.func.value)
            method = node.func.attr
            # `StateGraph(S).add_node(...).add_edge(...)`: a chain on the constructor.
            if receiver not in names and _chain_root(node.func.value) is not ctor:
                continue
            if method == "add_node":
                self._add_node(graph, node)
            elif method == "add_edge" and len(node.args) >= 2:
                for src in _node_names(node.args[0]):
                    for dst in _node_names(node.args[1]):
                        graph.routes.append((src, dst, "edge"))
            elif method == "add_conditional_edges" and node.args:
                sources = _node_names(node.args[0])
                path_map = _kw(node, "path_map") or (node.args[2] if len(node.args) > 2 else None)
                targets: list[str] = []
                if isinstance(path_map, ast.Dict):
                    targets = [s for v in path_map.values if (s := _str(v)) is not None]
                else:
                    targets = _strings(path_map)
                if not targets:
                    router = _kw(node, "path") or (node.args[1] if len(node.args) > 1 else None)
                    if isinstance(router, ast.Name) and router.id in self.functions:
                        targets = _returned_strings(self.functions[router.id])
                for src in sources:
                    for dst in targets:
                        graph.routes.append((src, dst, "route"))
            elif method == "compile":
                name = _str(_kw(node, "name"))
                if name:
                    raw.name = name
                var, _ = self.call_target.get(id(node), (None, None))
                if var:
                    self.out.vars.setdefault(var, raw.idx)
                    if id(node) in self.module_calls:
                        raw.attr, raw.attr_kind = var, "object"
        for gname, gnode in graph.nodes.items():
            if gnode.func is not None:
                for dst in _goto_strings(gnode.func):
                    graph.routes.append((gname, dst, "route"))
                gnode.bound_tools = self._bound_tools(gnode.func)
                gnode.loads = _loaded_names(gnode.func)
                if _calls_model(gnode.func):
                    graph.llm_nodes += 1
        if graph.nodes:
            self.out.graphs.append(graph)

    def _add_node(self, graph: _Graph, call: ast.Call) -> None:
        if not call.args:
            return
        first = call.args[0]
        name = _str(first)
        value: ast.AST | None
        if name is not None:
            value = call.args[1] if len(call.args) > 1 else _kw(call, "action", "node")
        elif isinstance(first, ast.Name):
            name, value = first.id, first
        else:
            return
        func = None
        if isinstance(value, ast.Name) and value.id in self.functions:
            func = self.functions[value.id]
        graph.nodes[name] = _Node(name=name, ref=self._ref(value), func=func)

    def _bound_tools(self, fn: ast.AST, depth: int = 0) -> list[tuple[str, str]] | None:
        """The tools a node function binds to its model, or None when it binds none:
        in its own body, through a name this file binds with ``.bind_tools(T)``
        (``llm_with_tools = llm.bind_tools(tools)`` at module level), or through a
        helper of this file it calls that binds them."""
        for sub in ast.walk(fn):
            if (
                isinstance(sub, ast.Call)
                and isinstance(sub.func, ast.Attribute)
                and sub.func.attr == "bind_tools"
            ):
                probe = _Raw(idx=-1, framework="", kind="", file="", line=0)
                self._tools(probe, sub.args[0] if sub.args else _kw(sub, "tools"))
                return probe.tools
        if depth > 1:
            return None
        for name in _loaded_names(fn):
            for call in self.bound_calls.get(name, []):
                found = self._bound_tools(call, depth + 1)
                if found is not None:
                    return found
            if name in self.functions and self.functions[name] is not fn:
                found = self._bound_tools(self.functions[name], depth + 1)
                if found is not None:
                    return found
        return None


_KIND = {
    "openai_agent": "agent",
    "crew_agent": "agent",
    "crew": "crew",
    "autogen_agent": "agent",
    "team_member": "team",
    "team_delegates": "team",
    "groupchat": "team",
    "gc_manager": "supervisor",
    "adk_agent": "agent",
    "adk_workflow": "team",
    "react_agent": "agent",
    "lc_agent": "agent",
    "lc_init": "agent",
    "lc_executor": "agent",
    "graph": "graph",
    "supervisor": "supervisor",
    "swarm": "team",
    "generic_agent": "agent",
    "class_agent": "agent",
    "known_agent": "agent",
    "known_team": "team",
    "voice_pipeline": "agent",
}

#: Display names for packages the agent-shaped rule meets; anything else is shown as
#: its package name. A label only: detection never depends on it.
_FRAMEWORK_LABELS = {
    "pydantic_ai": "Pydantic AI",
    "smolagents": "smolagents",
    "llama_index": "LlamaIndex",
    "swarm": "OpenAI Swarm",
    "mcp_agent": "mcp-agent",
    "claude_agent_sdk": "Claude Agent SDK",
    "agno": "Agno",
    "phi": "Agno",
    "camel": "CAMEL",
    "strands": "Strands Agents",
    "semantic_kernel": "Semantic Kernel",
    "haystack": "Haystack",
    "dspy": "DSPy",
    "metagpt": "MetaGPT",
    "azure": "Azure AI Agents",
    "agents": "OpenAI Agents SDK",
    "langgraph": "LangGraph",
    "langchain": "LangChain",
    "crewai": "CrewAI",
    "autogen": "AutoGen",
    "autogen_agentchat": "AutoGen",
    "google": "Google ADK",
}


#: Frameworks (by the label above) whose model calls `agentfox.auto()` does not see,
#: and the client they reach the model through by default, which it does not patch.
#: `agentfox up` and `agentfox init` say so instead of promising that `auto()` records
#: every call; the gateway route governs them. None today: Google ADK (google-genai)
#: and smolagents (huggingface_hub, and its tools) are patched, see
#: `frameworks.autoguard.genai` and `frameworks.autoguard.smol`.
UNPATCHED_FRAMEWORKS: dict[str, str] = {}

#: What a repository's own agent class talks to, by the package its module imports,
#: first match wins: the label of an agent built on a local ``Agent`` class.
_LOCAL_AGENT_PROVIDERS = (
    ("a2a", "A2A"),
    ("anthropic", "Anthropic SDK"),
    ("openai", "OpenAI SDK"),
    ("litellm", "LiteLLM"),
    ("google.genai", "Google GenAI"),
    ("mcp", "MCP"),
)


def _framework_label(root: str) -> str:
    return _FRAMEWORK_LABELS.get(root, root or "custom")


def _target_name(target: ast.AST) -> str:
    if isinstance(target, ast.Name):
        return target.id
    if isinstance(target, ast.Attribute) and _path(target.value) == "self":
        return target.attr
    return ""


def _assigned_names(stmt: ast.stmt) -> list[str]:
    if isinstance(stmt, ast.Assign):
        return [n for t in stmt.targets if (n := _target_name(t))]
    if isinstance(stmt, ast.AnnAssign):
        return [n] if (n := _target_name(stmt.target)) else []
    return []


def _child_bodies(stmt: ast.stmt) -> list[list[ast.stmt]]:
    """Nested statement lists (if/with/try/for bodies) that are still the same scope."""
    out: list[list[ast.stmt]] = []
    for attr in ("body", "orelse", "finalbody"):
        value = getattr(stmt, attr, None)
        if isinstance(value, list) and value and isinstance(value[0], ast.stmt):
            out.append(value)
    for handler in getattr(stmt, "handlers", []) or []:
        out.append(handler.body)
    return out


def _node_names(expr: ast.AST) -> list[str]:
    """A graph endpoint: a node name, a list of them, or START/END (skipped)."""
    if isinstance(expr, ast.List | ast.Tuple):
        return [n for e in expr.elts for n in _node_names(e)]
    if (s := _str(expr)) is not None:
        return [s]
    if _path(expr).rsplit(".", 1)[-1] == "START":
        return ["__start__"]
    return []


def _returned_strings(fn: ast.AST) -> list[str]:
    return [s for sub in ast.walk(fn) if isinstance(sub, ast.Return) for s in _strings(sub.value)]


def _goto_strings(fn: ast.FunctionDef | ast.AsyncFunctionDef) -> list[str]:
    """Where a node function can send the graph next: ``Command(goto=...)`` literals
    and a ``Command[Literal[...]]`` return annotation."""
    out: list[str] = []
    for sub in ast.walk(fn):
        if isinstance(sub, ast.Call) and _path(sub.func).rsplit(".", 1)[-1] == "Command":
            out.extend(_strings(_kw(sub, "goto")))
    ann = fn.returns
    if isinstance(ann, ast.Subscript) and _path(ann.value).rsplit(".", 1)[-1] == "Command":
        inner = ann.slice
        if isinstance(inner, ast.Subscript) and _path(inner.value).rsplit(".", 1)[-1] == "Literal":
            sl = inner.slice
            out.extend(_strings(sl) if not isinstance(sl, ast.Constant) else [sl.value])
    return [s for s in out if isinstance(s, str)]


def _chain_root(expr: ast.AST) -> ast.AST:
    """The object a method chain starts from: ``StateGraph(S)`` in
    ``StateGraph(S).add_node(...).add_edge(...)``."""
    while isinstance(expr, ast.Call) and isinstance(expr.func, ast.Attribute):
        expr = expr.func.value
    return expr


#: Calls that ask a model for something: a LangChain runnable or chat model.
_MODEL_METHODS = {
    "invoke",
    "ainvoke",
    "stream",
    "astream",
    "batch",
    "abatch",
    "with_structured_output",
    "generate_content",
    "create",
}


def _calls_model(fn: ast.AST) -> bool:
    for sub in ast.walk(fn):
        if isinstance(sub, ast.Call) and isinstance(sub.func, ast.Attribute):
            if sub.func.attr in _MODEL_METHODS:
                return True
    return False


def _loaded_names(fn: ast.AST) -> set[str]:
    return {n.id for n in ast.walk(fn) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)}


# ---------------------------------------------------------------------------
# TypeScript / JavaScript: agents by shape, any framework
# ---------------------------------------------------------------------------


def _js_object(source: str, start: int) -> dict[str, str]:
    """The top-level ``key: value`` pairs of the object literal opening at ``start``.

    A reader, not a parser: it tracks bracket depth and string literals, which is all
    an object literal of names and arrays needs.
    """
    out: dict[str, str] = {}
    depth = 0
    i = start
    n = len(source)
    key_start = start + 1
    while i < n:
        c = source[i]
        if c in "'\"`":
            j = i + 1
            while j < n and source[j] != c:
                j += 2 if source[j] == "\\" else 1
            i = j + 1
            continue
        if c in "{[(":
            depth += 1
        elif c in "}])":
            depth -= 1
            if depth == 0:
                _js_pair(source[key_start:i], out)
                return out
        elif c == "," and depth == 1:
            _js_pair(source[key_start:i], out)
            key_start = i + 1
        i += 1
    return out


def _js_pair(text: str, out: dict[str, str]) -> None:
    key, sep, value = text.partition(":")
    key = key.strip()
    if sep and re.fullmatch(r"\w+", key):
        out[key] = value.strip()
    elif re.fullmatch(r"\w+", key):
        out[key] = key  # shorthand `{ tools }`


def _js_elements(value: str) -> list[str]:
    value = value.strip()
    if not (value.startswith("[") and value.endswith("]")):
        return []
    items, depth, cur = [], 0, ""
    for c in value[1:-1]:
        if c in "{[(":
            depth += 1
        elif c in "}])":
            depth -= 1
        if c == "," and depth == 0:
            items.append(cur.strip())
            cur = ""
        else:
            cur += c
    if cur.strip():
        items.append(cur.strip())
    return items


def _js_string(value: str) -> str | None:
    m = re.fullmatch(r"""\s*(["'`])([^"'`]+)\1\s*""", value)
    return m.group(2) if m else None


#: An agent built in TypeScript or JavaScript, by shape: ``new XAgent({...})`` /
#: ``XAgent.create({...})``, ``create…Agent({...})`` (LangGraph.js, deep agents),
#: ``streamText`` / ``generateText`` given tools (Vercel AI SDK), a provider SDK's
#: ``…responses|messages|chat.completions.create({tools})``, and the Claude Agent
#: SDK's ``query({options: {allowedTools}})``. Optionally assigned: ``const x = …``.
_JS_AGENT_CALL = re.compile(
    r"(?:(?:const|let|var|export\s+const)\s+(?P<var>\w+)\s*(?::[^=]{0,80})?=\s*)?(?:await\s+)?"
    r"(?:new\s+(?:\w+\.)?(?P<cls>\w*Agent)|(?P<create>\w*Agent)\.create|(?P<factory>create\w*Agent)"
    r"|(?P<vercel>streamText|generateText|streamObject|generateObject)"
    r"|(?P<sdk>(?:\w+\.)*(?:responses|messages|chat\.completions)\.(?:create|stream|parse))"
    r"|(?P<query>\bquery))\s*\(\s*\{"
)
#: ``const x = tool({...})`` / ``createTool({...})`` / ``new DynamicStructuredTool({...})``
#: / ``tool(fn, {name: ...})``: a tool, by the variable and its ``name``.
_JS_TOOL_DECL = re.compile(
    r"(?:const|let|var|export\s+const)\s+(\w+)\s*=\s*(?:new\s+)?(?:tool|createTool|DynamicStructuredTool"
    r"|DynamicTool|FunctionTool|betaZodTool)\s*\("
)
_JS_AGENTS_IMPORT = re.compile(r"""from\s+["']@openai/agents(?:[-/][\w/-]*)?["']""")
_JS_FRAMEWORKS = (
    (re.compile(r"""from\s+["']@openai/agents(?:-|/)realtime"""), "OpenAI Realtime"),
    (re.compile(r"""from\s+["']@livekit/agents"""), "LiveKit Agents"),
    (re.compile(r"""from\s+["']@voltagent/"""), "VoltAgent"),
    (re.compile(r"""from\s+["']@strands-agents/"""), "Strands Agents"),
    (re.compile(r"""from\s+["']@openai/agents"""), "OpenAI Agents SDK"),
    (re.compile(r"""from\s+["']@langchain/langgraph"""), "LangGraph"),
    (re.compile(r"""from\s+["']@anthropic-ai/claude-agent-sdk"""), "Claude Agent SDK"),
    (re.compile(r"""from\s+["']@mastra/"""), "Mastra"),
    (re.compile(r"""from\s+["']ai["']"""), "Vercel AI SDK"),
    (re.compile(r"""from\s+["']@anthropic-ai/sdk"""), "Anthropic SDK"),
    (re.compile(r"""from\s+["']openai["']"""), "OpenAI SDK"),
)
#: Constructors each framework above builds an agent with: one of these in a file
#: that imports the framework is reported at high confidence.
_JS_KNOWN = {
    "OpenAI Agents SDK": ("Agent", "RealtimeAgent"),
    "OpenAI Realtime": ("Agent", "RealtimeAgent"),
    "LiveKit Agents": ("Agent",),
    "Mastra": ("Agent",),
    "VoltAgent": ("Agent",),
    "Strands Agents": ("Agent",),
}

#: Keys an agent-ish object must have one of to be taken for an agent.
_JS_AGENT_KEYS = {
    "name",
    "instructions",
    "tools",
    "model",
    "handoffs",
    "llm",
    "prompt",
    "systemPrompt",
}


def _js_tool_refs(value: str) -> tuple[list[tuple[str, str]], list[str]]:
    """Tool references in a ``tools`` value, and the agents it lists as tools
    (``x.asTool(...)``). An array of names, factory calls or strings; an object whose
    keys are the tool names (Vercel AI SDK); or one name holding a list elsewhere."""
    value = value.strip()
    tools: list[tuple[str, str]] = []
    as_tools: list[str] = []
    if value.startswith("{"):
        return [("name", k) for k in _js_object(value, 0)], as_tools
    if re.fullmatch(r"[\w.]+", value):
        return [("list", value.rsplit(".", 1)[-1])], as_tools
    for item in _js_elements(value):
        if m := re.match(r"(\w+)\.asTool\s*\(", item):
            as_tools.append(m.group(1))
        elif re.fullmatch(r"\w+", item):
            tools.append(("var", item))
        elif (s := _js_string(item)) is not None:
            tools.append(("name", s))
        elif m := re.match(r"(?:new\s+)?(\w+)\s*\(", item):
            named = re.search(r"""name\s*:\s*["'`]([^"'`]+)""", item)
            tools.append(("name", named.group(1) if named else m.group(1)))
    return tools, as_tools


def _extract_js(source: str, rel: str, start: int) -> _FileResult:
    out = _FileResult(file=rel)
    framework = next((name for pat, name in _JS_FRAMEWORKS if pat.search(source)), "JavaScript")
    for m in _JS_TOOL_DECL.finditer(source):
        brace = source.find("{", m.end() - 1, m.end() + 600)
        fields = _js_object(source, brace) if brace != -1 else {}
        out.tool_defs[m.group(1)] = _js_string(fields.get("name", "")) or m.group(1)
    idx = start
    loop: _Raw | None = None
    for m in _JS_AGENT_CALL.finditer(source):
        fields = _js_object(source, m.end() - 1)
        var = m.group("var")
        line = source.count("\n", 0, m.start()) + 1
        tools_value = fields.get("tools", "")
        if m.group("query"):
            options = fields.get("options", "")
            opts = _js_object(options, 0) if options.startswith("{") else {}
            tools_value = opts.get("allowedTools") or opts.get("tools") or ""
            if not tools_value and "mcpServers" not in opts:
                continue
        elif m.group("vercel") or m.group("sdk"):
            if not tools_value:
                continue
        elif not (set(fields) & _JS_AGENT_KEYS):
            continue
        tools, as_tools = _js_tool_refs(tools_value) if tools_value else ([], [])
        if m.group("sdk"):
            # A hand-written loop, one per file, like the Python one: reported only
            # when the repository has no agent of a framework.
            if loop is None:
                stem = Path(rel).stem
                parent = Path(rel).parent.name
                loop = _Raw(
                    idx=idx,
                    framework=framework,
                    kind="agent",
                    file=rel,
                    line=line,
                    name=parent if stem in _GENERIC_STEMS and parent else stem,
                    loop=True,
                    confidence="medium",
                    evidence="provider SDK call with tools",
                )
                idx += 1
                out.raws.append(loop)
            loop.tools.extend(tools)
            continue
        callee = (
            m.group("cls")
            or m.group("create")
            or m.group("factory")
            or m.group("vercel")
            or "query"
        )
        known = callee in _JS_KNOWN.get(framework, ())
        stem = Path(rel).stem
        parent = Path(rel).parent.name
        raw = _Raw(
            idx=idx,
            framework=framework,
            kind="agent",
            file=rel,
            line=line,
            name=_js_string(fields.get("name", ""))
            or var
            or (parent if stem in _GENERIC_STEMS and parent else stem),
            var=var,
            confidence="high" if known else "medium",
            evidence=f"{callee}({{...}})",
        )
        raw.named = bool(_js_string(fields.get("name", "")))
        idx += 1
        raw.tools.extend(tools)
        raw.children.extend((("var", a), "as_tool") for a in as_tools)
        for item in _js_elements(fields.get("handoffs", "")):
            target = re.match(r"(?:handoff\s*\(\s*)?(\w+)", item)
            if target:
                raw.children.append((("var", target.group(1)), "handoff"))
        out.raws.append(raw)
        if var:
            out.vars.setdefault(var, raw.idx)
            out.exported.add(var)
    return out


# ---------------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------------


class AgentCollector:
    """Accumulates raw definitions file by file; :meth:`finish` resolves them."""

    def __init__(self, *, include_tests: bool = False) -> None:
        self.files: list[_FileResult] = []
        self._next = 0
        #: Read test, mock and fixture files too (see :func:`is_test_path`).
        self.include_tests = include_tests

    def add(self, source: str, rel: str, suffix: str) -> None:
        if not self.include_tests and is_test_path(rel):
            return
        if not _HINT.search(source):
            # No framework here, but a plain module of functions another file turns
            # into tools (`function_tool(tools.get_ticket)`): keep what each says.
            if suffix == ".py" and (
                "def " in source or "class " in source or Path(rel).stem == "__init__"
            ):
                self._functions_only(source, rel)
            return
        if suffix == ".py":
            try:
                tree = ast.parse(source, filename=rel)
            except (SyntaxError, ValueError):
                return  # reported by the site pass already
            ex = _Extractor(tree, rel, self._next)
            ex.out.module = _module_name(rel)
            ex.collect()
            ex.create()
            ex.classes()
            ex.link()
            ex.mutate()
            ex.export()
            result = ex.out
            self._next = ex.next_idx
        else:
            result = _extract_js(source, rel, self._next)
            self._next += len(result.raws)
        # A file of tools alone is kept too: an agent elsewhere names them.
        if (
            result.raws
            or result.tool_defs
            or result.tool_lists
            or result.tool_helpers
            or result.consts
            or result.func_info
            or result.functions
            or result.imports
            or result.classes
        ):
            self.files.append(result)

    def _functions_only(self, source: str, rel: str) -> None:
        try:
            tree = ast.parse(source, filename=rel)
        except (SyntaxError, ValueError):
            return
        result = _FileResult(file=rel)
        result.module = _module_name(rel)
        if Path(rel).stem == "__init__":
            # A package's re-exports (`from .tools import TOOLS`), for an import of it.
            _record_imports(tree, rel, result)
        for stmt in tree.body:
            if isinstance(stmt, ast.FunctionDef | ast.AsyncFunctionDef):
                result.functions.add(stmt.name)
                doc, args = _fn_info(stmt)
                if doc or args:
                    result.func_info.setdefault(stmt.name, (doc, args))
            elif isinstance(stmt, ast.ClassDef):
                result.classes.add(stmt.name)
                if (made := tool_class(stmt)) is not None:
                    result.tool_defs.setdefault(stmt.name, made[0])
                    result.tool_info.setdefault(made[0], (made[1], made[2]))
        if (
            result.tool_defs
            or result.func_info
            or result.functions
            or result.imports
            or result.classes
        ):
            self.files.append(result)

    def finish(self) -> tuple[list[AgentSpec], list[AgentEdge]]:
        return _Linker(self.files, self._next).run()


class _Linker:
    def __init__(self, files: list[_FileResult], next_idx: int) -> None:
        self.files = files
        self.raws: dict[int, _Raw] = {r.idx: r for f in files for r in f.raws}
        self.file_of: dict[int, _FileResult] = {r.idx: f for f in files for r in f.raws}
        self.next_idx = next_idx
        # Repository-wide lookups, used only when a name is defined in exactly one file.
        self.global_vars: dict[str, set[int]] = defaultdict(set)
        self.global_tools: dict[str, set[str]] = defaultdict(set)
        for f in files:
            for var, idx in f.vars.items():
                if var in f.exported:
                    self.global_vars[var].add(idx)
            for var, name in f.tool_defs.items():
                self.global_tools[var].add(name)
        self.global_lists: dict[str, list[_FileResult]] = defaultdict(list)
        self.global_helpers: dict[str, list[_FileResult]] = defaultdict(list)
        self.global_consts: dict[str, set[str]] = defaultdict(set)
        self.global_info: dict[str, list[tuple[str, list[str]]]] = defaultdict(list)
        for f in files:
            for var in f.tool_lists:
                self.global_lists[var].append(f)
            for name in f.tool_helpers:
                self.global_helpers[name].append(f)
            for name, value in f.consts.items():
                self.global_consts[name].add(value)
            for name, info in f.tool_info.items():
                self.global_info[name].append(info)
        self.global_fn_names: set[str] = {n for f in files for n in f.functions}
        self.global_funcs: dict[str, list[tuple[str, list[str]]]] = defaultdict(list)
        for f in files:
            for name, info in f.func_info.items():
                self.global_funcs[name].append(info)
        #: Module path, and every tail of it, -> the files it names (see _dotted).
        self.modules: dict[str, list[_FileResult]] = defaultdict(list)
        for f in files:
            parts = _dotted(f.file)
            for i in range(len(parts)):
                self.modules[".".join(parts[i:])].append(f)
        #: inner raw -> the AgentExecutor raw that runs it (the two are one agent)
        self.merged: dict[int, int] = {}
        #: raw -> tool references added after construction, with their own file
        self.extra_tools: dict[int, list[tuple[tuple[str, str], _FileResult | None]]] = defaultdict(
            list
        )
        self.labels: dict[str, set[int]] = defaultdict(set)
        #: (graph raw, node name) -> raw, filled by the graph pass
        self.node_agents: dict[tuple[int, str], int] = {}

    def _module(self, name: str) -> _FileResult | None:
        found = self.modules.get(name) or []
        return found[0] if len(found) == 1 else None

    def _source(
        self, name: str, file: _FileResult | None, depth: int = 0
    ) -> tuple[_FileResult, str] | None:
        """The file and name an imported ``name`` (or ``mod.name``) comes from, through
        a package's re-export. None when the import names no file of the repository."""
        if file is None or depth > 3:
            return None
        target: tuple[str, str] | None = None
        if name in file.imports and file.imports[name][1]:
            target = file.imports[name]
        elif base := file.attr_modules.get(name):
            module, sub = file.imports[base]
            target = (f"{module}.{sub}" if sub else module, name)
        if target is None:
            return None
        module, orig = target
        owner = self._module(module)
        if owner is None:
            return None
        if orig in owner.imports and orig not in owner.exported and owner is not file:
            return self._source(orig, owner, depth + 1) or (owner, orig)
        return owner, orig

    def _by_var(self, var: str, file: _FileResult | None, depth: int = 0) -> int | None:
        if file is not None and var in file.vars:
            return file.vars[var]
        src = self._source(var, file) if depth < 3 else None
        if src is not None and src[0] is not file:
            hit = self._by_var(src[1], src[0], depth + 1)
            if hit is not None:
                return hit
        found = self.global_vars.get(var) or set()
        if len(found) == 1:
            return next(iter(found))
        if file is not None and var in file.aliases and depth < 3:
            return self._by_var(file.aliases[var], file, depth + 1)
        return None

    def _by_label(self, label: str, file: str) -> int | None:
        hits = self.labels.get(_slug(label)) or set()
        local = [i for i in hits if self.raws[i].file == file]
        if len(local) == 1:
            return local[0]
        return next(iter(hits)) if len(hits) == 1 else None

    def resolve(self, ref: Ref, raw: _Raw) -> list[int]:
        kind, value = ref
        file = self.file_of.get(raw.idx)
        if kind == "idx":
            return [value]
        if kind == "var":
            hit = self._by_var(value, file)
            return [hit] if hit is not None else []
        if kind == "label":
            hit = self._by_label(value, raw.file)
            return [hit] if hit is not None else []
        if kind == "class":
            return [
                r.idx
                for r in self.raws.values()
                if r.file == raw.file and r.cls == value and r.kind == "agent" and r.idx != raw.idx
            ]
        return []

    def _tool_names(
        self, ref: tuple[str, str], file: _FileResult | None, depth: int = 0
    ) -> list[str]:
        """The tool names a reference stands for: a name, a variable holding a tool,
        or a list (a module-level variable or a helper's return) another file holds.
        In this file first, then by a name exactly one file defines. A list or helper
        that cannot be found adds nothing rather than a tool named after it."""
        kind, value = ref
        if kind == "name":
            return [value]
        if depth > 4:
            return []
        if kind == "var":
            if file is not None and value in file.tool_defs:
                return [file.tool_defs[value]]
            if file is not None and value in file.tool_lists:
                return self._expand(file.tool_lists[value], file, depth)
            src = self._source(value, file)
            if src is not None:
                owner, orig = src
                if orig in owner.tool_defs:
                    return [owner.tool_defs[orig]]
                if orig in owner.tool_lists:
                    return self._expand(owner.tool_lists[orig], owner, depth)
            found = self.global_tools.get(value) or set()
            if len(found) == 1:
                return [next(iter(found))]
            owners = self.global_lists.get(value)
            if owners:
                if len(owners) > 1:
                    return []
                return self._expand(owners[0].tool_lists[value], owners[0], depth)
            return [value]
        if kind in ("call", "list"):
            src = self._source(value, file)
            if src is not None:
                owner, orig = src
                found_refs = (owner.tool_helpers if kind == "call" else owner.tool_lists).get(orig)
                if found_refs is not None:
                    return self._expand(found_refs, owner, depth)
        if kind == "call":
            if file is not None and value in file.tool_helpers:
                return self._expand(file.tool_helpers[value], file, depth)
            owners = self.global_helpers.get(value) or []
            if len(owners) == 1:
                return self._expand(owners[0].tool_helpers[value], owners[0], depth)
        if kind == "list":
            lists = self.global_lists.get(value) or []
            if len(lists) == 1:
                return self._expand(lists[0].tool_lists[value], lists[0], depth)
        return []

    def _expand(
        self, refs: list[tuple[str, str]], file: _FileResult | None, depth: int
    ) -> list[str]:
        return [n for r in refs for n in self._tool_names(r, file, depth + 1)]

    def _tools_of(self, idx: int) -> list[str]:
        raw = self.raws[idx]
        file = self.file_of.get(idx)
        refs = [(t, file) for t in raw.tools] + self.extra_tools.get(idx, [])
        for inner, outer in self.merged.items():
            if outer == idx:
                inner_file = self.file_of.get(inner)
                refs = [(t, inner_file) for t in self.raws[inner].tools] + refs
        return list(dict.fromkeys(n for t, f in refs for n in self._tool_names(t, f)))

    def _model_of(self, idx: int) -> str | None:
        """The agent's model as its own file reads it, else an imported constant that
        exactly one file defines. Never another agent's or a repository-wide guess."""
        raw = self.raws[idx]
        model, var = raw.model, raw.model_var
        if model is None and var is None:
            for inner, outer in self.merged.items():
                if outer == idx:
                    model, var = self.raws[inner].model, self.raws[inner].model_var
        if model is None and var is not None:
            src = self._source(var, self.file_of.get(idx))
            if src is not None and src[1] in src[0].consts:
                return src[0].consts[src[1]]
            found = self.global_consts.get(var) or set()
            model = next(iter(found)) if len(found) == 1 else None
        return model

    def _details(self, idx: int, tools: list[str]) -> list[dict[str, Any]]:
        file = self.file_of.get(idx)
        out: list[dict[str, Any]] = []
        for name in tools:
            info = file.tool_info.get(name) if file is not None else None
            fn = file.tool_fn.get(name) if file is not None else None
            for pool in (self.global_info.get(name, []), self.global_funcs.get(fn or "", [])):
                found = {(d, tuple(a)) for d, a in pool}
                if info is None and len(found) == 1:
                    doc, args = next(iter(found))
                    info = (doc, list(args))
            if info is not None:
                out.append({"name": name, "description": info[0], "args": list(info[1])})
        return out

    def _new_raw(self, **kw: Any) -> _Raw:
        raw = _Raw(idx=self.next_idx, **kw)
        self.next_idx += 1
        self.raws[raw.idx] = raw
        return raw

    def _local_framework(self, raw: _Raw) -> str | None:
        """The label for an agent whose constructor or base class is the repository's
        own (``from agents.agent import Agent`` with an ``agents/agent.py`` here, or
        ``class Orchestrator(BaseAgent)`` from a local ``a2a_mcp`` package): the
        provider or protocol that module, or the agent's own file, talks to; "custom"
        when neither says. None when the module is not the repository's."""
        module, _, name = (raw.origin or "").rpartition(".")
        if not module:
            return None
        own = self.file_of.get(raw.idx)
        local = [
            f
            for f in self.modules.get(module) or []
            if f is not own and (name in f.classes or name in f.functions or name in f.imports)
        ]
        if not local:
            return None
        for f in [local[0], *([own] if own else [])]:
            roots = {module.split(".")[0] for module, _name in f.imports.values()}
            dotted = {module for module, _name in f.imports.values()}
            for prefix, label in _LOCAL_AGENT_PROVIDERS:
                if prefix in roots or any(d.startswith(f"{prefix}.") for d in dotted):
                    return label
        return "custom"

    def run(self) -> tuple[list[AgentSpec], list[AgentEdge]]:
        for raw in self.raws.values():
            if (local := self._local_framework(raw)) is not None:
                raw.framework = local
                raw.confidence = "medium" if raw.confidence == "high" else raw.confidence
                raw.default_model = False  # no framework default: its own class picks
        for raw in self.raws.values():
            if raw.name and raw.extends is None:
                self.labels[_slug(raw.name)].add(raw.idx)
        self._merge_executors()
        edges: list[tuple[int, int, str]] = []
        #: (parent, child) of an ``as_tool`` edge -> the tool name the parent calls.
        edge_tools: dict[tuple[int, int], str] = {}
        for raw in list(self.raws.values()):
            owners = [raw.idx]
            if raw.extends is not None:
                # `a.handoffs.append(x)`: x is resolved where the line is, joined to `a`.
                owners = [
                    i for i in self.resolve(raw.extends, raw) if self.raws[i].extends is None
                ][:1]
                for owner in owners:
                    file = self.file_of.get(raw.idx)
                    self.extra_tools[owner].extend((t, file) for t in raw.tools)
            for ref, relation in raw.children:
                for child in self.resolve(ref, raw):
                    edges.extend((owner, child, relation) for owner in owners)
                    if relation == "as_tool":
                        tool = raw.child_tools.get(ref) or _as_tool_name(self.raws[child])
                        for owner in owners:
                            if tool:
                                edge_tools[(owner, child)] = tool
        edges.extend(self._graphs())
        edges.extend(self._crew_managers())
        edges = self._fold_groupchats(edges)
        edges.extend(self._crew_delegation(edges))
        edges = [(self.merged.get(p, p), self.merged.get(c, c), r) for p, c, r in edges]
        edge_tools = {
            (self.merged.get(p, p), self.merged.get(c, c)): t for (p, c), t in edge_tools.items()
        }

        # Orchestrators (crews, teams, graphs) are reported only when they run agents.
        parents = {p for p, _, _ in edges}
        for raw in self.raws.values():
            if raw.kind in ("crew", "team", "graph") and raw.idx not in parents:
                raw.dropped = True
        # A hand-written loop is an agent only when nothing else is.
        if any(not r.dropped and not r.loop for r in self.raws.values()):
            for raw in self.raws.values():
                raw.dropped = raw.dropped or raw.loop
        live = {i for i, r in self.raws.items() if not r.dropped}

        keys = self._keys([self.raws[i] for i in sorted(live, key=self._order)])
        specs = []
        for i in sorted(live, key=self._order):
            raw = self.raws[i]
            module = self.file_of[i].module if i in self.file_of else None
            tools = self._tools_of(i)
            model = self._model_of(i)
            specs.append(
                AgentSpec(
                    key=keys[i],
                    name=raw.name or keys[i],
                    framework=raw.framework,
                    kind=raw.kind,
                    file=raw.file,
                    line=raw.line,
                    tools=tools,
                    model=model,
                    default_model=model is None and raw.default_model,
                    module=module if raw.attr else None,
                    attr=raw.attr if module else None,
                    attr_kind=raw.attr_kind if module and raw.attr else None,
                    tool_details=self._details(i, tools),
                    named=raw.named,
                    instructions=raw.instructions,
                    confidence=raw.confidence,
                    evidence=raw.evidence,
                    var=raw.var,
                )
            )
        seen: set[tuple[int, int]] = set()
        out_edges: list[AgentEdge] = []
        rank = {r: n for n, r in enumerate(RELATIONS)}
        for parent, child, relation in sorted(edges, key=lambda e: rank.get(e[2], 9)):
            if parent == child or parent not in live or child not in live:
                continue
            if (parent, child) in seen:
                continue
            seen.add((parent, child))
            out_edges.append(
                AgentEdge(
                    keys[parent],
                    keys[child],
                    relation,
                    tool=edge_tools.get((parent, child)) if relation == "as_tool" else None,
                )
            )
        out_edges.sort(key=lambda e: (e.parent, e.child))
        return specs, out_edges

    def _order(self, idx: int) -> tuple[str, int, int]:
        raw = self.raws[idx]
        return (raw.file, raw.line, idx)

    def _keys(self, raws: list[_Raw]) -> dict[int, str]:
        """A unique, stable key per agent: its name, then its file when two share one."""
        base = {r.idx: _slug(r.name or f"{Path(r.file).stem}-{r.kind}") for r in raws}
        counts: dict[str, int] = defaultdict(int)
        for key in base.values():
            counts[key] += 1
        out: dict[int, str] = {}
        used: set[str] = set()
        for raw in raws:
            key = base[raw.idx]
            if counts[key] > 1:
                key = f"{key}-{_slug(Path(raw.file).stem)}"
            candidate, n = key, 2
            while candidate in used:
                candidate, n = f"{key}-{n}", n + 1
            used.add(candidate)
            out[raw.idx] = candidate
        return out

    def _graphs(self) -> list[tuple[int, int, str]]:
        edges: list[tuple[int, int, str]] = []
        for f in self.files:
            for graph in f.graphs:
                graph_raw = self.raws[graph.raw]
                agents: dict[str, int] = {}
                for name, node in graph.nodes.items():
                    hit: int | None = None
                    if node.ref is not None:
                        found = self.resolve(node.ref, graph_raw)
                        hit = found[0] if found and found[0] != graph.raw else None
                    if hit is None and node.func is not None:
                        # A node function that runs an agent stands for that agent.
                        found_ids = {
                            i
                            for n in node.loads
                            if (i := self._by_var(n, f)) is not None
                            and i != graph.raw
                            and self.raws[i].kind != "graph"
                        }
                        if len(found_ids) == 1:
                            hit = found_ids.pop()
                    if hit is None and node.bound_tools is not None:
                        # A node that binds tools to a model is an agent of its own.
                        hit = self._new_raw(
                            framework="LangGraph",
                            kind="agent",
                            file=graph_raw.file,
                            line=node.func.lineno if node.func else graph_raw.line,
                            name=name,
                            tools=node.bound_tools,
                        ).idx
                        self.file_of[hit] = f
                    if hit is not None:
                        agents[name] = hit
                # A node that routes to agent nodes is their supervisor, whatever it is.
                for src, dst, how in graph.routes:
                    if (
                        how == "route"
                        and dst in agents
                        and src not in agents
                        and src in graph.nodes
                    ):
                        node = graph.nodes[src]
                        agents[src] = self._new_raw(
                            framework="LangGraph",
                            kind="supervisor",
                            file=graph_raw.file,
                            line=node.func.lineno if node.func else graph_raw.line,
                            name=src,
                        ).idx
                        self.file_of[agents[src]] = f
                routed = {
                    (agents[s], agents[d])
                    for s, d, how in graph.routes
                    if how == "route" and s in agents and d in agents and s != d
                }
                # A worker that hands control back (`Command(goto="supervisor")`) is
                # returning, not delegating: of a pair routing both ways, the side that
                # routes to more agents is the supervisor. A tie is a pair of peers.
                fan_out: dict[int, int] = defaultdict(int)
                for parent, _ in routed:
                    fan_out[parent] += 1
                routed = {
                    (a, b) for a, b in routed if not ((b, a) in routed and fan_out[b] > fan_out[a])
                }
                has_parent: set[int] = set()
                for parent, child in routed:
                    edges.append((parent, child, "delegates"))
                    has_parent.add(child)
                for src, dst, how in graph.routes:
                    if how != "edge" or src not in agents or dst not in agents or src == dst:
                        continue
                    a, b = agents[src], agents[dst]
                    if (b, a) in routed or (a, b) in routed:
                        continue  # a worker returning to its supervisor
                    edges.append((a, b, "handoff"))
                    has_parent.add(b)
                distinct = list(dict.fromkeys(agents.values()))
                if not distinct and graph.llm_nodes:
                    # Nodes that call a model but bind no tools: the graph is one
                    # workflow agent (it reasons step by step; it does not pick tools).
                    graph_raw.kind = "agent"
                    graph_raw.confidence = "medium"
                    n, total = graph.llm_nodes, len(graph.nodes)
                    graph_raw.evidence = f"LangGraph workflow: {n} of {total} nodes call a model"
                    continue
                if (
                    not distinct
                    and len(graph.nodes) > 1
                    and all(node.func is None for node in graph.nodes.values())
                ):
                    # Every node is built elsewhere (a factory, another module): what the
                    # nodes do is not followed, but a graph of them is still an agent.
                    graph_raw.kind = "agent"
                    graph_raw.confidence = "low"
                    graph_raw.evidence = (
                        f"LangGraph graph of {len(graph.nodes)} nodes defined in other code"
                    )
                    continue
                if (
                    len(distinct) == 1
                    and self.raws[distinct[0]].file == graph_raw.file
                    and not routed
                ):
                    # A graph around exactly one agent is that agent: reported once,
                    # under the graph's name and entry point.
                    only = self.raws[distinct[0]]
                    if graph_raw.name:
                        only.name = graph_raw.name
                        only.named = graph_raw.named or only.named
                    if graph_raw.attr:
                        only.attr, only.attr_kind = graph_raw.attr, graph_raw.attr_kind
                    continue
                for idx in distinct:
                    if idx not in has_parent:
                        edges.append((graph.raw, idx, "member"))
        return edges

    def _merge_executors(self) -> None:
        """LangChain: ``AgentExecutor(agent=x, tools=...)`` runs the agent ``x`` builds,
        so the two are one agent, reported as the executor (what is invoked), with the
        tools and model of both."""
        for raw in list(self.raws.values()):
            if raw.wraps is None:
                continue
            inner = [i for i in self.resolve(raw.wraps, raw) if i != raw.idx]
            if len(inner) == 1 and self.raws[inner[0]].kind == "agent":
                self.merged[inner[0]] = raw.idx
                self.raws[inner[0]].dropped = True

    def _fold_groupchats(self, edges: list[tuple[int, int, str]]) -> list[tuple[int, int, str]]:
        """AG2: a GroupChatManager runs a GroupChat; the chat's members are its own."""
        for raw in self.raws.values():
            if raw.absorbs is None:
                continue
            for group in self.resolve(raw.absorbs, raw):
                members = [(p, c, r) for p, c, r in edges if p == group]
                if not members:
                    continue
                self.raws[group].dropped = True
                edges = [e for e in edges if e[0] != group and e[1] != group]
                edges.extend((raw.idx, c, "delegates") for _, c, _ in members)
        return edges

    def _crew_members(self, crew: _Raw) -> list[int]:
        return [i for ref in crew.members for i in self.resolve(ref, crew)]

    def _crew_managers(self) -> list[tuple[int, int, str]]:
        """CrewAI: a crew runs its ``manager_agent``, who delegates to every member."""
        out: list[tuple[int, int, str]] = []
        for crew in list(self.raws.values()):
            if crew.manager is None:
                continue
            members = self._crew_members(crew)
            for manager in self.resolve(crew.manager, crew):
                out.append((crew.idx, manager, "member"))
                out.extend((manager, m, "delegates") for m in members if m != manager)
        return out

    def _crew_delegation(self, edges: list[tuple[int, int, str]]) -> list[tuple[int, int, str]]:
        """CrewAI: an agent with ``allow_delegation=True`` may hand work to any crewmate."""
        out: list[tuple[int, int, str]] = []
        crews: dict[int, list[int]] = defaultdict(list)
        for parent, child, _ in edges:
            if self.raws[parent].kind == "crew":
                crews[parent].append(child)
        for crew in self.raws.values():
            if crew.manager is not None:
                crews[crew.idx] = self._crew_members(crew)
        for members in crews.values():
            for member in members:
                if self.raws[member].allow_delegation:
                    out.extend((member, other, "delegates") for other in members if other != member)
        return out


def _slug(value: str) -> str:
    """The key form of a name the code gives (:func:`agentfox.core.naming.slug`, the one
    the registry and `auto()` use too): `GameBuilderCrew`, `game_builder_crew` and
    "Game builder crew" are one key."""
    return naming.slug(value)


def agent_key(name: str, file: str, taken: set[str]) -> str:
    """A key for an agent found outside this module (a hosted platform's definition),
    unique among ``taken``: its name, then its file's stem, then a counter."""
    key = _slug(name)
    if key in taken:
        key = f"{key}-{_slug(Path(file).stem)}"
    candidate, n = key, 2
    while candidate in taken:
        candidate, n = f"{key}-{n}", n + 1
    return candidate
