"""Recurring work: the part that fills the job queue.

The cron endpoint (`/api/internal/jobs/run`) used to drain only jobs someone had already
enqueued, so nothing periodic — control recomputation, drift checks, canary advancement,
posture campaigns — could run unattended at all. A `JobSchedule` row per tenant per kind
is what now puts that work on the queue; the same cron call then drains it.

Two functions:

* :func:`ensure_default_schedules` creates the default rows for the session's tenant,
  once. It never touches a row that already exists, so an operator who disabled or
  retuned a schedule keeps that choice.
* :func:`enqueue_due` enqueues one job for every enabled schedule whose `next_due_at`
  has passed, then moves `next_due_at` a full interval past *now*. A cron that fires
  late by several intervals enqueues once, not once per missed interval, and a schedule
  whose previous job is still `pending` or `running` enqueues nothing — a slow or
  failing job cannot pile copies of itself onto the queue.

Everything is gated by `settings.scheduler_enabled`.

Default schedules (per tenant)
------------------------------

======================  =========  ========  ===================================================
kind                    interval   enabled   why
======================  =========  ========  ===================================================
``canary.advance``      1 hour     yes       Drives every rolling policy canary through the
                                             two-way gate. Rollback is immediate; advancing
                                             still needs `min_dwell_seconds` at each step.
``compliance.recompute``  1 day    yes       Keeps control status current (30-day window)
                                             without someone pressing "compute".
``drift.check``         1 day      yes       Persists drift windows and drift findings
                                             (groundedness) — the write `GET /api/eval/drift`
                                             no longer does.
``redteam.posture``     7 days     no        Adaptive red-team campaign per active agent. Off
                                             by default: it is the most expensive job and
                                             files findings, so a tenant opts in.
======================  =========  ========  ===================================================

`eval.run` has a handler but no default schedule: it needs a suite and a target that
only the tenant can name. Add a `JobSchedule` row with that payload to run one on a
cadence.
"""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import jobs_db
from .config import get_settings
from .improvement.contract import AUTOMATION_ACTOR_TYPE
from .jobs import PENDING, RUNNING
from .models import Agent, Job, JobSchedule, Policy, User, utcnow
from .tenancy import bind_session, session_org, system_scope

HOUR = 3600
DAY = 24 * HOUR


@dataclass(frozen=True)
class DefaultSchedule:
    kind: str
    interval_seconds: int
    enabled: bool
    payload: dict[str, Any] = field(default_factory=dict)
    why: str = ""


DEFAULT_SCHEDULES: tuple[DefaultSchedule, ...] = (
    DefaultSchedule(
        "canary.advance",
        HOUR,
        True,
        {},
        "advance, hold or roll back every rolling canary through the two-way gate",
    ),
    DefaultSchedule(
        "compliance.recompute",
        DAY,
        True,
        {"window_days": 30},
        "keep control status current",
    ),
    DefaultSchedule(
        "drift.check",
        DAY,
        True,
        {"scorer": "groundedness"},
        "persist drift windows and findings",
    ),
    DefaultSchedule(
        "tuning.propose",
        DAY,
        True,
        {"days": 30},
        "file rule cut-off proposals from labelled false positives; a person decides each",
    ),
    DefaultSchedule(
        "redteam.posture",
        7 * DAY,
        False,
        {"budget": 3, "seed": 1337},
        "adaptive red-team posture per agent; expensive, opt-in",
    ),
)


def _aware(value: dt.datetime | None) -> dt.datetime | None:
    if value is None:
        return None
    return value.replace(tzinfo=dt.UTC) if value.tzinfo is None else value


def ensure_default_schedules(session: Session, *, created_by: str = "") -> list[JobSchedule]:
    """Create any default schedule the session's tenant does not have yet.

    Returns the rows created (empty when every default already exists). A new row is
    due immediately (`next_due_at=None`), so the first cron run after a tenant appears
    does the work rather than waiting a full interval.
    """
    existing = set(session.scalars(select(JobSchedule.kind)))
    created: list[JobSchedule] = []
    for default in DEFAULT_SCHEDULES:
        if default.kind in existing:
            continue
        row = JobSchedule(
            kind=default.kind,
            payload_json=dict(default.payload),
            interval_seconds=default.interval_seconds,
            enabled=default.enabled,
            next_due_at=None,
            created_by=created_by or get_settings().improvement_actor_id,
        )
        session.add(row)
        created.append(row)
    if created:
        session.flush()
    return created


def _has_open_job(session: Session, schedule: JobSchedule) -> bool:
    return (
        session.scalar(
            select(Job.id)
            .where(Job.schedule_id == schedule.id, Job.status.in_((PENDING, RUNNING)))
            .limit(1)
        )
        is not None
    )


def enqueue_due(session: Session, now: dt.datetime | None = None) -> list[Job]:
    """Enqueue one job per enabled, due schedule in the session's bound tenant.

    Returns the jobs enqueued. No-op when `settings.scheduler_enabled` is false.
    """
    settings = get_settings()
    if not settings.scheduler_enabled:
        return []
    now = now or utcnow()
    org_id = session_org(session)
    enqueued: list[Job] = []
    schedules = session.scalars(
        select(JobSchedule).where(JobSchedule.enabled.is_(True)).order_by(JobSchedule.kind)
    )
    for schedule in list(schedules):
        due_at = _aware(schedule.next_due_at)
        if due_at is not None and due_at > now:
            continue
        if _has_open_job(session, schedule):
            # The previous run has not finished (or is waiting out its backoff). Leave
            # next_due_at alone so the schedule is picked up once that job settles.
            continue
        payload = dict(schedule.payload_json or {})
        payload.setdefault("actor_type", AUTOMATION_ACTOR_TYPE)
        payload.setdefault("requested_by", settings.improvement_actor_id)
        job = jobs_db.enqueue(
            session,
            schedule.kind,
            payload,
            org_id=org_id,
            requested_by=f"schedule:{schedule.id}",
            schedule_id=schedule.id,
        )
        schedule.last_enqueued_at = now
        schedule.next_due_at = now + dt.timedelta(seconds=max(1, int(schedule.interval_seconds)))
        enqueued.append(job)
    if enqueued:
        session.flush()
    return enqueued


def known_tenants(session: Session) -> list[str]:
    """Every tenant with users, agents, policies or schedules — the ones a cron run
    should create default schedules for and enqueue due work in."""
    orgs: set[str] = set()
    with system_scope("scheduler: enumerating tenants to enqueue recurring work"):
        for model in (User, Agent, Policy, JobSchedule):
            orgs.update(o for o in session.scalars(select(model.org_id).distinct()) if o)
    return sorted(orgs)


def schedule_all_tenants(session: Session, now: dt.datetime | None = None) -> dict[str, int]:
    """The cron's scheduling pass: per tenant, ensure defaults then enqueue due work.

    Follows `jobs_db.run_pending`'s pattern — enumerate across tenants inside
    `system_scope`, then bind the session to each tenant before touching its rows, so
    every schedule and job lands in the tenant it belongs to. Returns {org_id: jobs
    enqueued}.
    """
    if not get_settings().scheduler_enabled:
        return {}
    now = now or utcnow()
    out: dict[str, int] = {}
    for org_id in known_tenants(session):
        bind_session(session, org_id)
        ensure_default_schedules(session)
        out[org_id] = len(enqueue_due(session, now))
    return out
