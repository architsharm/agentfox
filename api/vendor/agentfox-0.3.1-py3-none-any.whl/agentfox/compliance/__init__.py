"""Pillar 6 — Policy & Compliance Management.

Appendix A.5's coverage map ends here: OSS coverage for this pillar is *essentially
none*, because mapping controls to regimes needs product integration and domain work
rather than a library. That is precisely why it is the moat.
"""

from . import catalog, risk, status
from .catalog import (
    FRAMEWORK_TITLES,
    all_frameworks,
    controls_for_framework,
    framework_coverage,
    load_catalog,
    review_mapping,
    sync_catalog,
    sync_obligations,
)
from .risk import assess, board_view, classify, obligation_calendar, register
from .status import (
    compute_all,
    ensure_compliance_computed,
    evaluate_control,
    latest_statuses,
    posture,
)

__all__ = [
    "FRAMEWORK_TITLES",
    "all_frameworks",
    "assess",
    "board_view",
    "catalog",
    "classify",
    "compute_all",
    "ensure_compliance_computed",
    "controls_for_framework",
    "evaluate_control",
    "framework_coverage",
    "latest_statuses",
    "load_catalog",
    "obligation_calendar",
    "posture",
    "register",
    "review_mapping",
    "risk",
    "status",
    "sync_catalog",
    "sync_obligations",
]
