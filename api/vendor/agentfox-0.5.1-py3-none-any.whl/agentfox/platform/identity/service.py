"""Pillar 2 — non-human identity, least privilege, delegation, approvals.

The state of this layer: *"engines yes, agent-native no"*. OPA and Cedar
solve the decision problem; nobody has modelled the thing that actually matters for
agents — an identity whose capabilities are scoped per tool, per action, per
argument value, **and per the provenance of that argument**. That last clause is
what this module adds on top of the engine.

Three properties are enforced here rather than documented:

* **Default deny.** No matching capability means denied, not allowed.
* **Narrowing on delegation.** A sub-agent's capabilities must be a subset of its
  parent's; widening is rejected at write time, not audited afterwards.
* **Deny on approval timeout.** An approval that nobody answers fails closed.
"""

from __future__ import annotations

import datetime as dt
import fnmatch
import hashlib
import json
import secrets
from dataclasses import dataclass, field
from typing import Any

from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from agentfox.core.config import get_settings
from agentfox.core.models import (
    Agent,
    ApprovalRequest,
    Capability,
    Credential,
    DelegationEdge,
    Finding,
    Identity,
    as_aware,
    utcnow,
)
from agentfox.core.vocab import COMPARATORS, taint_rank
from agentfox.platform.identity.keyhash import check_key, hash_key
from agentfox.platform.ledger.findings import auto_resolve, raise_finding

AGENT_KEY_PREFIX = "nom_agt_"
API_KEY_PREFIX = "nom_api_"

#: A credential unused for this long is posture-flagged as stale.
STALE_AFTER_DAYS = 30


# ---------------------------------------------------------------------------
# Identity & credentials
# ---------------------------------------------------------------------------


def ensure_identity(session: Session, agent: Agent, principal: str | None = None) -> Identity:
    principal = principal or f"agent:{agent.slug}"
    identity = session.scalar(select(Identity).where(Identity.principal == principal))
    if identity is None:
        # A savepoint, because a new agent's first calls arrive together (an attack
        # test checks eight at once) and the loser of that insert race must find the
        # winner's row, not fail the call or roll back the session.
        try:
            with session.begin_nested():
                identity = Identity(agent_id=agent.id, principal=principal, kind="agent")
                session.add(identity)
                session.flush()
        except IntegrityError:
            identity = session.scalar(select(Identity).where(Identity.principal == principal))
    return identity


def issue_credential(
    session: Session,
    identity: Identity,
    ttl_days: int | None = 90,
    rotated_from: str | None = None,
) -> tuple[Credential, str]:
    """Issue a key. The plaintext exists only in this return value."""
    raw = AGENT_KEY_PREFIX + secrets.token_urlsafe(32).replace("-", "").replace("_", "")[:40]
    credential = Credential(
        identity_id=identity.id,
        key_prefix=raw[: len(AGENT_KEY_PREFIX) + 8],
        key_hash=hash_key(raw),
        expires_at=utcnow() + dt.timedelta(days=ttl_days) if ttl_days else None,
        rotated_from_id=rotated_from,
    )
    session.add(credential)
    session.flush()
    return credential, raw


def verify_credential(session: Session, raw_key: str) -> Identity | None:
    """Resolve a presented key to its identity, or None.

    Lookup is narrowed by prefix so verification is one hash check in the common
    case rather than one per stored credential.
    """
    if not raw_key:
        return None
    prefix = raw_key[: len(AGENT_KEY_PREFIX) + 8]
    candidates = session.scalars(select(Credential).where(Credential.key_prefix == prefix)).all()
    for credential in candidates:
        if not credential.active:
            continue
        matches, upgraded = check_key(credential.key_hash, raw_key)
        if not matches:
            continue
        if upgraded:
            credential.key_hash = upgraded
        credential.last_used_at = utcnow()
        identity = session.get(Identity, credential.identity_id)
        if identity is None or identity.status != "active":
            return None
        identity.last_used_at = utcnow()
        session.flush()
        return identity
    return None


def rotate_credential(
    session: Session, identity: Identity, overlap_hours: int = 24
) -> tuple[Credential, str]:
    """Issue a replacement and expire the old key after an overlap window.

    Revoking immediately would mean every rotation is an outage, which is how
    rotation policies end up never being applied.
    """
    new_credential, raw = issue_credential(session, identity)
    cutoff = utcnow() + dt.timedelta(hours=overlap_hours)
    for credential in session.scalars(
        select(Credential).where(
            Credential.identity_id == identity.id,
            Credential.id != new_credential.id,
            Credential.revoked_at.is_(None),
        )
    ):
        if credential.expires_at is None or credential.expires_at > cutoff:
            credential.expires_at = cutoff
    new_credential.rotated_from_id = None
    session.flush()
    return new_credential, raw


def revoke_credential(session: Session, credential_id: str) -> bool:
    credential = session.get(Credential, credential_id)
    if credential is None:
        return False
    credential.revoked_at = utcnow()
    session.flush()
    return True


# ---------------------------------------------------------------------------
# Capabilities
# ---------------------------------------------------------------------------


#: Constraint keys that configure the grant rather than naming an argument path.
#: Why a call is held when the grant itself asks for a person on every call. A taint
#: ceiling holds a call for a different reason and says so (`taint_violation`).
APPROVAL_REQUIRED_REASON = "This tool is allowed only with a person's approval."

RESERVED_CONSTRAINTS = frozenset({"requires_verified_state", "dry_run_only"})


@dataclass
class CapabilityDecision:
    granted: bool = False
    requires_approval: bool = False
    matched_capability_id: str | None = None
    reasons: list[str] = field(default_factory=list)
    constraint_violations: list[str] = field(default_factory=list)
    #: A sentence a person can read, naming the grant, the declared limit and the
    #: value that failed it. Empty unless `constraint_violations` is populated.
    constraint_reason: str = ""
    max_taint: str = "none"
    taint_violation: str | None = None
    #: The matched grant's constraints, carried forward so downstream gates (verified
    #: state) can read them without a second lookup.
    constraints: dict[str, Any] = field(default_factory=dict)

    @property
    def state(self) -> str:
        """``denied`` means *no grant exists*. A grant that exists and was exceeded
        is a different fact and gets a different name, because reporting it as
        default deny tells the caller to go and ask for a permission they already
        hold — and contradicts the grant sitting in the same response.
        """
        if not self.granted:
            return "constraint_violated" if self.constraint_violations else "denied"
        return "requires_approval" if self.requires_approval else "granted"

    def to_json(self) -> dict[str, Any]:
        return {
            "granted": self.granted,
            "requires_approval": self.requires_approval,
            "state": self.state,
            "capability_id": self.matched_capability_id,
            "reasons": self.reasons,
            "constraint_violations": self.constraint_violations,
            "constraint_reason": self.constraint_reason,
            "max_taint": self.max_taint,
            "taint_violation": self.taint_violation,
            "constraints": self.constraints,
        }


def grant_capability(
    session: Session,
    identity: Identity,
    tool_key: str,
    actions: list[str] | None = None,
    constraints: dict[str, Any] | None = None,
    requires_approval: bool = False,
    max_taint: str = "user",
    granted_by: str = "system",
    expires_at: dt.datetime | None = None,
) -> Capability:
    capability = Capability(
        identity_id=identity.id,
        tool_key=tool_key,
        actions=actions or ["*"],
        constraints_json=constraints or {},
        requires_approval=requires_approval,
        max_taint=max_taint,
        granted_by=granted_by,
        expires_at=expires_at,
    )
    session.add(capability)
    session.flush()
    return capability


def revoke_capability(session: Session, capability_id: str) -> Capability | None:
    """Remove a grant. Returns the row that was removed, or None if there was none.

    The row is deleted rather than flagged, so a count of capabilities is a count of
    what an agent may actually do right now — the number `agentfox doctor` reports.
    The history is not lost: the caller writes the removal to the audit chain, which
    is append-only and keeps the full shape of the grant that was withdrawn.
    """
    capability = session.get(Capability, capability_id)
    if capability is None:
        return None
    session.delete(capability)
    session.flush()
    return capability


def _constraint_ok(value: Any, spec: Any) -> tuple[bool, str]:
    """``{"lt": 1000}``, ``{"in": ["USD"]}``, or a bare literal for equality."""
    if not isinstance(spec, dict):
        return (value == spec, f"expected {spec!r}, got {value!r}")
    for op, expected in spec.items():
        fn = COMPARATORS.get(op)
        if fn is None:
            return False, f"unknown constraint operator '{op}'"
        try:
            if not fn(value, expected):
                return False, f"{value!r} fails {op} {expected!r}"
        except Exception:
            return False, f"{value!r} could not be compared with {op} {expected!r}"
    return True, ""


#: How each comparator reads in a sentence a person has to act on. `lt` is not
#: "fails lt 1000" to anyone outside this file.
_LIMIT_PHRASES = {
    "lt": "below {expected}",
    "lte": "at most {expected}",
    "gt": "above {expected}",
    "gte": "at least {expected}",
    "eq": "exactly {expected}",
    "ne": "anything but {expected}",
    "in": "one of {expected}",
    "not_in": "none of {expected}",
    "contains": "text containing {expected}",
    "matches": "text matching {expected}",
}


def _describe_violation(path: str, spec: Any, value: Any) -> str:
    """One clause: what the grant allows on this argument, and what was asked for.

    Always names the limit and the value that failed it, because "constraints
    violated" tells the reader nothing they can fix.
    """
    if not isinstance(spec, dict):
        allowed = f"exactly {spec!r}"
    else:
        allowed = " and ".join(
            _LIMIT_PHRASES.get(op, f"{op} {{expected}}").format(expected=repr(expected))
            for op, expected in spec.items()
        )
    return f"{path} {allowed}, but this call passed {value!r}"


def default_deny_hint(principal: str | None, tool_key: str) -> str:
    """What to do about a default-deny refusal, in commands rather than concepts.

    Default deny is enforced from the first call — there is no observe grace — so the
    refusal itself has to say how to get out of it. The refused call is recorded with
    its arguments and provenance either way, which is what `proposals from-traffic`
    learns from.
    """
    slug = principal.split(":", 1)[1] if principal and principal.startswith("agent:") else None
    where = f"Agents → {slug} → Access" if slug else "the agent's Access tab"
    command = f"agentfox permit grant {slug or '<agent>'} {tool_key}"
    return f"Allow it in the dashboard ({where}), or run `{command}`."


def holds_any_grant(session: Session, identity: Identity | None) -> bool:
    """Whether anyone has configured least privilege for this identity at all: at
    least one capability row, expired or not.

    ``agentfox.auto()`` (``"policy"`` mode) applies capability default-deny only once
    this is true; before the first grant a refusal that is only a missing grant is
    recorded, not raised. The onboarding attack test's dry run reads the same answer,
    so it never reports a stop live traffic would not make.
    """
    if identity is None:
        return False
    from sqlalchemy import func

    count = session.scalar(
        select(func.count()).select_from(Capability).where(Capability.identity_id == identity.id)
    )
    return bool(count)


def check_capability(
    session: Session,
    identity: Identity | None,
    tool_key: str,
    action: str = "*",
    arguments: dict[str, Any] | None = None,
    argument_taint: dict[str, str] | None = None,
) -> CapabilityDecision:
    """Evaluate least privilege for one tool call (NOM-IAM-02).

    Default deny. Argument constraints and argument *provenance* are both checked,
    which is the agent-native part: a capability may permit ``payments.transfer``
    under 1000 USD and still refuse it when the recipient came from a tool result.
    """
    decision = CapabilityDecision()
    arguments = arguments or {}
    argument_taint = argument_taint or {}

    if identity is None:
        decision.reasons.append(
            f"'{tool_key}' has not been granted to this agent yet (default deny). "
            + default_deny_hint(None, tool_key)
        )
        return decision

    capabilities = session.scalars(
        select(Capability).where(Capability.identity_id == identity.id)
    ).all()
    now = utcnow()
    matches = [
        c
        for c in capabilities
        if fnmatch.fnmatch(tool_key, c.tool_key)
        # SQLite gives a naive datetime back; comparing it to `utcnow` raises, which
        # would turn every *expiring* grant into a crash at decision time.
        and (c.expires_at is None or as_aware(c.expires_at) > now)
        and ("*" in (c.actions or ["*"]) or action in (c.actions or []))
    ]
    if not matches:
        decision.reasons.append(
            f"'{tool_key}' has not been granted to {identity.principal.split(':', 1)[-1]} "
            f"(default deny). {default_deny_hint(identity.principal, tool_key)}"
        )
        return decision

    # Most specific grant wins: an explicit tool key beats a glob.
    capability = sorted(matches, key=lambda c: ("*" in c.tool_key, -len(c.tool_key)))[0]
    decision.matched_capability_id = capability.id
    decision.max_taint = capability.max_taint
    decision.constraints = dict(capability.constraints_json or {})

    violation_clauses: list[str] = []
    for path, spec in (capability.constraints_json or {}).items():
        # Reserved keys configure the grant itself rather than constraining an
        # argument path; treating `requires_verified_state` as a path would look for
        # an argument by that name and fail every call.
        if path in RESERVED_CONSTRAINTS:
            continue
        value = arguments
        for part in path.split("."):
            value = value.get(part) if isinstance(value, dict) else None
        ok, why = _constraint_ok(value, spec)
        if not ok:
            decision.constraint_violations.append(f"{path}: {why}")
            violation_clauses.append(_describe_violation(path, spec, value))

    if decision.constraint_violations:
        # The grant is real and the caller holds it. What failed is a declared limit
        # on an argument, so the refusal names the grant, the limit and the number.
        decision.constraint_reason = " ".join(
            [
                f"{identity.principal} holds a grant for '{capability.tool_key}', so this "
                f"is not a missing permission."
            ]
            + [f"The grant allows {clause}." for clause in violation_clauses]
        )
        decision.reasons.append(decision.constraint_reason)
        return decision

    worst = max(
        (taint_rank(str(s)) for s in argument_taint.values()),
        default=taint_rank("none"),
    )
    if worst > taint_rank(capability.max_taint):
        offending = [
            p
            for p, s in argument_taint.items()
            if taint_rank(str(s)) > taint_rank(capability.max_taint)
        ]
        # The cause is where an argument came from, not the grant: this grant may
        # require no approval at all. Saying "the granting capability requires
        # human approval" sent the reader to a grant that asks for nothing.
        origins = ", ".join(f"{p} from {argument_taint[p]}" for p in offending)
        decision.taint_violation = (
            f"arguments {offending} carry provenance above the capability's "
            f"max_taint '{capability.max_taint}' ({origins}), so a person must approve "
            f"this call before it runs"
        )
        decision.granted = True
        decision.requires_approval = True
        decision.reasons.append(decision.taint_violation)
        return decision

    decision.granted = True
    decision.requires_approval = capability.requires_approval
    if decision.requires_approval:
        decision.reasons.append(APPROVAL_REQUIRED_REASON)
    return decision


#: Stands in for a child glob's wildcard when testing containment. Any character
#: that cannot appear in a tool key works; the point is that `*` must not be allowed
#: to match a parent's *literal* segment, or `*` would look "covered by" `tickets.*`.
_WILDCARD_PROBE = ""


def _covers(parent: Capability, child: Capability) -> bool:
    """True when ``parent`` grants at least everything ``child`` does.

    Glob containment is undecidable in general, so this is a sound approximation:
    substituting the child's wildcard with a character the parent's literal segments
    cannot match means a broader child pattern never tests as covered. It errs
    towards rejecting a delegation, which is the correct direction for an
    authority check.
    """
    probe = child.tool_key.replace("*", _WILDCARD_PROBE)
    if not fnmatch.fnmatch(probe, parent.tool_key):
        return False

    child_actions = set(child.actions or ["*"])
    parent_actions = set(parent.actions or ["*"])
    if "*" not in parent_actions and not child_actions <= parent_actions:
        return False

    # A child may not accept more dangerous argument provenance than its parent.
    if taint_rank(child.max_taint) > taint_rank(parent.max_taint):
        return False

    # A child may not drop an approval requirement the parent imposes.
    if parent.requires_approval and not child.requires_approval:
        return False

    return True


def capability_set(session: Session, identity_id: str) -> set[tuple[str, str]]:
    caps = session.scalars(select(Capability).where(Capability.identity_id == identity_id)).all()
    out: set[tuple[str, str]] = set()
    for c in caps:
        for action in c.actions or ["*"]:
            out.add((c.tool_key, action))
    return out


def delegate(
    session: Session,
    parent: Identity,
    child: Identity,
    trace_id: str | None = None,
) -> DelegationEdge:
    """Record a delegation, rejecting any widening of authority.

    A child capability is permitted only if some parent capability covers it — the
    child's tool pattern must be *at least as narrow* as the parent's.
    """
    parent_caps = session.scalars(
        select(Capability).where(Capability.identity_id == parent.id)
    ).all()
    child_caps = session.scalars(select(Capability).where(Capability.identity_id == child.id)).all()

    widened: list[str] = []
    for cc in child_caps:
        if not any(_covers(pc, cc) for pc in parent_caps):
            widened.append(f"{cc.tool_key}:{','.join(cc.actions or ['*'])}")

    if widened:
        raise ValueError(
            "delegation would widen authority; child holds capabilities the parent "
            f"does not: {widened}"
        )

    edge = DelegationEdge(
        parent_identity_id=parent.id,
        child_identity_id=child.id,
        capability_diff_json={
            "parent": sorted(f"{t}:{a}" for t, a in capability_set(session, parent.id)),
            "child": sorted(f"{t}:{a}" for t, a in capability_set(session, child.id)),
        },
        trace_id=trace_id,
    )
    session.add(edge)
    session.flush()
    return edge


# ---------------------------------------------------------------------------
# Human-in-the-loop approvals
# ---------------------------------------------------------------------------


def request_approval(
    session: Session,
    *,
    agent_id: str | None,
    tool_key: str | None,
    arguments: dict[str, Any],
    reason: str,
    trace_id: str | None = None,
    decision_id: str | None = None,
    ttl_minutes: int | None = None,
    approver_role: str = "security",
) -> ApprovalRequest:
    """Open an approval for a held call — or return the one already waiting for it.

    An agent told its call is held usually tries again, and every retry used to open
    another request: the same refund, four times in the reviewer's queue. The same
    agent asking for the same tool with the same arguments while a request is still
    pending gets that request back.
    """
    if ttl_minutes is None:
        ttl_minutes = int(getattr(get_settings(), "approval_ttl_minutes", 30) or 30)
    now = utcnow()
    waiting = session.scalars(
        select(ApprovalRequest).where(
            ApprovalRequest.agent_id == agent_id,
            ApprovalRequest.tool_key == tool_key,
            ApprovalRequest.status == "pending",
        )
    )
    for existing in waiting:
        expires = existing.expires_at
        if expires is not None and expires.tzinfo is None:
            expires = expires.replace(tzinfo=dt.UTC)
        if (expires is None or expires > now) and (existing.arguments_json or {}) == (
            arguments or {}
        ):
            return existing
    request = ApprovalRequest(
        decision_id=decision_id,
        trace_id=trace_id,
        agent_id=agent_id,
        tool_key=tool_key,
        arguments_json=arguments,
        reason=reason,
        expires_at=utcnow() + dt.timedelta(minutes=ttl_minutes),
        approver_role=approver_role,
        timeout_action="deny",
    )
    session.add(request)
    session.flush()
    return request


class AgentStopped(Exception):
    """An approval cannot be granted while its agent is killed or quarantined."""

    def __init__(self, state: str, slug: str | None) -> None:
        self.state = state
        self.slug = slug
        super().__init__(
            f"agent {slug or ''} is {state}: an approval cannot be granted while the "
            "kill switch is on. Deny it, or resume the agent first."
        )


def _stopped_state(session: Session, agent_id: str | None) -> tuple[str, str | None] | None:
    if not agent_id:
        return None
    from agentfox.core.models import Agent, AgentControl

    control = session.scalar(select(AgentControl).where(AgentControl.agent_id == agent_id))
    if control is None or control.state == "active":
        return None
    agent = session.get(Agent, agent_id)
    return control.state, agent.slug if agent else None


#: How long an approved call stays redeemable once a person approves it. The clock
#: restarts at approval, so a decision made in the 29th minute of a 30-minute wait
#: does not leave the agent seconds to retry.
REDEEM_WINDOW_MINUTES = 30

#: Statuses an approval can have. ``used`` is an approval a retry has redeemed: an
#: approval lets exactly one call through.
APPROVAL_STATUSES = ("pending", "approved", "denied", "expired", "used")


def resolve_approval(
    session: Session,
    approval_id: str,
    approved: bool,
    resolver_user_id: str,
    rationale: str = "",
) -> ApprovalRequest | None:
    """Approve or deny a pending request.

    Approving is refused (:class:`AgentStopped`) while the agent is killed or
    quarantined: the kill switch means the operator has stopped trusting this
    agent, and an approval granted in that window is a standing yes that outlives
    the incident. Denying is always allowed — it only makes things stricter.
    """
    request = session.get(ApprovalRequest, approval_id)
    if request is None or request.status != "pending":
        return request
    expires = as_aware(request.expires_at)
    if expires and expires < utcnow():
        request.status = "expired"
        session.flush()
        return request
    if approved:
        stopped = _stopped_state(session, request.agent_id)
        if stopped is not None:
            raise AgentStopped(*stopped)
    request.status = "approved" if approved else "denied"
    request.resolver_user_id = resolver_user_id
    request.resolution_rationale = rationale
    if approved:
        # From here `expires_at` is how long the approval may be redeemed.
        request.expires_at = utcnow() + dt.timedelta(minutes=REDEEM_WINDOW_MINUTES)
    session.flush()
    return request


def _canonical(arguments: Any) -> str:
    """One spelling of an argument set, so a retry's arguments compare equal to the
    ones a person approved after both have been through JSON."""
    normalised = json.loads(json.dumps(arguments or {}, default=str))
    return json.dumps(normalised, sort_keys=True, separators=(",", ":"))


def content_digest(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8", "replace")).hexdigest()


def _binding(tool_key: str | None, arguments: dict[str, Any] | None) -> str:
    """What an approval is bound to besides the agent: the tool and its arguments.
    A held *message* is bound to its content's digest, which is what the stored
    arguments carry for it (`runtime/enforcement/approvals.py`)."""
    arguments = arguments or {}
    if "content_sha256" in arguments and str(tool_key or "").startswith("message:"):
        return f"{tool_key}|{arguments['content_sha256']}"
    return f"{tool_key}|{_canonical(arguments)}"


def _already_used(approval_id: str) -> str:
    return f"approval '{approval_id}' was already used; each approval lets one call through"


def redeem_approval(
    session: Session,
    approval_id: str,
    *,
    agent_id: str | None,
    tool_key: str | None,
    arguments: dict[str, Any] | None,
) -> tuple[ApprovalRequest | None, str]:
    """Spend an approval on the call it was granted for.

    Returns ``(approval, "")`` when the retry may run, or ``(None, why)`` when it may
    not. An approval lets through one call: the same agent, the same tool and the
    same arguments a person saw, before it expires, once. Anything else is refused
    and the caller escalates as it would have without it, so presenting an approval
    can never make a call *more* permitted than a person said.
    """
    request = session.get(ApprovalRequest, approval_id)
    if request is None:
        return None, f"no approval '{approval_id}' exists"
    if request.status == "used":
        return None, _already_used(approval_id)
    if request.status != "approved":
        return None, f"approval '{approval_id}' is {request.status}, not approved"
    expires = as_aware(request.expires_at)
    if expires and expires < utcnow():
        return None, f"approval '{approval_id}' expired at {expires.isoformat()}"
    if request.agent_id != agent_id:
        return None, f"approval '{approval_id}' was granted to a different agent"
    if (request.tool_key or None) != (tool_key or None):
        return None, (f"approval '{approval_id}' is for '{request.tool_key}', not '{tool_key}'")
    if _binding(request.tool_key, request.arguments_json) != _binding(tool_key, arguments):
        return None, (
            f"approval '{approval_id}' was granted for different arguments than this call's"
        )
    # Conditional on the status still reading `approved`, so two retries racing on
    # one approval cannot both spend it.
    spent = session.execute(
        update(ApprovalRequest)
        .where(ApprovalRequest.id == request.id, ApprovalRequest.status == "approved")
        .values(status="used")
        .execution_options(synchronize_session=False)
    )
    if spent.rowcount != 1:
        return None, _already_used(approval_id)
    session.refresh(request)
    return request, ""


def denial_of(
    session: Session,
    approval_id: str,
    *,
    agent_id: str | None,
    tool_key: str | None,
    arguments: dict[str, Any] | None,
) -> ApprovalRequest | None:
    """The denied approval ``approval_id``, when the retry presenting it is the very
    call a person denied: the same agent, tool and arguments. None otherwise.

    A denial is an answer, not a request to ask again: a retry of the denied call is
    refused with the denial's reason rather than filing a fresh approval that shows a
    reviewer the call they just turned down as if it were new. A different call (other
    arguments, another agent) is not what was denied, and escalates as usual.
    """
    request = session.get(ApprovalRequest, approval_id)
    if request is None or request.status != "denied":
        return None
    if request.agent_id != agent_id or (request.tool_key or None) != (tool_key or None):
        return None
    if _binding(request.tool_key, request.arguments_json) != _binding(tool_key, arguments):
        return None
    return request


def find_approved(
    session: Session,
    *,
    agent_id: str | None,
    tool_key: str | None,
    arguments: dict[str, Any] | None,
) -> str | None:
    """The id of an approval a person granted for exactly this call and nobody has
    spent yet, or None.

    For callers that cannot carry an ``approval_id`` back: a voice platform or a
    gateway retries a tool call with only the tool and its arguments, so after a
    person approves, the retry is matched here and then spent through
    :func:`redeem_approval` like any other, once. Nothing is spent by this lookup.
    """
    if not agent_id or not tool_key:
        return None
    candidates = session.scalars(
        select(ApprovalRequest)
        .where(
            ApprovalRequest.status == "approved",
            ApprovalRequest.agent_id == agent_id,
            ApprovalRequest.tool_key == tool_key,
        )
        .order_by(ApprovalRequest.requested_at.desc())
        .limit(50)
    ).all()
    wanted = _binding(tool_key, arguments)
    now = utcnow()
    for request in candidates:
        expires = as_aware(request.expires_at)
        if expires and expires < now:
            continue
        if _binding(request.tool_key, request.arguments_json) == wanted:
            return request.id
    return None


def expire_stale_approvals(session: Session) -> int:
    """Fail closed: an unanswered approval denies (NOM-IAM-03)."""
    now = utcnow()
    stale = session.scalars(
        select(ApprovalRequest).where(
            ApprovalRequest.status == "pending",
            ApprovalRequest.expires_at.is_not(None),
            ApprovalRequest.expires_at < now,
        )
    ).all()
    for request in stale:
        if request.timeout_action == "deny":
            request.status = "expired"
        else:
            request.status = "approved"
            # Approved by timeout: it gets the same window to be used as one a
            # person approved, or it would lapse the moment it was granted.
            request.expires_at = now + dt.timedelta(minutes=REDEEM_WINDOW_MINUTES)
    # Approved but never used inside its window: it can no longer run, and the
    # history should say so rather than read "approved" forever.
    lapsed = session.scalars(
        select(ApprovalRequest).where(
            ApprovalRequest.status == "approved",
            ApprovalRequest.expires_at.is_not(None),
            ApprovalRequest.expires_at < now,
        )
    ).all()
    for request in lapsed:
        request.status = "lapsed"
    session.flush()
    return len(stale) + len(lapsed)


# ---------------------------------------------------------------------------
# Posture
# ---------------------------------------------------------------------------


#: Every finding type identity posture can raise, so a posture that changed can close
#: the finding for the posture it left.
_POSTURE_FINDING_TYPES = ("orphaned_identity", "stale_identity", "over_privileged")


def assess_posture(session: Session) -> list[Finding]:
    """Flag stale, over-privileged and orphaned identities.

    An identity graph nobody prunes is how agents accumulate the permissions that
    make a single injection catastrophic.
    """
    findings = [
        finding
        for identity in session.scalars(select(Identity))
        if (finding := assess_identity(session, identity)) is not None
    ]
    session.flush()
    return findings


def assess_identity(session: Session, identity: Identity) -> Finding | None:
    """One identity's posture, its finding raised or, if the posture cleared, closed.

    A retired identity (status other than ``active``) cannot authenticate, so it has
    no posture to keep: every posture finding it had closes. A stale identity is one
    nobody has used for the window that *still holds grants*; one with none left can
    do nothing, so it is not flagged.
    """
    cutoff = utcnow() - dt.timedelta(days=STALE_AFTER_DAYS)
    posture = "healthy"
    reasons: list[str] = []
    caps = session.scalars(select(Capability).where(Capability.identity_id == identity.id)).all()

    if identity.status != "active":
        posture = "retired"
    else:
        agent = session.get(Agent, identity.agent_id) if identity.agent_id else None
        if identity.kind == "agent" and (agent is None or agent.status == "retired"):
            posture = "orphaned"
            reasons.append("no active agent owns this identity")

        last_used = identity.last_used_at
        if last_used is not None and last_used.tzinfo is None:
            last_used = last_used.replace(tzinfo=dt.UTC)
        if posture == "healthy" and caps and (last_used is None or last_used < cutoff):
            posture = "stale"
            reasons.append(f"unused for more than {STALE_AFTER_DAYS} days")

        wildcards = [c for c in caps if c.tool_key.strip() == "*"]
        if wildcards:
            posture = "over_privileged"
            reasons.append("holds an unrestricted '*' tool grant")

    identity.posture = posture
    current_type = (
        None
        if posture in ("healthy", "retired")
        else (f"{posture}_identity" if posture != "over_privileged" else "over_privileged")
    )
    # A posture that no longer holds closes its finding: an identity that was stale
    # and has since been used is not stale, whatever the queue still says.
    for posture_type in _POSTURE_FINDING_TYPES:
        if posture_type != current_type:
            auto_resolve(
                session,
                type=posture_type,
                subject_type="identity",
                subject_id=identity.id,
                note=f"identity {identity.principal} is now {posture}",
            )
    if current_type is None:
        return None
    finding, _ = raise_finding(
        session,
        type=current_type,
        severity="high" if posture == "over_privileged" else "medium",
        title=f"Identity {identity.principal} is {posture}",
        subject_type="identity",
        subject_id=identity.id,
        evidence={"reasons": reasons, "capabilities": len(caps)},
        control_keys=["NOM-IAM-01", "NOM-IAM-02"],
    )
    return finding
