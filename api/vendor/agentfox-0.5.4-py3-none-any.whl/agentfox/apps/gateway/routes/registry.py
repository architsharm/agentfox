"""Control-plane routes for Pillars 1 and 2 — registry, identity, approvals."""

from __future__ import annotations

import datetime as dt
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from agentfox.apps.gateway.deps import (
    WRITE_ROLES,
    current_user,
    db,
    get_agent_or_404,
    may_enforce,
    operator_or_agent,
    require,
)
from agentfox.capabilities.onboarding.projects import remove_project
from agentfox.core.models import (
    Agent,
    ApiToken,
    ApprovalRequest,
    Capability,
    Credential,
    Finding,
    Handoff,
    Identity,
    LineageEdge,
    McpServer,
    Tool,
    Trace,
    User,
    utcnow,
)
from agentfox.platform.identity import (
    AgentStopped,
    ApprovalAlreadyDecided,
    assess_posture,
    check_capability,
    expire_stale_approvals,
    grant_capability,
    issue_credential,
    resolve_approval,
    revoke_credential,
    rotate_credential,
)
from agentfox.platform.identity.operators import issue_token
from agentfox.platform.ledger import chain
from agentfox.platform.ledger.findings import STATUSES as FINDING_STATUSES
from agentfox.platform.registry.control import UnknownAgent, all_controls, set_state
from agentfox.platform.registry.projects import list_projects, project_map, project_of
from agentfox.platform.registry.service import (
    assess_delegation,
    attest_registry,
    derive_lineage,
    detect_shadow_agents,
    fold_duplicate_drafts,
    impact_source_of,
    inventory,
    lineage,
    register_agent,
    scan_mcp_server,
    unowned_agents,
    upsert_mcp_server,
    upsert_tool,
)

router = APIRouter(prefix="/api", tags=["registry", "identity"])


@router.get("/projects")
def get_projects(
    session: Session = Depends(db), _user: User = Depends(current_user)
) -> dict[str, Any]:
    """Every project: a multi-agent system (a root agent and every agent it hands work
    to, from code or traffic, across repositories), or one agent on its own.

    ``project`` (= ``root``) is the key the other ``/api/projects/{project}`` routes
    take; ``members`` lists each agent with its ``depth`` under the root and the
    ``relation`` it is reached by; ``repos`` the repositories `agentfox init` mapped
    them from, which those routes also accept."""
    return {"projects": list_projects(session)}


@router.delete("/projects/{project}")
def delete_project(
    project: str, session: Session = Depends(db), user: User = Depends(require("registry"))
) -> dict[str, Any]:
    """Disconnect a project: connecting it again with `agentfox init` starts fresh.

    Acts on the members that came from the same repository (``project`` may be a
    system's root or a repository init mapped); an agent of another project it hands
    work to, and the hand-off itself, stay. Each agent's guardrails are recorded
    before they are emptied (``restorable`` lists who has them), to be put back with
    ``POST /api/agents/{slug}/restore-guardrails``. Its history (traffic, issues,
    audit) is kept."""
    out = remove_project(session, project, actor=user.email or user.id)
    if not out["removed"]:
        raise HTTPException(404, f"No project '{project}'")
    return out


@router.post("/projects/{project}/approve")
def approve_project(
    project: str, session: Session = Depends(db), user: User = Depends(require("registry"))
) -> dict[str, Any]:
    """Add every agent `agentfox init` proposed for this project ("Add all").

    Each gets the same state change and ledger entry as approving it on its own
    (``POST /api/agents/{id}/approve``), and is allowed the tools its own code hands
    it (``registry.service.grant_found_tools``); anything else is still granted per
    tool (``POST /api/agents/{slug}/access``)."""
    from agentfox.platform.registry.projects import project_agents
    from agentfox.platform.registry.service import approve_drafts

    agents = project_agents(session, project)
    if not agents:
        raise HTTPException(404, f"No project '{project}'")
    approved = approve_drafts(
        session, sorted(agents, key=lambda a: a.slug), actor=user.email or user.id
    )
    session.commit()
    return {"project": project, "approved": [a.slug for a in approved]}


@router.get("/projects/{project}/map")
def get_project_map(
    project: str, session: Session = Depends(db), _user: User = Depends(current_user)
) -> dict[str, Any]:
    """One project's map: who talks to its agents, their models, tools, and what the
    tools touch. Every member of the system is drawn, sub-agents and parents in other
    repositories included. 404 for a name that is no project, root, repository or agent."""
    found = project_map(session, project)
    if found is None:
        raise HTTPException(404, f"No project '{project}'")
    return found


@router.post("/agents/{slug}/restore-guardrails")
def restore_agent_guardrails(
    slug: str, session: Session = Depends(db), user: User = Depends(require("policy"))
) -> dict[str, Any]:
    """Put back the guardrails an agent had when its project was disconnected.

    Each layer's recorded version goes live again, watching; blocking again only when
    it was, the caller may change production policy, and that version was simulated.
    404 when the agent has nothing to restore; 409 while it is still disconnected
    (connect it again first)."""
    from agentfox.capabilities.onboarding.projects import restore_guardrails
    from agentfox.platform.registry.projects import REMOVED

    agent = get_agent_or_404(session, slug)
    if agent.status == REMOVED:
        raise HTTPException(409, f"'{slug}' is disconnected; connect it again first")
    out = restore_guardrails(
        session,
        agent,
        actor=user.email or user.id,
        may_enforce=may_enforce(user),
    )
    if out is None:
        raise HTTPException(404, f"Nothing to restore for '{slug}'")
    session.commit()
    return out


# ---------------------------------------------------------------------------
# Self-service API tokens — the CLI/SDK path had no way for an already-signed-in
# dashboard user to get a token for their own scripts short of the GitHub-login
# provisioning flow, which only ever mints one server-to-server at sign-in.
# ---------------------------------------------------------------------------


class TokenIn(BaseModel):
    name: str = ""
    ttl_days: int | None = 365


@router.post("/tokens", status_code=201)
def create_token(
    payload: TokenIn, session: Session = Depends(db), user: User = Depends(current_user)
) -> dict[str, Any]:
    """Mint a token for the caller's own use. The raw value is returned once —
    same guarantee as every other credential this platform issues."""
    token, raw = issue_token(
        session,
        user,
        name=payload.name or "self-service",
        ttl_days=payload.ttl_days,
        actor=user.email or user.id,
        reason="self-service token generation",
    )
    chain.append(
        session,
        "token.self_issued",
        actor_type="user",
        actor_id=user.email or user.id,
        subject_type="api_token",
        subject_id=token.id,
        payload={"name": token.name},
    )
    session.commit()
    return {"id": token.id, "name": token.name, "token": raw, "expires_at": _iso(token.expires_at)}


@router.get("/tokens")
def list_tokens(
    session: Session = Depends(db), user: User = Depends(current_user)
) -> dict[str, Any]:
    tokens = session.scalars(
        select(ApiToken).where(ApiToken.user_id == user.id).order_by(ApiToken.created_at.desc())
    )
    return {
        "tokens": [
            {
                "id": t.id,
                "name": t.name,
                "key_prefix": t.key_prefix,
                "created_at": _iso(t.created_at),
                "expires_at": _iso(t.expires_at),
                "revoked_at": _iso(t.revoked_at),
            }
            for t in tokens
        ]
    }


@router.post("/tokens/{token_id}/revoke")
def revoke_token(
    token_id: str, session: Session = Depends(db), user: User = Depends(current_user)
) -> dict[str, Any]:
    token = session.get(ApiToken, token_id)
    if token is None or token.user_id != user.id:
        raise HTTPException(404, "no token with that id")
    token.revoked_at = utcnow()
    session.flush()
    chain.append(
        session,
        "token.revoked",
        actor_type="user",
        actor_id=user.email or user.id,
        subject_type="api_token",
        subject_id=token.id,
    )
    session.commit()
    return {"id": token.id, "revoked": True}


# ---------------------------------------------------------------------------
# Agents
# ---------------------------------------------------------------------------


class AgentIn(BaseModel):
    slug: str
    name: str = ""
    purpose: str = ""
    owner_email: str | None = None
    owner_team: str | None = None
    environment: str = "production"
    risk_tier: str = "limited"
    declared_models: list[str] = Field(default_factory=list)
    declared_tools: list[str] = Field(default_factory=list)
    data_classes: list[str] = Field(default_factory=list)
    framework: str | None = None
    #: The repository `agentfox init` maps the agent from (`agentfox up` sends it).
    project: str | None = None


def _agent_json(agent: Agent, session: Session | None = None) -> dict[str, Any]:
    control = "active"
    if session is not None:
        from agentfox.core.models import AgentControl

        row = session.scalar(select(AgentControl).where(AgentControl.agent_id == agent.id))
        control = row.state if row else "active"
    return {
        "control_state": control,
        "id": agent.id,
        "slug": agent.slug,
        "name": agent.name,
        "purpose": agent.purpose,
        "owner_email": agent.owner_email,
        "owner_team": agent.owner_team,
        "environment": agent.environment,
        "risk_tier": agent.risk_tier,
        "framework": agent.framework,
        "project": project_of(agent),
        "status": agent.status,
        "registered": agent.registered,
        # Why a draft showed up: a repository scan (its run) or, with none, `agentfox init`.
        "scan_run_id": agent.source_scan_run_id,
        "owned": agent.is_owned,
        "is_seed": agent.is_seed,
        "declared_models": agent.declared_models,
        "declared_tools": agent.declared_tools,
        "data_classes": agent.data_classes,
        "first_seen_at": _iso(agent.first_seen_at),
        "last_seen_at": _iso(agent.last_seen_at),
    }


@router.get("/agents")
def list_agents(
    session: Session = Depends(db),
    registered: bool | None = None,
    environment: str | None = None,
    include_removed: bool = False,
    _user: User = Depends(current_user),
) -> dict[str, Any]:
    """Every agent. An agent whose project was disconnected (status ``removed``) is
    left out unless ``include_removed``: it is history, not part of the workspace."""
    query = select(Agent).order_by(Agent.slug)
    if not include_removed:
        query = query.where(Agent.status != "removed")
    if registered is not None:
        query = query.where(Agent.registered.is_(registered))
    if environment:
        query = query.where(Agent.environment == environment)
    # Who each agent hands work to, from code or traffic: what lets the Proposed list
    # show a scanned multi-agent system as one system with its members under it.
    children: dict[str, list[dict[str, Any]]] = {}
    for edge in session.scalars(
        select(LineageEdge)
        .where(LineageEdge.relation == "delegates_to", LineageEdge.dst_type == "agent")
        .order_by(LineageEdge.src_id, LineageEdge.dst_id)
    ):
        if edge.src_id != edge.dst_id:
            children.setdefault(edge.src_id, []).append(
                {"slug": edge.dst_id, "relation": edge.kind, "declared": bool(edge.declared)}
            )
    return {
        "agents": [
            {**_agent_json(a, session), "children": children.get(a.slug, [])}
            for a in session.scalars(query)
        ],
        "inventory": inventory(session),
    }


@router.post("/agents", status_code=201)
def create_agent(
    payload: AgentIn,
    session: Session = Depends(db),
    user: User = Depends(require("registry")),
) -> dict[str, Any]:
    agent = register_agent(session, **payload.model_dump())
    # A draft a scan proposed for the same code (same name) is this agent: folded in.
    fold_duplicate_drafts(session, agent, actor=user.email or user.id)
    chain.append(
        session,
        "agent.registered",
        actor_type="user",
        actor_id=user.email or user.id,
        subject_type="agent",
        subject_id=agent.id,
        payload=payload.model_dump(),
    )
    return _agent_json(agent)


@router.get("/agents/{slug}")
def get_agent(
    slug: str, session: Session = Depends(db), _user: User = Depends(current_user)
) -> dict[str, Any]:
    agent = get_agent_or_404(session, slug)
    return _agent_detail_json(agent, session)


def _agent_detail_json(agent: Agent, session: Session) -> dict[str, Any]:
    """One agent, with where its traffic comes from beside the environment it was
    registered in: `agentfox init` registers a new agent as development while
    `auto()` reports production, and its page said "development" for an agent
    running live. What discovery stored is left as it is."""
    latest = session.scalar(
        select(Trace.environment)
        .where(Trace.agent_id == agent.id)
        .order_by(Trace.started_at.desc())
        .limit(1)
    )
    return {**_agent_json(agent, session), "traffic_environment": latest}


class AgentUpdate(BaseModel):
    #: The display name the dashboard shows; the slug (what `auto()` names) never changes.
    name: str | None = None
    owner_email: str | None = None
    owner_team: str | None = None
    risk_tier: str | None = None
    purpose: str | None = None


@router.patch("/agents/{slug}")
def update_agent(
    slug: str,
    payload: AgentUpdate,
    session: Session = Depends(db),
    user: User = Depends(require("registry")),
) -> dict[str, Any]:
    agent = get_agent_or_404(session, slug)
    changes = payload.model_dump(exclude_unset=True)
    if "name" in changes:
        changes["name"] = (changes["name"] or "").strip()[:200]
        if not changes["name"]:
            raise HTTPException(422, "A name can't be empty.")
    for field, value in changes.items():
        setattr(agent, field, value)
    session.flush()
    chain.append(
        session,
        "agent.updated",
        actor_type="user",
        actor_id=user.email or user.id,
        subject_type="agent",
        subject_id=agent.id,
        payload=changes,
    )
    return _agent_json(agent, session)


@router.delete("/agents/{slug}")
def remove_agent(
    slug: str, session: Session = Depends(db), user: User = Depends(require("registry"))
) -> dict[str, Any]:
    """Remove one agent from the dashboard (a duplicate, or one that is gone), the way
    disconnecting its project removes each of its agents: its guardrails recorded and
    emptied, its tool permissions revoked, what init declared for it cleared. Its
    history (traffic, issues, audit) is kept, and `agentfox init` or ``agentfox up``
    proposes it again. The rest of its project stays."""
    from agentfox.capabilities.onboarding.projects import remove_agents
    from agentfox.platform.registry.projects import REMOVED

    agent = get_agent_or_404(session, slug)
    if agent.status == REMOVED:
        raise HTTPException(404, f"'{slug}' is already removed")
    out = remove_agents(session, [agent], subject=slug, actor=user.email or user.id)
    session.commit()
    return out


@router.get("/agents/{slug}/lineage")
def agent_lineage(
    slug: str, depth: int = 2, session: Session = Depends(db), _user: User = Depends(current_user)
) -> dict[str, Any]:
    derive_lineage(session, slug)
    return lineage(session, slug, depth)


@router.get("/agents/{slug}/posture")
def agent_posture(
    slug: str, session: Session = Depends(db), _user: User = Depends(current_user)
) -> dict[str, Any]:
    from agentfox.capabilities.evaluation.drift import evaluate_slos
    from agentfox.core.models import Decision

    agent = get_agent_or_404(session, slug)

    traces = list(session.scalars(select(Trace).where(Trace.agent_slug == slug)))
    decisions = list(session.scalars(select(Decision).where(Decision.agent_id == agent.id)))
    findings = list(
        session.scalars(
            select(Finding).where(
                Finding.subject_id.in_([agent.id, slug]), Finding.status == "open"
            )
        )
    )
    # Hand-offs are recorded independently of Trace/Decision — a conversation can
    # escalate without ever producing a traced execution path (e.g. this agent's
    # SDK only calls record_turn/raise_handoff directly). Counting only Trace and
    # Decision rows here made a real, escalated conversation report as "no traffic
    # recorded" on the one page most likely to be checked first during an incident.
    handoffs = list(session.scalars(select(Handoff).where(Handoff.agent_id == agent.id)))
    by_verdict: dict[str, int] = {}
    for decision in decisions:
        by_verdict[decision.verdict] = by_verdict.get(decision.verdict, 0) + 1

    return {
        "agent": _agent_detail_json(agent, session),
        "traces": len(traces),
        "decisions": len(decisions),
        "decisions_by_verdict": by_verdict,
        "blocked": by_verdict.get("block", 0),
        "escalated": by_verdict.get("escalate", 0),
        "handoffs": len(handoffs),
        "open_findings": [
            {"id": f.id, "type": f.type, "severity": f.severity, "title": f.title} for f in findings
        ],
        "slos": evaluate_slos(session, slug),
    }


@router.get("/discovery/shadow")
def shadow_agents(
    window_days: int = 30, session: Session = Depends(db), _user: User = Depends(current_user)
) -> dict[str, Any]:
    return {"shadow_agents": detect_shadow_agents(session, window_days)}


@router.post("/discovery/scan")
def run_discovery(
    session: Session = Depends(db), user: User = Depends(require("registry"))
) -> dict[str, Any]:
    """Sweep: lineage, unowned agents, registry drift, identity posture, delegation shape."""
    edges = derive_lineage(session)
    unowned = unowned_agents(session)
    drift = attest_registry(session)
    posture = assess_posture(session)
    delegation = assess_delegation(session)
    chain.append(
        session,
        "discovery.scan",
        actor_type="user",
        actor_id=user.email or user.id,
        payload={
            "edges": edges,
            "unowned": len(unowned),
            "drift": len(drift),
            "posture": len(posture),
            "delegation": len(delegation),
        },
    )
    return {
        "lineage_edges": edges,
        "unowned_agents": len(unowned),
        "registry_drift": len(drift),
        "identity_posture_findings": len(posture),
        "delegation_findings": len(delegation),
        "shadow_agents": detect_shadow_agents(session),
    }


# ---------------------------------------------------------------------------
# Tools & MCP
# ---------------------------------------------------------------------------


class ToolIn(BaseModel):
    key: str
    name: str = ""
    kind: str = "function"
    impact: str = "read"
    description: str = ""
    json_schema: dict[str, Any] = Field(default_factory=dict)
    #: ``untrusted`` | ``trusted``. Omitted leaves an existing tool's declaration as it is.
    output_trust: str | None = None
    #: ``communication`` (`agentfox declare tool --effect`); "" clears it, omitted keeps it.
    effect_class: str | None = None
    #: What a call sets off downstream (`--triggers`). Omitted keeps what is declared.
    triggers: list[str] | None = None


@router.get("/tools")
def list_tools(
    session: Session = Depends(db), _user: User = Depends(current_user)
) -> dict[str, Any]:
    return {
        "tools": [
            {
                "key": t.key,
                "name": t.name,
                "kind": t.kind,
                "impact": t.impact,
                "impact_source": impact_source_of(t),
                "output_trust": t.output_trust or "untrusted",
                "triggers": list(t.triggers_json or []),
                "description": t.description,
                "mcp_server_id": t.mcp_server_id,
            }
            for t in session.scalars(select(Tool).order_by(Tool.key))
        ]
    }


@router.post("/tools", status_code=201)
def create_tool(
    payload: ToolIn, session: Session = Depends(db), user: User = Depends(require("registry"))
) -> dict[str, Any]:
    from agentfox.core.models import OUTPUT_TRUST_LEVELS, TOOL_EFFECT_CLASSES

    if payload.output_trust is not None and payload.output_trust not in OUTPUT_TRUST_LEVELS:
        raise HTTPException(400, f"output_trust must be one of {OUTPUT_TRUST_LEVELS}")
    if payload.effect_class and payload.effect_class not in TOOL_EFFECT_CLASSES:
        raise HTTPException(400, f"effect_class must be one of {TOOL_EFFECT_CLASSES}")
    tool = upsert_tool(
        session,
        payload.key,
        name=payload.name,
        kind=payload.kind,
        impact=payload.impact,
        schema=payload.json_schema,
        description=payload.description,
        output_trust=payload.output_trust,
        effect_class=payload.effect_class,
        actor=user.email or user.id,
    )
    if payload.triggers is not None:
        tool.triggers_json = payload.triggers
    return {
        "key": tool.key,
        "impact": tool.impact,
        "output_trust": tool.output_trust,
        "triggers": list(tool.triggers_json or []),
    }


class McpIn(BaseModel):
    name: str
    url: str = ""
    #: Omitted keeps what an existing server has; a new one gets stdio / untrusted.
    transport: str | None = None
    trust_level: str | None = None
    pinned_version: str | None = None


@router.get("/mcp-servers")
def list_mcp(session: Session = Depends(db), _user: User = Depends(current_user)) -> dict[str, Any]:
    return {
        "servers": [
            {
                "id": s.id,
                "name": s.name,
                "url": s.url,
                "transport": s.transport,
                "trust_level": s.trust_level,
                "pinned_version": s.pinned_version,
                "last_scanned_at": _iso(s.last_scanned_at),
            }
            for s in session.scalars(select(McpServer))
        ]
    }


@router.post("/mcp-servers", status_code=201)
def create_mcp(
    payload: McpIn, session: Session = Depends(db), user: User = Depends(require("registry"))
) -> dict[str, Any]:
    """Register an MCP server, and start monitoring it for tool drift.

    A remote (Streamable HTTP) server's tool listing is re-read on a schedule; a stdio
    server's pushed listings are watched."""
    server = upsert_mcp_server(session, **payload.model_dump())
    monitor = _monitor_mcp(session, server, user)
    return {"id": server.id, "name": server.name, "monitor_id": monitor.id if monitor else None}


def _monitor_mcp(session: Session, server: McpServer, user: User | None):
    from agentfox.core import extensions

    # Watching a registered server is AgentFox Enterprise; the open core registers it.
    ensure_monitor = extensions.service("monitors.ensure")
    if ensure_monitor is None:
        return None
    return ensure_monitor(
        session,
        kind="mcp_server",
        target=server.name,
        config={"mcp_server_id": server.id},
        created_by=(user.email or user.id) if user else "",
    )


class McpScanIn(BaseModel):
    tools: list[dict[str, Any]] = Field(default_factory=list)


@router.post("/mcp-servers/{name}/scan")
def scan_mcp(
    name: str,
    payload: McpScanIn,
    session: Session = Depends(db),
    _user: User = Depends(require("registry")),
) -> dict[str, Any]:
    server = session.scalar(select(McpServer).where(McpServer.name == name))
    if server is None:
        raise HTTPException(404, f"unknown MCP server '{name}'")
    return scan_mcp_server(session, server, payload.tools)


class McpRegisterIn(McpScanIn):
    #: The signed-in person's approval of each held tool's new definition. Accepting
    #: lifts the rug-pull block, an org-level loosening: it is an ``mcp.tool.accept``
    #: change proposal, and applies once a second, different person has approved it.
    accept_changes: bool = False
    #: Why the new definitions are acceptable; recorded with the approval.
    note: str | None = None


@router.post("/mcp-servers/{name}/tools")
def register_mcp_tools(
    name: str,
    payload: McpRegisterIn,
    session: Session = Depends(db),
    user: User = Depends(require("registry")),
) -> dict[str, Any]:
    """Snapshot a listing *and* register each tool in the registry.

    Distinct from ``/scan``, which only reports hygiene. Registration is what gives
    the tool a policy identity and a digest to compare against at call time; without
    it the rug-pull check has no baseline.

    A changed listing for an already-registered tool is held (reported in ``held``,
    not registered) and filed as a change proposal (``proposals``). With
    ``accept_changes`` the signed-in person approves those proposals, which takes the
    same role as approving any proposal (``policy_production``); a held tool is
    re-recorded once two different people have approved it.
    """
    from agentfox.capabilities.improvement.proposals import ProposalError
    from agentfox.frameworks.mcp import McpGovernor

    if payload.accept_changes:
        approvers = WRITE_ROLES["policy_production"]
        if user.role not in approvers:
            raise HTTPException(
                403,
                f"role '{user.role}' may not accept a changed MCP listing; accepting is a "
                f"change-proposal approval. Permitted: {sorted(approvers)}.",
            )
    governor = McpGovernor(session=session, agent_slug="", server_name=name)
    try:
        report = governor.register_tools(
            payload.tools,
            accept_changes=payload.accept_changes,
            actor=user.email or user.id,
            note=payload.note,
        )
    except ProposalError as exc:
        raise HTTPException(400, str(exc)) from exc
    _monitor_mcp(session, governor.server, user)
    held = set(report.get("held", []))
    return {
        **report,
        "registered": [
            t.get("name") for t in payload.tools if t.get("name") and t.get("name") not in held
        ],
    }


# ---------------------------------------------------------------------------
# Findings
# ---------------------------------------------------------------------------


def _agent_slug_for_subject(
    session: Session, subject_type: str, subject_id: str | None
) -> str | None:
    """A finding's `subject_id` is an agent identifier — but call sites across the
    codebase have raised findings with both the agent's DB id and its slug in that
    field over time. Resolving both here, once, means the dashboard can always link
    to `/agents/{slug}` without guessing which form a given finding used.
    """
    if subject_type != "agent" or not subject_id:
        return None
    agent = session.get(Agent, subject_id)
    if agent is None:
        agent = session.scalar(select(Agent).where(Agent.slug == subject_id))
    return agent.slug if agent else None


@router.get("/findings")
def list_findings(
    status: str | None = "open",
    severity: str | None = None,
    type: str | None = None,
    agent: str | None = None,
    limit: int = 200,
    session: Session = Depends(db),
    _user: User = Depends(current_user),
) -> dict[str, Any]:
    query = select(Finding).order_by(Finding.created_at.desc()).limit(limit)
    if status:
        query = query.where(Finding.status == status)
    if severity:
        query = query.where(Finding.severity == severity)
    if type:
        query = query.where(Finding.type == type)
    if agent:
        # `subject_id` has been raised with both the agent's DB id and its slug
        # across call sites over time (see `_agent_slug_for_subject`) — matching
        # against both is what makes this filter reliable regardless of which
        # form a given finding used.
        record = session.scalar(select(Agent).where(Agent.slug == agent))
        subject_ids = {agent, record.id} if record else {agent}
        query = query.where(Finding.subject_type == "agent", Finding.subject_id.in_(subject_ids))
    return {
        "findings": [
            {
                "id": f.id,
                "type": f.type,
                "severity": f.severity,
                "status": f.status,
                "title": f.title,
                "subject_type": f.subject_type,
                "subject_id": f.subject_id,
                "agent_slug": _agent_slug_for_subject(session, f.subject_type, f.subject_id),
                "controls": f.control_keys,
                "evidence": f.evidence_json,
                "occurrences": f.occurrences,
                "last_seen_at": _iso(f.last_seen_at),
                "created_at": _iso(f.created_at),
            }
            for f in session.scalars(query)
        ]
    }


@router.get("/findings/types")
def list_finding_types(_user: User = Depends(current_user)) -> dict[str, Any]:
    """Every finding type: its title, default severity, what it means and who raises it.

    The registry the queue's labels come from (`platform/ledger/finding_types.py`),
    including the types the loaded capability packs declare. Declared before
    `/findings/{finding_id}` so ``types`` is not read as an id.
    """
    from agentfox.platform.ledger.finding_types import all_types

    return {"types": [entry.to_json() for entry in all_types()]}


def _may_take(user: User, family: str | None) -> bool:
    """Whether this caller may take a remedy needing ``family``'s write permission."""
    from agentfox.capabilities.detection.tuning import LABEL_REFUSED_ROLES

    if family is None:
        return True
    if family == "feedback":
        return user.role not in LABEL_REFUSED_ROLES
    return user.role in WRITE_ROLES.get(family, set())


def _remedies_json(session: Session, finding: Finding, user: User) -> list[dict[str, Any]]:
    from agentfox.capabilities.remediation import remedies_for

    return [
        {**r.to_json(), "allowed": r.kind == "link" or _may_take(user, r.family)}
        for r in remedies_for(session, finding)
    ]


@router.get("/findings/{finding_id}")
def get_finding(
    finding_id: str, session: Session = Depends(db), user: User = Depends(current_user)
) -> dict[str, Any]:
    finding = session.get(Finding, finding_id)
    if finding is None:
        raise HTTPException(404, "unknown finding")
    return {
        # What can be done about it from here: actions the platform takes, and places
        # the fix is made. `allowed` says whether this caller may take each action.
        "remedies": _remedies_json(session, finding, user),
        "id": finding.id,
        "type": finding.type,
        "severity": finding.severity,
        "status": finding.status,
        "title": finding.title,
        "subject_type": finding.subject_type,
        "subject_id": finding.subject_id,
        "agent_slug": _agent_slug_for_subject(session, finding.subject_type, finding.subject_id),
        "controls": finding.control_keys,
        "evidence": finding.evidence_json,
        "occurrences": finding.occurrences,
        "last_seen_at": _iso(finding.last_seen_at),
        "suppression_reason": finding.suppression_reason,
        "suppressed_by": finding.suppressed_by,
        "resolution_note": finding.resolution_note,
        "resolved_by": finding.resolved_by,
        "created_at": _iso(finding.created_at),
        "resolved_at": _iso(finding.resolved_at),
    }


class RemedyIn(BaseModel):
    inputs: dict[str, Any] = Field(default_factory=dict)


@router.post("/findings/{finding_id}/remedies/{key}")
def take_remedy(
    finding_id: str,
    key: str,
    payload: RemedyIn,
    session: Session = Depends(db),
    user: User = Depends(current_user),
) -> dict[str, Any]:
    """Take one of the issue's actions. Audited; the issue closes itself if the
    condition it is about cleared."""
    from agentfox.capabilities.remediation import RemedyError, apply_remedy
    from agentfox.capabilities.remediation.remedies import find_remedy

    finding = session.get(Finding, finding_id)
    if finding is None:
        raise HTTPException(404, "unknown finding")
    try:
        remedy = find_remedy(session, finding, key)
    except RemedyError as exc:
        raise HTTPException(409, str(exc)) from exc
    if not _may_take(user, remedy.family):
        allowed = sorted(WRITE_ROLES.get(remedy.family or "", set()))
        raise HTTPException(
            403, f"role '{user.role}' may not {remedy.label.lower()}. Permitted: {allowed}."
        )
    try:
        result = apply_remedy(
            session, finding, key, actor=user.email or user.id, inputs=payload.inputs
        )
    except RemedyError as exc:
        raise HTTPException(400, str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    return {**result, "remedies": _remedies_json(session, finding, user)}


class FindingPatch(BaseModel):
    status: str
    suppression_reason: str | None = None
    # What was actually done to fix it — required for "resolved", same discipline
    # "suppressed" already has via suppression_reason. See migration a3f7c9e1b204.
    note: str | None = None


@router.patch("/findings/{finding_id}")
def patch_finding(
    finding_id: str,
    payload: FindingPatch,
    session: Session = Depends(db),
    user: User = Depends(require("registry")),
) -> dict[str, Any]:
    finding = session.get(Finding, finding_id)
    if finding is None:
        raise HTTPException(404, "unknown finding")
    if payload.status not in FINDING_STATUSES:
        # The status is the queue. A free-text status is a finding that silently
        # leaves every view filtering on open/suppressed/resolved — and it would be
        # written into the audit chain as an action name, too.
        raise HTTPException(
            400, f"status must be one of {', '.join(FINDING_STATUSES)}, got {payload.status!r}"
        )
    if payload.status == "suppressed" and not payload.suppression_reason:
        # Suppression without a recorded justification is how a finding queue becomes
        # meaningless; the reason is the control, not the button.
        raise HTTPException(400, "suppression requires a justification")
    if payload.status == "resolved" and not payload.note:
        # Same reasoning as suppression: a one-click "resolved" with nothing recorded
        # is how a still-broken critical finding vanishes from the executive view
        # without anyone having actually fixed it.
        raise HTTPException(400, "resolving requires a note describing what was fixed")
    finding.status = payload.status
    finding.suppression_reason = payload.suppression_reason
    finding.suppressed_by = user.email if payload.status == "suppressed" else None
    if payload.status == "resolved":
        finding.resolved_at = utcnow()
        finding.resolution_note = payload.note
        finding.resolved_by = user.email
    elif payload.status == "open":
        # A reopened finding is not still resolved: leaving the old resolution on it
        # would make the next reader believe the fix was recorded and still holds.
        finding.resolved_at = None
        finding.resolution_note = None
        finding.resolved_by = None
    chain.append(
        session,
        f"finding.{payload.status}",
        actor_type="user",
        actor_id=user.email or user.id,
        subject_type="finding",
        subject_id=finding.id,
        payload={"type": finding.type, "reason": payload.suppression_reason or payload.note},
    )
    return {"id": finding.id, "status": finding.status}


# ---------------------------------------------------------------------------
# Identities, credentials, capabilities
# ---------------------------------------------------------------------------


@router.get("/identities")
def list_identities(
    session: Session = Depends(db), _user: User = Depends(current_user)
) -> dict[str, Any]:
    out = []
    for identity in session.scalars(select(Identity)):
        credentials = list(
            session.scalars(select(Credential).where(Credential.identity_id == identity.id))
        )
        capabilities = list(
            session.scalars(select(Capability).where(Capability.identity_id == identity.id))
        )
        out.append(
            {
                "id": identity.id,
                "principal": identity.principal,
                "agent_id": identity.agent_id,
                "kind": identity.kind,
                "status": identity.status,
                "posture": identity.posture,
                "last_used_at": _iso(identity.last_used_at),
                "credentials": [
                    {
                        "id": c.id,
                        "prefix": c.key_prefix,
                        "active": c.active,
                        "expires_at": _iso(c.expires_at),
                        "revoked_at": _iso(c.revoked_at),
                    }
                    for c in credentials
                ],
                "capabilities": [
                    {
                        "id": c.id,
                        "tool_key": c.tool_key,
                        "actions": c.actions,
                        "constraints": c.constraints_json,
                        "max_taint": c.max_taint,
                        "requires_approval": c.requires_approval,
                    }
                    for c in capabilities
                ],
            }
        )
    return {"identities": out}


@router.post("/identities/{identity_id}/credentials", status_code=201)
def issue(
    identity_id: str,
    ttl_days: int = 90,
    session: Session = Depends(db),
    user: User = Depends(require("identity")),
) -> dict[str, Any]:
    identity = session.get(Identity, identity_id)
    if identity is None:
        raise HTTPException(404, "unknown identity")
    credential, raw = issue_credential(session, identity, ttl_days=ttl_days)
    chain.append(
        session,
        "credential.issued",
        actor_type="user",
        actor_id=user.email or user.id,
        subject_type="credential",
        subject_id=credential.id,
        payload={"identity": identity.principal, "ttl_days": ttl_days},
    )
    # Shown once, never stored in plaintext.
    return {
        "credential_id": credential.id,
        "key": raw,
        "expires_at": _iso(credential.expires_at),
        "note": "This key is shown once and cannot be retrieved again.",
    }


@router.post("/identities/{identity_id}/rotate")
def rotate(
    identity_id: str,
    overlap_hours: int = 24,
    session: Session = Depends(db),
    user: User = Depends(require("identity")),
) -> dict[str, Any]:
    identity = session.get(Identity, identity_id)
    if identity is None:
        raise HTTPException(404, "unknown identity")
    credential, raw = rotate_credential(session, identity, overlap_hours)
    chain.append(
        session,
        "credential.rotated",
        actor_type="user",
        actor_id=user.email or user.id,
        subject_type="credential",
        subject_id=credential.id,
        payload={"identity": identity.principal, "overlap_hours": overlap_hours},
    )
    return {"credential_id": credential.id, "key": raw, "overlap_hours": overlap_hours}


@router.post("/credentials/{credential_id}/revoke")
def revoke(
    credential_id: str, session: Session = Depends(db), user: User = Depends(require("identity"))
) -> dict[str, Any]:
    if not revoke_credential(session, credential_id):
        raise HTTPException(404, "unknown credential")
    chain.append(
        session,
        "credential.revoked",
        actor_type="user",
        actor_id=user.email or user.id,
        subject_type="credential",
        subject_id=credential_id,
        payload={},
    )
    return {"revoked": credential_id}


class CapabilityIn(BaseModel):
    tool_key: str
    actions: list[str] = Field(default_factory=lambda: ["*"])
    constraints: dict[str, Any] = Field(default_factory=dict)
    requires_approval: bool = False
    max_taint: str = "user"


@router.post("/identities/{identity_id}/capabilities", status_code=201)
def add_capability(
    identity_id: str,
    payload: CapabilityIn,
    session: Session = Depends(db),
    user: User = Depends(require("identity")),
) -> dict[str, Any]:
    identity = session.get(Identity, identity_id)
    if identity is None:
        raise HTTPException(404, "unknown identity")
    capability = grant_capability(
        session,
        identity,
        payload.tool_key,
        actions=payload.actions,
        constraints=payload.constraints,
        requires_approval=payload.requires_approval,
        max_taint=payload.max_taint,
        granted_by=user.email,
    )
    chain.append(
        session,
        "capability.granted",
        actor_type="user",
        actor_id=user.email or user.id,
        subject_type="capability",
        subject_id=capability.id,
        payload=payload.model_dump(),
    )
    return {"id": capability.id, "tool_key": capability.tool_key}


class CapabilityCheckIn(BaseModel):
    tool_key: str
    action: str = "*"
    arguments: dict[str, Any] = Field(default_factory=dict)
    argument_taint: dict[str, str] = Field(default_factory=dict)


@router.post("/identities/{identity_id}/check")
def check(
    identity_id: str,
    payload: CapabilityCheckIn,
    session: Session = Depends(db),
    _user: User = Depends(current_user),
) -> dict[str, Any]:
    identity = session.get(Identity, identity_id)
    return check_capability(
        session,
        identity,
        payload.tool_key,
        payload.action,
        payload.arguments,
        payload.argument_taint,
    ).to_json()


# ---------------------------------------------------------------------------
# Approvals
# ---------------------------------------------------------------------------


@router.get("/approvals")
def list_approvals(
    status: str = "pending", session: Session = Depends(db), _user: User = Depends(current_user)
) -> dict[str, Any]:
    expire_stale_approvals(session)
    query = select(ApprovalRequest).order_by(ApprovalRequest.requested_at.desc())
    if status:
        query = query.where(ApprovalRequest.status == status)
    rows = list(session.scalars(query))
    resolvers = _resolver_emails(session, rows)
    return {"approvals": [_approval_json(a, resolvers) for a in rows]}


def _resolver_emails(session: Session, rows: list[ApprovalRequest]) -> dict[str, str]:
    ids = {a.resolver_user_id for a in rows if a.resolver_user_id}
    if not ids:
        return {}
    return {u.id: u.email or u.id for u in session.scalars(select(User).where(User.id.in_(ids)))}


def _approval_json(a: ApprovalRequest, resolvers: dict[str, str]) -> dict[str, Any]:
    """One approval as the Approvals pages show it, including who decided and when.

    `resolver` is null when nobody did: an approval that expired unanswered, or one
    still pending. `resolved_at` is when its status last changed (approved, denied,
    expired or used), null while pending.
    """
    return {
        "id": a.id,
        "agent_id": a.agent_id,
        "tool": a.tool_key,
        "arguments": a.arguments_json,
        "reason": a.reason,
        "status": a.status,
        "requested_at": _iso(a.requested_at),
        "expires_at": _iso(a.expires_at),
        "resolved_at": None if a.status == "pending" else _iso(a.updated_at),
        "resolver": resolvers.get(a.resolver_user_id or "") or a.resolver_user_id,
        "rationale": a.resolution_rationale or None,
        "trace_id": a.trace_id,
        "decision_id": a.decision_id,
        "timeout_action": a.timeout_action,
    }


@router.get("/approvals/{approval_id}")
def get_approval(
    approval_id: str,
    session: Session = Depends(db),
    caller: User | Identity = Depends(operator_or_agent),
) -> dict[str, Any]:
    """One approval. An operator may read any; an agent key only its own agent's.

    The SDK's `wait_for_approval` polls this with the agent's own key: the
    agent that is waiting is the one caller certain to need the answer, so it
    does not need an operator token to read it.
    """
    # The SDK polls this single-approval route, not the bulk list below — without
    # expiring here too, a stale approval reads "pending" forever unless something
    # else happens to hit /approvals first (NOM-IAM-03: unanswered must fail closed).
    expire_stale_approvals(session)
    approval = session.get(ApprovalRequest, approval_id)
    if approval is None:
        raise HTTPException(404, "unknown approval")
    if isinstance(caller, Identity) and (
        approval.agent_id is None or approval.agent_id != caller.agent_id
    ):
        # Not "forbidden": another agent's approval is not this agent's to know of.
        raise HTTPException(404, "unknown approval")
    body = _approval_json(approval, _resolver_emails(session, [approval]))
    if isinstance(caller, Identity):
        # The agent needs the outcome, not which operator decided it.
        body["resolver"] = None
    return body


class ApprovalDecision(BaseModel):
    rationale: str = ""


@router.post("/approvals/{approval_id}/approve")
def approve(
    approval_id: str,
    payload: ApprovalDecision,
    session: Session = Depends(db),
    user: User = Depends(require("approvals")),
) -> dict[str, Any]:
    return _resolve(session, approval_id, True, user, payload.rationale)


@router.post("/approvals/{approval_id}/deny")
def deny(
    approval_id: str,
    payload: ApprovalDecision,
    session: Session = Depends(db),
    user: User = Depends(require("approvals")),
) -> dict[str, Any]:
    return _resolve(session, approval_id, False, user, payload.rationale)


def _resolve(
    session: Session, approval_id: str, approved: bool, user: User, rationale: str
) -> dict[str, Any]:
    existing = session.get(ApprovalRequest, approval_id)
    if existing is not None and existing.status != "pending":
        # Deciding twice would record a second decision for one approval.
        raise HTTPException(409, f"approval is already {existing.status}")
    try:
        approval = resolve_approval(session, approval_id, approved, user.id, rationale)
    except AgentStopped as exc:
        raise HTTPException(409, str(exc)) from exc
    except ApprovalAlreadyDecided as exc:
        raise HTTPException(409, f"approval is already {exc.status}") from exc
    if approval is None:
        raise HTTPException(404, "unknown approval")
    if approval.status == "expired":
        # It ran out while the person was deciding. Recording it as their approval (a
        # 200 the dashboard showed as "Request approved") would be false, and the
        # expiry is not their act for the chain either. A response rather than a raise,
        # so the change to "expired" is committed.
        return JSONResponse(  # type: ignore[return-value]
            status_code=409,
            content={"detail": "This approval expired before it was decided."},
        )
    chain.append(
        session,
        f"approval.{approval.status}",
        actor_type="user",
        actor_id=user.email or user.id,
        subject_type="approval",
        subject_id=approval.id,
        payload={"tool": approval.tool_key, "rationale": rationale, "reason": approval.reason},
    )
    return {"id": approval.id, "status": approval.status, "resolver": user.email}


def _iso(value: dt.datetime | None) -> str | None:
    if value is None:
        return None
    return (value.replace(tzinfo=dt.UTC) if value.tzinfo is None else value).isoformat()


# ---------------------------------------------------------------------------
# Kill switch & quarantine
# ---------------------------------------------------------------------------


class ControlIn(BaseModel):
    reason: str = ""


@router.get("/agent-controls")
def list_agent_controls(
    session: Session = Depends(db), _user: User = Depends(current_user)
) -> dict[str, Any]:
    """Kill-switch/quarantine state per agent.

    Deliberately not `/api/controls`: that path belongs to governance.py's
    compliance-control listing (NIST/EU-AI-Act style controls). Two routers with a
    handler on the identical path means whichever is included first in app.py
    silently takes every request meant for the other.
    """
    return {"controls": all_controls(session)}


@router.get("/agents/{slug}/control")
def agent_control(
    slug: str,
    limit: int = 20,
    session: Session = Depends(db),
    _user: User = Depends(current_user),
) -> dict[str, Any]:
    """One agent's pause/stop state (who, when, why) and its control history, newest
    first, read from the audit chain."""
    from agentfox.platform.registry.control import control_of

    get_agent_or_404(session, slug)
    return control_of(session, slug, limit=limit)


@router.post("/agents/{slug}/quarantine")
def quarantine_agent(
    slug: str,
    payload: ControlIn,
    session: Session = Depends(db),
    user: User = Depends(require("registry")),
) -> dict[str, Any]:
    """Stop an agent while you investigate. Reversible and audited."""
    return _set_agent_state(session, slug, "quarantined", payload.reason, user)


@router.post("/agents/{slug}/kill")
def kill_agent(
    slug: str,
    payload: ControlIn,
    session: Session = Depends(db),
    user: User = Depends(require("identity")),
) -> dict[str, Any]:
    """Stop an agent now. Requires the stronger role — this is an incident action."""
    return _set_agent_state(session, slug, "killed", payload.reason, user)


@router.post("/agents/{slug}/resume")
def resume_agent(
    slug: str,
    payload: ControlIn,
    session: Session = Depends(db),
    user: User = Depends(require("identity")),
) -> dict[str, Any]:
    """Restart a stopped agent. Deliberately the same role as `kill` — restarting
    something that was stopped for cause is not a lesser decision than stopping it."""
    return _set_agent_state(session, slug, "active", payload.reason, user)


class BreakerIn(BaseModel):
    mode: str | None = None
    window_seconds: float | None = None
    min_calls: float | None = None
    block_ratio: float | None = None
    cooldown_seconds: float | None = None
    probe_calls: float | None = None


@router.get("/agents/{slug}/breaker")
def agent_breaker(
    slug: str, session: Session = Depends(db), _user: User = Depends(current_user)
) -> dict[str, Any]:
    """The agent's circuit breaker: settings, state, and the current window's rate."""
    from agentfox.platform.registry import breaker

    return breaker.status(session, get_agent_or_404(session, slug))


@router.put("/agents/{slug}/breaker")
def configure_agent_breaker(
    slug: str,
    payload: BreakerIn,
    session: Session = Depends(db),
    user: User = Depends(require("identity")),
) -> dict[str, Any]:
    """Change when the breaker trips and what it does. The same role as the kill
    switch: a breaker that pauses the agent is one."""
    from agentfox.platform.registry import breaker

    try:
        return breaker.configure(
            session,
            get_agent_or_404(session, slug),
            payload.model_dump(exclude_none=True),
            actor=user.email,
        )
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc


@router.post("/agents/{slug}/breaker/reset")
def reset_agent_breaker(
    slug: str,
    payload: ControlIn,
    session: Session = Depends(db),
    user: User = Depends(require("identity")),
) -> dict[str, Any]:
    """Close the breaker now and let the agent's calls through."""
    from agentfox.platform.registry import breaker

    return breaker.reset(
        session, get_agent_or_404(session, slug), actor=user.email, reason=payload.reason
    )


def _set_agent_state(
    session: Session, slug: str, state: str, reason: str, user: User
) -> dict[str, Any]:
    try:
        control = set_state(session, slug, state, reason=reason, actor=user.email)
    except UnknownAgent as exc:
        raise HTTPException(404, str(exc)) from exc
    return {
        "agent": slug,
        "state": control.state,
        "previous_state": control.previous_state,
        "reason": control.reason,
        "actor": control.actor,
        "changed_at": _iso(control.changed_at),
    }
