"""FastAPI application — inline gateway + control-plane API.

One process serves both surfaces, which is a deployment choice rather than an
architectural one: it keeps the self-host story to a single container,
and the gateway is stateless so it scales out horizontally.
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import Any

from fastapi import Depends, FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse
from sqlalchemy import select
from sqlalchemy.orm import Session
from starlette.concurrency import run_in_threadpool

from agentfox import __version__
from agentfox.apps.gateway.deps import current_user, db
from agentfox.apps.gateway.routes import access as access_routes
from agentfox.apps.gateway.routes import (
    answerability,
    coverage,
    discovery,
    entitlement,
    escalation,
    evaluation,
    governance,
    inline,
    integrations,
    jobs,
    memory,
    messaging,
    onboarding,
    playground,
    policy,
    posture,
    probes,
    proposals,
    provenance,
    registry,
    tuning,
    waitlist,
)
from agentfox.apps.gateway.routes import checks as check_routes
from agentfox.apps.gateway.routes import custom_rules as custom_rule_routes
from agentfox.apps.gateway.routes import features as feature_routes
from agentfox.apps.gateway.routes import imports as import_routes
from agentfox.apps.gateway.routes import library as library_routes
from agentfox.apps.gateway.routes import members as member_routes
from agentfox.apps.gateway.routes import metrics as metrics_routes
from agentfox.apps.gateway.routes import onboarding_flow as onboarding_flow_routes
from agentfox.apps.gateway.routes import platform_hooks as platform_hook_routes
from agentfox.apps.gateway.routes import protection as protection_routes
from agentfox.apps.gateway.routes import rule_examples as rule_example_routes
from agentfox.apps.gateway.routes import workspace as workspace_routes
from agentfox.capabilities.compliance.catalog import load_catalog
from agentfox.capabilities.detection import all_detectors, available_detectors
from agentfox.core.config import assert_production_secrets, get_settings
from agentfox.core.db import init_db
from agentfox.platform.providers import all_providers, available_providers
from agentfox.runtime.availability import (
    check_services,
    get_admission_controller,
    observe_governed_request,
    service_health,
)

log = logging.getLogger(__name__)


def _load_demo_fixtures() -> None:
    """Re-register the offline provider's scripted replies when a seeded DB is present.

    Purely a demo affordance, and scoped to exactly that: the scripts live in the
    `echo` provider's process memory, so a server started after `agentfox admin seed` would
    otherwise lose them and the walkthrough would not reproduce over HTTP. Guarded on
    the seeded suite existing so a real deployment never picks up fixture text.
    """
    try:
        from sqlalchemy import select

        from agentfox.core.db import session_scope
        from agentfox.core.models import EvalSuite
        from agentfox.fixtures.seed import register_scripts

        with session_scope() as session:
            if session.scalar(select(EvalSuite).where(EvalSuite.key == "support-quality")):
                register_scripts()
                log.info("demo fixtures detected — offline provider scripts registered")
    except Exception as exc:  # never let a fixture concern break startup
        log.debug("demo fixture load skipped: %s", exc)


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    _load_demo_fixtures()
    settings = get_settings()
    log.info(
        "AgentFox %s starting — provider=%s policy_engine=%s mode=%s egress=%s",
        __version__,
        settings.default_provider,
        settings.policy_engine,
        settings.default_policy_mode,
        settings.allow_egress,
    )
    from agentfox.platform.identity.operators import auth_posture

    posture = auth_posture()
    (log.warning if posture.startswith("DEVELOPMENT") else log.info)("auth: %s", posture)
    # Pay any model-loading cost now, off the request path — a classifier detector
    # that only gets slow once, on its very first call, would otherwise silently
    # degrade the first real request every time this process starts (the 40ms
    # per-detector timeout is nowhere near enough to also cover loading a model).
    from agentfox.capabilities.detection import warm_all

    warm_all()
    # The shipped policy packs and the check modules load lazily on first use (about
    # 180 ms, mostly YAML parsing), which the first guarded request of every process
    # paid. Load them here instead. Never fatal: the request path loads them anyway.
    try:
        from agentfox.platform import checks as check_registry
        from agentfox.runtime.checks import BUILTIN_CHECK_MODULES
        from agentfox.runtime.enforcement.rules import _fallback_policies

        _fallback_policies()
        check_registry.load(BUILTIN_CHECK_MODULES)
    except Exception:  # pragma: no cover - warm-up only
        log.warning("could not preload policy packs and checks", exc_info=True)
    yield


def _judgment_posture() -> dict[str, Any]:
    """What the judgment tiers are allowed to do, and what leaves the box.

    Rendered from the routing table rather than restated, so the UI cannot
    drift from the policy it is describing: each kind reports who may decide
    it and, for every tier that may not, the measured reason it was refused.
    """
    from agentfox.capabilities.judgment import posture as _posture
    from agentfox.capabilities.judgment.capability import CapabilityRouter, DecisionKind, Tier
    from agentfox.core.config import get_settings

    settings = get_settings()
    # The *effective* posture, which is this tenant's stored choice where there is one
    # and the deployment's settings otherwise. Reading settings directly here would
    # make this endpoint disagree with the page that changes them, and the whole
    # purpose of the endpoint is to be the thing somebody screenshots.
    active = _posture.effective()
    router = CapabilityRouter.from_settings()
    kinds = {}
    for kind in DecisionKind:
        plan = router.plan(kind)
        kinds[kind.value] = {
            "combine": plan.combine.value,
            "deciders": [t.value for t in plan.deciders],
            "refused": {
                t.value: plan.why(t) for t in plan.excluded_tiers() if t is not Tier.DETERMINISTIC
            },
        }
    return {
        "tiers_enabled": sorted(str(t) for t in active.tiers),
        # From settings and never from posture: it is the ceiling, and a ceiling the
        # thing underneath it can raise is not a ceiling.
        "allow_egress": bool(getattr(settings, "allow_egress", False)),
        "pii_egress": str(active.pii_egress),
        "backend": str(active.backend),
        "fail_closed": active.fail_closed,
        "redact_before_egress": bool(getattr(settings, "judgment_redact_before_egress", True)),
        "editable_at": "/api/judgment/posture",
        "kinds": kinds,
    }


def _key_rotation_status() -> dict[str, str]:
    """`platform.keys.rotation.status_summary`, or "unknown" if it cannot be computed.

    Public, so states only. Free (no database access) unless a previous key is
    configured, and cached for a minute when one is.
    """
    from agentfox.platform.keys.rotation import status_summary

    try:
        return status_summary()
    except Exception as exc:  # noqa: BLE001 - a version route must always answer
        log.warning("key rotation status unavailable: %s", type(exc).__name__)
        return {"token_encryption": "unknown", "audit_signing": "unknown"}


#: The inline routes that call a model provider on the caller's behalf.
MODEL_ROUTES = ("/v1/chat/completions", "/v1/messages")


#: Least gap between traffic-triggered job passes, per instance.
JOBS_KICK_INTERVAL_SECONDS = 600
#: Monotonic time of the last pass; None until this instance has run one. Not 0.0:
#: monotonic time counts from boot, so a fresh instance (a new serverless container, a
#: CI runner) would read "ran one moments ago" and wait out its first ten minutes.
_last_jobs_kick: float | None = None


def _jobs_kick_due(path: str) -> bool:
    global _last_jobs_kick
    import time

    settings = get_settings()
    if not (settings.scheduler_enabled and settings.jobs_on_traffic):
        return False
    if path.startswith("/api/internal/jobs"):
        return False
    now = time.monotonic()
    if _last_jobs_kick is not None and now - _last_jobs_kick < JOBS_KICK_INTERVAL_SECONDS:
        return False
    _last_jobs_kick = now
    return True


def _run_due_jobs() -> None:
    """One scheduling and job pass, quietly."""
    try:
        from agentfox.core.db import session_scope
        from agentfox.platform.jobs import scheduler

        with session_scope() as session:
            scheduler.run_due(session, limit=10)
    except Exception:  # noqa: BLE001 - housekeeping must never surface to a caller
        logging.getLogger(__name__).warning("traffic-triggered job pass failed", exc_info=True)


class RunDueJobsOnTraffic:
    """Run due background jobs off ordinary traffic, after the request has finished.

    Scheduled jobs are driven by the cron route, and the hosted gateway's plan allows
    one cron a day: every job meant to run hourly (escalation scan, repo monitors,
    probes) ran daily. While the gateway serves traffic, an instance now also runs
    whatever is due at most every few minutes. Jobs are claimed atomically
    (jobs.store._run_one), so this and the cron never run one twice.

    Plain ASGI rather than a `BaseHTTPMiddleware` attaching `response.background`, and
    the difference is a deadlock. Starlette's `BaseHTTPMiddleware` (1.10; not 1.6) holds the
    wrapped app's final `send` until its own response, background included, has been
    sent, so the request's `get_session` teardown — its COMMIT — waited for the job
    pass, and the job pass's first write waited for that COMMIT. On SQLite both sat
    out the 30 s busy timeout, every request behind them failed "database is locked",
    and the connection pool filled with requests waiting their turn. Here the pass
    starts only once the wrapped app has returned, so the request has committed and
    released its connection; and the ASGI call stays open until the pass is done, so a
    serverless host still keeps the instance alive for it.
    """

    def __init__(self, app: Any) -> None:
        self.app = app

    async def __call__(self, scope: Any, receive: Any, send: Any) -> None:
        await self.app(scope, receive, send)
        if scope["type"] == "http" and _jobs_kick_due(scope.get("path", "")):
            await run_in_threadpool(_run_due_jobs)


#: Sent on every gateway response. The gateway serves JSON and the API docs; nothing
#: legitimately frames it, so framing is refused, and nothing it returns should be
#: sniffed into another content type. Only `frame-ancestors` in the CSP: a script
#: policy would break the bundled API docs page for no gain on a JSON API.
SECURITY_HEADERS: tuple[tuple[bytes, bytes], ...] = (
    (b"x-content-type-options", b"nosniff"),
    (b"x-frame-options", b"DENY"),
    (b"content-security-policy", b"frame-ancestors 'none'"),
    (b"referrer-policy", b"no-referrer"),
)


class SecurityHeaders:
    """Add :data:`SECURITY_HEADERS` to every HTTP response that does not set its own.

    Plain ASGI for the reason `RunDueJobsOnTraffic` gives: no `BaseHTTPMiddleware`.
    """

    def __init__(self, app: Any) -> None:
        self.app = app

    async def __call__(self, scope: Any, receive: Any, send: Any) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        async def send_with_headers(message: Any) -> None:
            if message["type"] == "http.response.start":
                headers = list(message.get("headers") or [])
                present = {k.lower() for k, _ in headers}
                headers.extend((k, v) for k, v in SECURITY_HEADERS if k not in present)
                message = {**message, "headers": headers}
            await send(message)

        await self.app(scope, receive, send_with_headers)


class _BodyTooLarge(Exception):
    pass


class BodySizeLimit:
    """Refuse a request body over ``max_request_bytes`` with 413, before it is buffered.

    A declared ``Content-Length`` over the limit is refused without reading anything; a
    body sent without one (chunked) is counted as it arrives and cut off at the limit.
    """

    def __init__(self, app: Any) -> None:
        self.app = app

    async def __call__(self, scope: Any, receive: Any, send: Any) -> None:
        limit = get_settings().max_request_bytes
        if scope["type"] != "http" or limit <= 0:
            await self.app(scope, receive, send)
            return
        declared = dict(scope.get("headers") or []).get(b"content-length")
        if declared is not None and declared.isdigit() and int(declared) > limit:
            await self._too_large(send, limit)
            return

        received = 0
        over = False
        replaced = False
        started = False

        async def counting_receive() -> Any:
            nonlocal received, over
            message = await receive()
            if message["type"] == "http.request":
                received += len(message.get("body", b""))
                if received > limit:
                    over = True
                    raise _BodyTooLarge
            return message

        async def tracking_send(message: Any) -> None:
            nonlocal started, replaced
            if over:
                # FastAPI turns an error while reading the body into its own 400; the
                # caller should hear what actually happened instead.
                if not replaced and message["type"] == "http.response.start":
                    replaced = started = True
                    await self._too_large(send, limit)
                return
            if message["type"] == "http.response.start":
                started = True
            await send(message)

        try:
            await self.app(scope, counting_receive, tracking_send)
        except _BodyTooLarge:
            if started:
                return
            await self._too_large(send, limit)

    @staticmethod
    async def _too_large(send: Any, limit: int) -> None:
        body = (
            b'{"detail":"request body too large (the limit is '
            + str(limit).encode()
            + b' bytes, max_request_bytes)"}'
        )
        await send(
            {
                "type": "http.response.start",
                "status": 413,
                "headers": [
                    (b"content-type", b"application/json"),
                    (b"content-length", str(len(body)).encode()),
                ],
            }
        )
        await send({"type": "http.response.body", "body": body})


def create_app() -> FastAPI:
    # Before anything else, and here rather than in `lifespan`: a serverless host may
    # never run the lifespan, and a process that is going to refuse should refuse
    # before it has served a single request. Outside development, a published service
    # secret lets anyone mint an owner token, and a published signing key lets anyone
    # forge the audit chain — neither is a configuration to run degraded on.
    assert_production_secrets()
    app = FastAPI(
        title="AgentFox Control Plane",
        version=__version__,
        description=(
            "Agent-native, vendor-neutral governance, security and compliance for AI "
            "agents in production. Inline enforcement under /v1, control plane under /api."
        ),
        lifespan=lifespan,
    )

    # The dashboard is a client of this API. In self-host it is same-origin or
    # localhost; nothing here opens the control plane to the internet by itself.
    # The public playground page is the one deliberate exception — it is designed
    # to be called cross-origin, unauthenticated, from wherever it's hosted, so its
    # origin is additive here via AGENTFOX_PLAYGROUND_CORS_ORIGIN rather than
    # widening this list's intent for every other route.
    cors_origins = ["http://localhost:3000", "http://127.0.0.1:3000"]
    cors_origins.extend(get_settings().playground_cors_origins)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=[
            "X-AgentFox-Trace",
            "X-AgentFox-Verdict",
            "X-AgentFox-Effective-Verdict",
            # Same two values under names that say which one took effect:
            # applied = what happened, would-be = the counterfactual. See
            # gateway/verdicts.py.
            "X-AgentFox-Applied-Verdict",
            "X-AgentFox-Would-Be-Verdict",
            "X-AgentFox-Decision",
            "X-AgentFox-Mode",
            "X-AgentFox-Latency-Ms",
        ],
    )

    # Between CORS and the two gates below, where the `@app.middleware` version sat.
    app.add_middleware(RunDueJobsOnTraffic)

    @app.middleware("http")
    async def degradation_gate(request: Request, call_next):
        """Fail-open/closed per *service*, and never silently.

        `fail_mode` per detector covers one detector timing out on one request. That
        is the wrong granularity for the failure that actually matters. When the
        detector pipeline as a whole has nothing to run, the policy engine's OPA
        sidecar is unreachable (`policy/store.py` quietly substitutes the native
        engine), the database is refusing connections, or the configured model
        provider is gone, *every* request is ungoverned — and the deployment reports
        200s throughout, which is precisely the indistinguishable-from-working failure
        `availability.py`'s docstring refuses to accept.

        So: probe the dependencies, run the operator's declared `FailPolicy`, and put
        the answer where it can be seen. Fail-closed refuses here rather than admitting
        an ungoverned request; fail-open serves it but records it and stamps the
        response, and converts to closed once the degradation outlasts its budget.
        Scoped to ``/v1/*`` for the same reason as the admission gate below: ``/api/*``
        is the operator control plane, and an operator diagnosing an outage must not be
        locked out by the outage.
        """
        if not request.url.path.startswith("/v1/"):
            return await call_next(request)

        # Counted before the verdict so the ledger's denominator includes the healthy
        # traffic — five degraded requests out of five is an outage, five out of fifty
        # thousand is a blip, and a fraction over failures alone cannot tell them apart.
        observe_governed_request()
        # Cached verdicts only: a stale probe refreshes in the background. Probing
        # here blocked the event loop on a database connection under load, which
        # stalled every request until the pool timed out (30 s).
        events = await run_in_threadpool(check_services, block=False)
        if not request.url.path.startswith(MODEL_ROUTES):
            # Guard, MCP and trace routes never call the model: a provider outage is
            # no reason to stop checking the traffic of teams that call it themselves.
            events = [e for e in events if e.control != "model_provider"]
        blocking = [e for e in events if e.verdict == "block"]
        if blocking:
            event = blocking[0]
            return JSONResponse(
                status_code=503,
                content={
                    "error": {
                        "type": "agentfox_service_degraded",
                        "message": event.reason,
                        "service": event.control,
                        "detail": event.error,
                        "escalated": event.escalated,
                        "fail_mode": get_settings().fail_mode,
                        "degraded_services": sorted({e.control for e in blocking}),
                    }
                },
                headers={
                    "Retry-After": "5",
                    "X-AgentFox-Degraded": ",".join(sorted({e.control for e in blocking})),
                },
            )

        response = await call_next(request)
        if events:
            # The request was served without a dependency the governance layer needed.
            # A caller that gets a 200 back deserves to know that much without going
            # and reading someone else's logs.
            response.headers["X-AgentFox-Degraded"] = ",".join(sorted({e.control for e in events}))
        return response

    @app.middleware("http")
    async def admission_gate(request: Request, call_next):
        """Shed load before it reaches governance, never after.

        Scoped to ``/v1/*``, the inline surface an agent actually calls under load;
        ``/api/*`` is the operator control plane, low-volume by nature and already
        outside what this admission budget is sized for. This runs ahead of
        routing, so a shed request never reaches `Enforcer` — under saturation the
        thing to drop is work, not the checks on the work that gets through
        (`availability.py`'s module docstring).
        """
        if not request.url.path.startswith("/v1/"):
            return await call_next(request)

        controller = get_admission_controller()
        priority = request.headers.get("X-AgentFox-Priority", "normal")
        admission = controller.admit(scope="inline", priority=priority)
        if not admission.admitted:
            return JSONResponse(
                status_code=429,
                content={
                    "error": {
                        "type": "agentfox_admission_shed",
                        "message": admission.reason,
                        "retry_after_seconds": admission.retry_after_seconds,
                    }
                },
                headers={"Retry-After": str(max(1, round(admission.retry_after_seconds)))},
            )
        controller.enter()
        try:
            return await call_next(request)
        finally:
            controller.leave()

    app.add_middleware(BodySizeLimit)
    # Added last, so outermost: the gates' own 429 and 503 answers, and the 413 above,
    # get the headers too.
    app.add_middleware(SecurityHeaders)

    from agentfox.runtime.enforcement import ProviderUnavailable

    @app.exception_handler(ProviderUnavailable)
    async def provider_unavailable(_request: Request, exc: ProviderUnavailable) -> JSONResponse:
        """No provider could answer: a 502 that says so, rather than a bare 500."""
        return JSONResponse(
            status_code=502,
            content={"error": {"type": "agentfox_provider_unavailable", "message": str(exc)}},
        )

    app.include_router(inline.router)
    app.include_router(registry.router)
    app.include_router(policy.router)
    app.include_router(evaluation.router)
    app.include_router(governance.router)
    app.include_router(tuning.router)
    app.include_router(escalation.router)
    app.include_router(answerability.router)
    app.include_router(onboarding.router)
    app.include_router(onboarding_flow_routes.router)
    app.include_router(provenance.router)
    app.include_router(entitlement.router)
    app.include_router(integrations.router)
    app.include_router(jobs.router)
    app.include_router(discovery.router)
    app.include_router(memory.router)
    app.include_router(messaging.router)
    app.include_router(proposals.router)
    app.include_router(posture.router)
    app.include_router(coverage.router)
    app.include_router(metrics_routes.router)
    app.include_router(access_routes.router)
    app.include_router(library_routes.router)
    app.include_router(custom_rule_routes.router)
    app.include_router(feature_routes.router)
    app.include_router(check_routes.router)
    app.include_router(import_routes.router)
    app.include_router(protection_routes.router)
    app.include_router(rule_example_routes.router)
    app.include_router(workspace_routes.router)
    app.include_router(member_routes.router)
    app.include_router(platform_hook_routes.router)
    app.include_router(platform_hook_routes.admin_router)
    # Unauthenticated by design (see playground.py's module docstring) — the only
    # router in this app that never depends on `current_user`. It keeps no state in
    # this process: a sandbox is a tenant in the deployment database, so any instance
    # can serve any sandbox and the gateway stays stateless.
    app.include_router(playground.router)
    # Also unauthenticated by design, and for a plainer reason than the playground's:
    # joining a waitlist is what someone does *before* they have an account to sign in
    # with. It writes one row to the one table that holds no tenant's data, and calls
    # nothing — see waitlist.py's module docstring for what keeps a public write safe.
    app.include_router(waitlist.router)
    app.include_router(probes.router)
    # Unauthenticated and read-only: the marketing site's /live page. It reads only the
    # showcase tenant, returns counts rather than content, and is cached and rate
    # limited — see probes.py and apps/showcase.py.
    app.include_router(probes.public_router)
    # Routers an installed extension adds (the enterprise package, `core/extensions.py`).
    # Mounted after every core router, so an extension can add paths but not shadow ours.
    from agentfox.core import extensions

    for extension_router in extensions.collect("routers"):
        app.include_router(extension_router)

    def _health_payload() -> dict[str, Any]:
        degradation = service_health()
        return {
            "status": "ok",
            "version": __version__,
            "governance_healthy": degradation.get("healthy"),
            "degradation": degradation,
        }

    @app.get("/", tags=["platform"], summary="Service root")
    def root() -> dict[str, Any]:
        """Name the service and say where to go next. Unauthenticated.

        Added because `GET /` and `GET /health` both returned `{"detail":"Not Found"}`
        on the deployed API while only `/api/health` worked, which reads as a dead host
        to anyone checking by hand or with a default uptime probe.

        It reports the product name, the running version, and paths. It reports no
        configuration: not the database, the provider, the policy mode, the fail mode,
        the enabled detectors or any credential. Reaching this route proves the process
        is up and serving HTTP and nothing more — it runs no dependency check, so a 200
        here does not mean the database or the detectors are healthy. `/api/health`
        answers that.
        """
        return {
            "service": "agentfox",
            "description": (
                "Governance, security and compliance for AI agents. Inline enforcement "
                "under /v1, control plane under /api."
            ),
            "version": __version__,
            "docs": "/docs",
            "openapi": "/openapi.json",
            "health": "/api/health",
            "metrics": "/metrics",
        }

    @app.get("/health", tags=["platform"], summary="Health")
    def health_alias() -> dict[str, Any]:
        """The same payload as `/api/health`, at the path probes default to.

        An alias, not a second implementation: both call the same function, so the two
        cannot drift apart and report different things about one process.
        """
        return _health_payload()

    # `summary` pinned so the docstring below does not rewrite this route's label in
    # the generated API route table (scripts/gen/api_routes.py) — the explanation belongs
    # in the description, and the public summary of this route has not changed.
    @app.get("/api/health", tags=["platform"], summary="Health")
    def health() -> dict[str, Any]:
        """Liveness, plus what is currently not being checked.

        `status` stays "ok" for a process that is up and serving — that is what every
        liveness probe already pointed at this route means by it, and changing it would
        start restarting healthy containers. What a fail-open deployment needs *on top*
        is `governance_healthy`: a fail-open system reports success while checking
        nothing, so a 200 here is exactly the signal that cannot tell a working control
        from an absent one.
        """
        return _health_payload()

    @app.get("/api/version", tags=["platform"])
    def version() -> dict[str, Any]:
        """Every version that participates in a decision, so a verdict can be reproduced."""
        settings = get_settings()
        catalog = load_catalog()
        from agentfox.core import extensions

        return {
            "code_version": __version__,
            # "enterprise" when the enterprise package is installed; `features` is what
            # it adds, and what the dashboard shows navigation for.
            "edition": "enterprise" if extensions.loaded() else "open-source",
            "extensions": extensions.names(),
            "features": sorted(extensions.features()),
            "catalog_version": catalog.get("version"),
            "catalog_review_status": catalog.get("review_status"),
            "policy_engine": settings.policy_engine,
            "default_provider": settings.default_provider,
            "default_policy_mode": settings.default_policy_mode,
            "fail_mode": settings.fail_mode,
            "enforcement_budget_ms": settings.enforcement_budget_ms,
            "detector_versions": {k: d.version for k, d in all_detectors().items()},
            "egress_allowed": settings.allow_egress,
            # States only (complete | pending | not_configured | misconfigured), never a
            # key or a fingerprint: lets an operator confirm a rotation from outside.
            "key_rotation": _key_rotation_status(),
        }

    @app.get("/api/detectors", tags=["platform"])
    def detectors(session: Session = Depends(db), _u=Depends(current_user)) -> dict[str, Any]:
        """Which detectors exist, which are live, and how fast they are."""
        from sqlalchemy import func

        from agentfox.core.models import DetectorRun

        stats: dict[str, dict[str, Any]] = {}
        rows = session.execute(
            select(
                DetectorRun.detector_key,
                func.count(),
                func.avg(DetectorRun.duration_ms),
                func.max(DetectorRun.duration_ms),
            ).group_by(DetectorRun.detector_key)
        ).all()
        for key, count, avg_ms, max_ms in rows:
            stats[key] = {
                "runs": int(count),
                "avg_ms": round(float(avg_ms or 0), 3),
                "max_ms": round(float(max_ms or 0), 3),
            }

        from agentfox.capabilities.detection.models import pull_hint

        available = available_detectors()
        from agentfox.capabilities.detection.detector_settings import (
            ALWAYS_ON as DETECTORS_ALWAYS_ON,
        )
        from agentfox.capabilities.detection.detector_settings import enabled_for

        workspace_enabled = enabled_for(session)
        from agentfox.apps.gateway.routes.checks import latest_pull_jobs
        from agentfox.capabilities.detection.catalog import GROUPS, describe, feeds_for
        from agentfox.capabilities.detection.models import models_for, pull_blocker

        pull_jobs = latest_pull_jobs(session)
        # What the workspace's own models and rules make the custom checks report.
        feeds = feeds_for(all_detectors(), session)
        # Why the OSS-wrapped and licence-restricted detectors aren't live here —
        # shown in the UI so "not installed" doesn't read as a bug. The native
        # detectors (injection.heuristic, pii.native, safety.lexicon, schema.json,
        # secrets.native) need none of this and are always available.
        unavailable_reason = {
            # pii.presidio answers for itself too, and has to: this said it was
            # "available in the self-hosted docker-compose deployment", which is
            # only true where its 400MB spaCy model has also been provisioned —
            # and getting that wrong is what the detector's own reason exists to
            # explain. It also named the wrong extra (`[presidio]`, not `[pii]`).
            # rails.nemo and rails.guardrails_ai answer for themselves now that
            # they can actually be turned on: their reason names the setting to
            # set and distinguishes "not installed" from "installed, nothing
            # configured" from "configured, but it did not load". A fixed
            # sentence here could say none of that.
            "safety.granite": (
                "Wrapped IBM Granite Guardian, via transformers — needs the model "
                "weights downloaded ahead of time (never fetched at request time); "
                "not present in this deployment's function image."
            ),
            "safety.restricted": (
                "Meta Llama Guard / Google ShieldGemma — capable, but their licences "
                "aren't OSI-approved (usage restrictions, a MAU clause), so this stays "
                "opt-in only via AGENTFOX_ACCEPT_RESTRICTED_MODEL_LICENSES=1, "
                "regardless of deployment."
            ),
        }
        return {
            "detectors": [
                {
                    "key": key,
                    "version": detector.version,
                    "surfaces": list(detector.surfaces),
                    "available": key in available,
                    # This workspace's choice (dashboard switches) over the deployment's.
                    "enabled": key in workspace_enabled,
                    "always_on": key in DETECTORS_ALWAYS_ON,
                    # A detector that knows why it is unavailable says so itself;
                    # the table above covers the ones that predate that. Twenty
                    # Hub validators maintained in a hard-coded dict in this file
                    # would drift from the catalogue on the first addition.
                    "unavailable_reason": (
                        None
                        if key in available
                        else getattr(detector, "unavailable_reason", None)
                        or unavailable_reason.get(key)
                        or (
                            f"Its model is not downloaded here. Run `{pull_hint(detector)}`."
                            if pull_hint(detector)
                            else None
                        )
                    ),
                    "label": getattr(detector, "label", None),
                    "install": getattr(detector, "package", None),
                    "pull": None if key in available else pull_hint(detector),
                    "stats": stats.get(key, {}),
                    # For the Checks screen: what it catches, where it runs, where it
                    # comes from (built-in, open-source model, LLM judge, your own).
                    **describe(detector, feeds),
                    # Why the Download button cannot work on this server, if it cannot.
                    "pull_blocked": (
                        pull_blocker(detector)
                        if key not in available and models_for(detector)
                        else None
                    ),
                    "pull_job": pull_jobs.get(key),
                }
                for key, detector in sorted(all_detectors().items())
            ],
            "groups": [{"key": k, "label": label} for k, label in GROUPS],
            "budget_ms": get_settings().enforcement_budget_ms,
            "detector_timeout_ms": get_settings().detector_timeout_ms,
            # The judgment tiers are the one capability whose posture an
            # operator cannot infer from the detector list: two of these checks
            # being off says nothing about *why*, or about what leaves the
            # deployment when they are on. The egress choice in particular was
            # configurable only by editing a TOML file.
            "judgment": _judgment_posture(),
        }

    @app.get("/api/reliability", tags=["platform"])
    def reliability(session: Session = Depends(db), _u=Depends(current_user)) -> dict[str, Any]:
        """Circuit-breaker state and live budget consumption."""

        from agentfox.core.models import Agent, Budget
        from agentfox.runtime.reliability import BREAKER, check_budget

        budgets = []
        for budget in session.scalars(select(Budget).where(Budget.scope_type == "agent")):
            agent = session.get(Agent, budget.scope_id)
            verdict = check_budget(session, "agent", budget.scope_id)
            budgets.append({"agent": agent.slug if agent else budget.scope_id, **verdict.to_json()})
        return {
            "circuit_breakers": BREAKER.snapshot(),
            "budgets": budgets,
            "fallback_chain": get_settings().fallback_chain,
            # The per-service degradation ledger, alongside the per-provider
            # breaker it complements. `fail_mode` travels with it because "degraded"
            # means something different under each — open means those requests were
            # served unchecked, closed means they were refused.
            "fail_mode": get_settings().fail_mode,
            "degradation": service_health(),
        }

    @app.get("/metrics", tags=["platform"], response_class=PlainTextResponse)
    def metrics(session: Session = Depends(db)) -> str:
        """Prometheus exposition.

        Unauthenticated on purpose, like every other /metrics endpoint: a scrape job
        that needs a bearer token is a scrape job nobody configures. It exposes counts
        and rates, never content — no prompt, no finding detail, no identifier.
        """
        from agentfox.exporters.prometheus import render_metrics

        return render_metrics(session)

    @app.get("/api/providers", tags=["platform"])
    def providers(_u=Depends(current_user)) -> dict[str, Any]:
        """The neutrality surface, made inspectable."""
        available = available_providers()
        return {
            "providers": [
                {
                    "key": key,
                    "available": key in available,
                    "default": key == get_settings().default_provider,
                }
                for key in sorted(all_providers())
            ],
            "note": (
                "Hosted providers report unavailable unless AGENTFOX_ALLOW_EGRESS=1 and "
                "a key is configured. Zero egress is the default (NFR-4)."
            ),
        }

    return app


app = create_app()
