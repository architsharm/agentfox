"""What an agent can reach — and whether it adds up to the lethal trifecta.

A list of tool names is not a finding a security owner can act on. "send_email" is
fine. "fetch_url" is fine. "read_customer_record" is fine. All three in the same agent
is the lethal trifecta (Simon Willison's term): the agent can read private data, it
reads content an attacker can write, and it has a way to send data out. An
instruction hidden in a web page can then make it mail the customer table to anyone.
That sentence is the finding; the tool list is the evidence.

So every tool and every MCP server a static scan finds is classified into three flags:

* ``private_data`` — it can read something that is not public (records, files,
  inboxes, databases).
* ``untrusted_input`` — it brings in content someone outside can author (web pages,
  search results, incoming email, issue comments).
* ``exfiltration`` — it can send data out or act irreversibly (send, post, pay,
  refund, delete, write, run a shell command, make an outbound request).

The classification is a name-and-description heuristic, deliberately: this runs on a
repository nobody has imported, and a tool's name is usually the most honest
description of it there is. It reuses
:func:`agentfox.platform.registry.impact.infer_impact`, so the scan and the runtime
agree on what "irreversible" means. It deliberately does not reuse any benchmark's
own list of tool names: a scan that knows a benchmark's tools scores well on that
benchmark and no better on anyone's real tools. A tool whose name says nothing is
left unflagged rather than guessed at, and an MCP server this module does not know is
reported as unknown — never as safe.

Static and offline, like the rest of discovery: MCP server *configs* are read, the
servers are never started.
"""

from __future__ import annotations

import json
import re
from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from agentfox.platform.registry.impact import NOUN_VERBS, actions, handoff
from agentfox.platform.registry.impact import tokens as _impact_tokens

PRIVATE = "private_data"
UNTRUSTED = "untrusted_input"
EXFIL = "exfiltration"
FLAGS = (PRIVATE, UNTRUSTED, EXFIL)

#: How each flag reads to someone who has never heard of the trifecta.
FLAG_LABEL = {
    PRIVATE: "reads private data",
    UNTRUSTED: "reads untrusted content",
    EXFIL: "can send data out or act irreversibly",
}

# -- name vocabulary ---------------------------------------------------------
#
# Matched against whole tokens of the tool name (`read_customer_record` ->
# read, customer, record), never substrings: "drop" in "dropdown" and "send" in
# "sender" are how a substring heuristic produces a wall of nonsense.

_READ_VERBS = {
    "read", "get", "list", "search", "lookup", "find", "query", "load", "retrieve",
    "view", "show", "fetch", "export", "open", "cat", "describe", "check", "inspect",
    "examine",
}  # fmt: skip

_PRIVATE_NOUNS = {
    "customer", "customers", "client", "clients", "user", "users", "account",
    "accounts", "profile", "profiles", "record", "records", "patient", "patients",
    "employee", "employees", "contact", "contacts", "inbox", "email", "emails",
    "mail", "message", "messages", "file", "files", "document", "documents", "doc",
    "docs", "database", "db", "sql", "table", "crm", "invoice", "invoices", "order",
    "orders", "transaction", "transactions", "balance", "payment", "payments",
    "ssn", "secret", "secrets", "credential", "credentials", "password", "salary",
    "ticket", "tickets", "calendar", "event", "events", "note", "notes", "drive",
    "repo", "repository", "history", "memory", "address", "phone", "iban",
    "medical", "health", "card",
}  # fmt: skip

#: Nouns that are about the outside world, so a read verb on them is untrusted input,
#: not private data.
_WEB_NOUNS = {
    "url", "urls", "web", "webpage", "website", "page", "html", "http", "https",
    "internet", "browser", "browse", "scrape", "crawl", "rss", "feed", "google",
    "bing", "serp", "download", "link",
}  # fmt: skip

#: Content an outside party authors even though it arrives through a private system.
_INBOUND_NOUNS = {
    "inbox", "email", "emails", "mail", "message", "messages", "comment", "comments",
    "issue", "issues", "review", "reviews", "ticket", "tickets",
}  # fmt: skip

_EXFIL_VERBS = {
    "send", "post", "publish", "upload", "share", "forward", "reply", "tweet",
    "notify", "webhook", "pay", "refund", "transfer", "wire", "charge", "payout",
    "delete", "drop", "remove", "purge", "truncate", "destroy", "revoke", "write",
    "exec", "execute", "shell", "bash", "deploy", "invite", "sms", "email", "mail",
    "dm", "submit", "push", "withdraw",
}  # fmt: skip

#: Verbs that change a thing without reading anything back from it.
_WRITE_VERBS = {
    "create", "update", "add", "set", "insert", "edit", "modify", "cancel", "schedule",
    "append", "save", "put", "patch",
    # State changes on an existing record: `tickets_close` closes a ticket, it does
    # not read one in, so it is neither private data nor untrusted input.
    "close", "resolve", "reopen", "assign", "archive", "approve", "reject", "merge",
    "rename", "move", "tag", "label", "lock", "unlock", "mark",
}  # fmt: skip

#: Nouns that read wrong with an "s" stuck on ("can read crms"), and what to say.
_MASS_NOUNS = {
    "crm": "CRM records", "db": "the database", "sql": "the database",
    "database": "the database", "history": "history", "memory": "memory",
    "health": "health records", "medical": "medical records", "ssn": "SSNs",
    "drive": "drive files", "repo": "the repository", "repository": "the repository",
    "calendar": "the calendar", "inbox": "the inbox", "mail": "mail",
}  # fmt: skip

#: Words that move money when they act (``issue_refund``, ``list_and_refund``), and the
#: things a tool that acts on them pays out (``issue_compensation``).
_MONEY_VERBS = {
    "pay", "refund", "transfer", "wire", "charge", "payout", "withdraw", "compensate",
    "reimburse", "purchase", "buy",
}  # fmt: skip
_MONEY_NOUNS = {
    "money", "cash", "funds", "compensation", "voucher", "vouchers", "refund", "refunds",
    "reimbursement", "payout", "payment", "payments", "credit", "credits",
}  # fmt: skip
#: A tool that changes something and says it pays out: `start_return`, "Create a
#: return request and refund for an order."
_MONEY_DESCRIPTION = re.compile(
    r"\b(refunds?|refunded|reimburs\w*|compensat\w*|payouts?|vouchers?|send money|"
    r"charges? (?:the|a|their) (?:card|customer|account))\b"
)
#: Commitments a person cannot simply take back: a cancelled flight, a booked one.
_COMMIT_VERBS = {"cancel", "book", "rebook", "purchase", "buy"}


def tokens(name: str) -> list[str]:
    """`readCustomerRecord` / `read-customer.record` -> [read, customer, record]."""
    return _impact_tokens(name)


#: Words that take no plural: "can read user data", never "user datas".
_UNCOUNTABLE = {
    "data", "info", "information", "metadata", "content", "feedback", "status",
    "inventory", "mail", "media", "storage", "config", "configuration", "pii", "news",
    "history", "memory", "knowledge", "analytics", "telemetry",
}  # fmt: skip


def _plural(noun: str) -> str:
    """The plural a sentence needs: "records", "entries", "boxes", "user data"."""
    if noun in _UNCOUNTABLE or noun.endswith("s"):
        return noun
    if noun.endswith("y") and len(noun) > 1 and noun[-2] not in "aeiou":
        return noun[:-1] + "ies"
    if noun.endswith(("x", "z", "ch", "sh")):
        return noun + "es"
    return noun + "s"


@dataclass
class Capabilities:
    """The three flags, with the plain-English phrase behind each one that is set."""

    flags: set[str] = field(default_factory=set)
    #: flag -> how this tool does it, e.g. "can read customer records".
    phrases: dict[str, str] = field(default_factory=dict)
    #: The noun the private data is about ("customer"), for the risk sentence.
    data_noun: str | None = None
    #: What kind of untrusted content ("a web page", "an email").
    source: str | None = None
    #: What the exfiltration channel does in a sentence ("send customer data out").
    action: str | None = None
    #: False for an MCP server this module has no knowledge of.
    known: bool = True

    def ordered(self) -> list[str]:
        return [f for f in FLAGS if f in self.flags]


#: Argument names that are a filesystem path the model fills in.
_PATH_ARGS = {
    "path", "paths", "file", "files", "file_path", "file_paths", "filepath", "filename",
    "file_name", "filenames", "directory", "dir", "dir_path", "directory_path", "folder",
    "folder_path", "source_path", "input_path", "document_path", "doc_path",
}  # fmt: skip
#: A description that says the tool takes a path to a file.
_PATH_DESCRIPTION = re.compile(
    r"\b(?:file|directory|folder)[ _]?path\b|\bpath (?:to|of) (?:the|a|an|any) (?:[\w-]+ ){0,2}"
    r"(?:file|directory|folder|document)\b"
)


def classify_tool(name: str, description: str = "", args: Iterable[str] = ()) -> Capabilities:
    """Classify one tool by its name, falling back to its description.

    ``args``, the tool function's argument names when the code shows them, add one
    shape a name rarely says: a tool that opens whatever path the model gives it
    (`markdown_validation_tool(file_path)`) reads any file this process can, which is
    private data whatever the tool is called.
    """
    caps = _classify_by_name(name, description)
    if PRIVATE in caps.flags:
        return caps
    desc = (description or "").lower()
    by_arg = any(a.lower() in _PATH_ARGS for a in args)
    if not (by_arg or _PATH_DESCRIPTION.search(desc)):
        return caps
    toks = set(tokens(name))
    writes = bool(toks & (_WRITE_VERBS | {"write", "delete", "remove"})) and not toks & _READ_VERBS
    if writes or UNTRUSTED in caps.flags:
        return caps
    caps.flags.add(PRIVATE)
    caps.phrases[PRIVATE] = "can read any file path it is given"
    caps.data_noun = caps.data_noun or "file"
    return caps


def _classify_by_name(name: str, description: str = "") -> Capabilities:
    """The name- and description-only classification behind :func:`classify_tool`."""
    from agentfox.platform.registry.impact import infer_impact

    toks = tokens(name)
    tset = set(toks)
    desc = (description or "").lower()
    caps = Capabilities()

    # -- can it send something out, or do something it cannot undo? ----------
    reads = bool(tset & _READ_VERBS)
    # The words that act, read as verb phrases: "email" acts in `email_customer` and
    # `fetch_and_email_report` and is what is read in `read_email`; "issue" acts in
    # `issue_compensation` and is read in `get_issue`.
    acting = set(actions(toks))
    # `transfer_to_human` hands a conversation to a person: it moves no money.
    passing = handoff(toks)
    if passing:
        acting.discard("transfer")
    exfil_hits = [
        t
        for t in toks
        if t in _EXFIL_VERBS
        and (t in acting or t not in NOUN_VERBS)
        and not (passing and t == "transfer")
    ]
    money = bool(acting & _MONEY_VERBS) or (
        bool(acting) and not passing and bool(tset & _MONEY_NOUNS)
    )
    # A change whose description says it pays out (`start_return`: "... and refund").
    if not money and acting and not reads and _MONEY_DESCRIPTION.search(desc):
        money = True
    committed = bool(acting & _COMMIT_VERBS)
    if (
        exfil_hits
        or money
        or committed
        # Name only, and only for a name that is not a read: a description saying
        # "the sender's address" is not a send, and neither is `get_sender`.
        or (not reads and infer_impact(name) == "irreversible")
    ):
        caps.flags.add(EXFIL)
        caps.phrases[EXFIL], caps.action = (
            ("can move money", "move money") if money else _exfil_phrase(tset)
        )

    # -- does it bring in content an outsider can write? ---------------------
    # `create_ticket` and `post_webpage` write to those things; they read nothing in.
    reading = reads or not (
        exfil_hits or money or committed or tset & _WRITE_VERBS or acting & {"issue", "start"}
    )
    # What the name is about: its words, less the ones that act.
    about = tset - acting
    web = reading and bool(about & _WEB_NOUNS or ("fetch" in tset and not (about & _PRIVATE_NOUNS)))
    inbound = about & _INBOUND_NOUNS if reading else set()
    if (
        reading
        and not web
        and not inbound
        and re.search(
            r"\b(web ?page|website|url|internet|web (?:results?|search|content)|search engine)\b",
            desc,
        )
    ):
        web = True
    if web:
        caps.flags.add(UNTRUSTED)
        caps.phrases[UNTRUSTED] = "reads untrusted web pages"
        caps.source = "a web page"
    elif inbound:
        caps.flags.add(UNTRUSTED)
        noun = sorted(inbound)[0]
        if noun in ("inbox", "email", "emails", "mail"):
            caps.phrases[UNTRUSTED] = "reads incoming email"
            caps.source = "an email"
        else:
            caps.phrases[UNTRUSTED] = f"reads {_plural(noun)} other people write"
            caps.source = f"a {noun.rstrip('s')}"

    # -- does it read something private? -------------------------------------
    nouns = [t for t in toks if t in _PRIVATE_NOUNS and t in about]
    if nouns and reading and not web:
        caps.flags.add(PRIVATE)
        # "read_customer_record" -> "customer records": every non-verb token, in order.
        verbs = _READ_VERBS | _WRITE_VERBS | _EXFIL_VERBS
        subject = " ".join(t for t in toks if t not in verbs or t in nouns)
        subject = subject or nouns[0]
        words = subject.split()
        words[-1] = _MASS_NOUNS.get(words[-1]) or _plural(words[-1])
        caps.phrases[PRIVATE] = f"can read {' '.join(words)}"
        noun = nouns[0]
        caps.data_noun = {"crm": "CRM", "db": "database", "sql": "database"}.get(noun) or (
            noun if noun in ("ssn", "credentials", "address") else noun.rstrip("s")
        )
    elif (
        not nouns
        and reading
        and not web
        and re.search(
            r"\b(customer|patient|personal|private|confidential|pii|account holder)\b", desc
        )
    ):
        caps.flags.add(PRIVATE)
        caps.phrases[PRIVATE] = "reads private data"
    return caps


def _exfil_phrase(tset: set[str]) -> tuple[str, str]:
    """(what it can do, what an attacker could make it do) for an exfiltration tool."""
    if tset & {"pay", "refund", "transfer", "wire", "charge", "payout", "money", "withdraw"}:
        return "can move money", "move money"
    if tset & {"email", "mail"}:
        return "can send email", "send {data} out"
    if tset & {"sms", "dm", "message", "messages", "notify", "slack", "tweet"}:
        return "can send messages", "send {data} out"
    if tset & {"delete", "drop", "remove", "purge", "truncate", "destroy"}:
        return "can delete data", "delete data"
    if tset & {"exec", "execute", "shell", "bash", "command"}:
        return "can run shell commands", "run commands on this machine"
    if tset & {"post", "webhook", "http", "request", "upload", "publish", "share", "push"}:
        return "can send data to other systems", "send {data} out"
    if tset & {"write"}:
        return "can write files", "write {data} somewhere it can be read"
    return "can act irreversibly", "act on {data}"


# ---------------------------------------------------------------------------
# MCP servers, from config
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class McpConfigFile:
    """One place an MCP client keeps its server list, relative to a project root."""

    #: Relative path, ``/``-separated. A file found anywhere under a scanned tree
    #: matches when its path ends with this one.
    path: str
    #: The client that reads it (``""`` for the cross-client ``.mcp.json`` convention).
    client: str

    def matches(self, path: Path) -> bool:
        parts = tuple(self.path.split("/"))
        return path.parts[-len(parts) :] == parts


#: Every MCP client config file discovery knows how to read, in the order
#: `agentfox scan mcp` lists them. Each one is a file the scanner can open without
#: starting anything.
#:
#: Owned here, not by the harness adapters: finding which MCP servers a repository
#: declares is discovery, not harness governance, and a connected repository is scanned
#: by `capabilities/monitoring`, which sits below the adapters. An adapter reports its
#: own rows with `config_files_for(<client>)`.
KNOWN_MCP_CONFIGS: tuple[McpConfigFile, ...] = (
    McpConfigFile(".mcp.json", ""),
    McpConfigFile("mcp.json", ""),
    McpConfigFile(".cursor/mcp.json", "cursor"),
    McpConfigFile(".claude/settings.json", "claude-code"),
    McpConfigFile(".claude/settings.local.json", "claude-code"),
    McpConfigFile(".claude.json", "claude-code"),
    McpConfigFile("claude_desktop_config.json", "claude-desktop"),
    McpConfigFile("mcp_settings.json", "cline"),
)


def config_files_for(client: str) -> tuple[McpConfigFile, ...]:
    """The rows of :data:`KNOWN_MCP_CONFIGS` one client reads."""
    return tuple(row for row in KNOWN_MCP_CONFIGS if row.client == client)


def is_mcp_config(path: Path) -> bool:
    """True when ``path`` is one of :data:`KNOWN_MCP_CONFIGS`, wherever it sits."""
    return any(row.matches(path) for row in KNOWN_MCP_CONFIGS)


#: Known servers, matched against the server's name and how it is launched (package
#: name, image, URL). The order matters: the first match wins, so the specific names
#: come before the generic ones. Flags are what the server is *for*; an operator can
#: always narrow it with the real tool list (`agentfox scan mcp NAME --file`).
_KnownServer = tuple[tuple[str, ...], set[str], dict[str, str], str | None, str | None]
_KNOWN_SERVERS: tuple[_KnownServer, ...] = (
    (
        ("gmail", "outlook", "email", "imap"),
        {PRIVATE, UNTRUSTED, EXFIL},
        {PRIVATE: "reads your mailbox", UNTRUSTED: "reads incoming email", EXFIL: "can send email"},
        "an email",
        "send {data} out",
    ),
    (
        ("slack", "discord", "teams", "telegram", "whatsapp"),
        {PRIVATE, UNTRUSTED, EXFIL},
        {
            PRIVATE: "reads private channels",
            UNTRUSTED: "reads messages other people write",
            EXFIL: "can post messages",
        },
        "a chat message",
        "send {data} out",
    ),
    (
        ("github", "gitlab", "bitbucket", "linear", "jira", "atlassian", "notion", "asana"),
        {PRIVATE, UNTRUSTED, EXFIL},
        {
            PRIVATE: "reads private repositories and tickets",
            UNTRUSTED: "reads issues and comments anyone can write",
            EXFIL: "can create issues, comments and pull requests",
        },
        "an issue comment",
        "publish {data}",
    ),
    (
        (
            "fetch",
            "browser",
            "puppeteer",
            "playwright",
            "web-search",
            "websearch",
            "brave-search",
            "brave",
            "tavily",
            "exa",
            "firecrawl",
            "perplexity",
            "serp",
            "scrape",
            "crawl",
            "duckduckgo",
        ),
        {UNTRUSTED, EXFIL},
        {
            UNTRUSTED: "reads untrusted web pages",
            EXFIL: "can send data out in the URLs it requests",
        },
        "a web page",
        "send {data} out",
    ),
    (
        ("filesystem", "file-system", "files", "fs"),
        {PRIVATE, EXFIL},
        {PRIVATE: "reads files on this machine", EXFIL: "can write and overwrite files"},
        None,
        "write {data} somewhere it can be read",
    ),
    (
        (
            "postgres",
            "postgresql",
            "mysql",
            "sqlite",
            "mongodb",
            "mongo",
            "supabase",
            "database",
            "redis",
            "bigquery",
            "snowflake",
            "db",
        ),
        {PRIVATE, EXFIL},
        {PRIVATE: "reads a database", EXFIL: "can modify or delete rows"},
        None,
        "delete data",
    ),
    (
        ("shell", "terminal", "desktop-commander", "exec", "bash", "computer-use"),
        {PRIVATE, EXFIL},
        {PRIVATE: "reads anything on this machine", EXFIL: "can run shell commands"},
        None,
        "run commands on this machine",
    ),
    (
        ("git",),
        {PRIVATE},
        {PRIVATE: "reads the git repository"},
        None,
        None,
    ),
    (
        ("memory", "knowledge-graph"),
        {PRIVATE},
        {PRIVATE: "reads what earlier sessions stored"},
        None,
        None,
    ),
)

#: Servers known to touch nothing private and send nothing out.
_INERT_SERVERS = ("time", "everything", "sequential-thinking", "sequentialthinking", "calculator")


#: Shells a config may wrap a launcher in (`/bin/sh -c "npx -y pkg"`), and the
#: launchers that fetch a package to run.
_SHELLS = {"sh", "bash", "zsh", "dash"}
_LAUNCHERS = {"npx", "pnpx", "bunx", "uvx", "pipx", "docker"}


@dataclass
class McpServerDecl:
    """One MCP server as a client config declares it. Nothing here was executed."""

    name: str
    config: str  # path of the config file, relative to the scan root when possible
    command: str = ""
    args: list[str] = field(default_factory=list)
    url: str = ""
    transport: str = "stdio"
    headers: dict[str, Any] = field(default_factory=dict)
    env: dict[str, Any] = field(default_factory=dict)
    #: The config sets up an OAuth login for it (Claude Code's and Gemini CLI's
    #: `oauth`, an `auth` block), or a token read from the environment (Codex's
    #: `bearer_token_env_var`): it authenticates, just not with a header written here.
    oauth: bool = False

    @property
    def launch(self) -> str:
        """How the server starts, in one line, without any env values."""
        if self.url:
            return self.url
        return " ".join([self.command, *self.args]).strip()

    @property
    def effective(self) -> tuple[str, list[str]]:
        """``(command, args)`` of what actually starts: a shell wrapper
        (`/bin/sh -c "npx -y @scope/pkg"`) runs the command in its string."""
        import shlex

        if Path(self.command).name in _SHELLS:
            for i, arg in enumerate(self.args[:-1]):
                if arg.startswith("-") and "c" in arg.lstrip("-"):
                    try:
                        words = shlex.split(self.args[i + 1])
                    except ValueError:
                        break
                    # `exec npx ...`, `cd x && npx ...`: the first launcher named.
                    for j, word in enumerate(words):
                        if Path(word).name in _LAUNCHERS:
                            rest = []
                            for w in words[j + 1 :]:
                                if w in ("&&", "||", ";", "|"):
                                    break
                                rest.append(w)
                            return word, rest
                    break
        return self.command, list(self.args)

    @property
    def package(self) -> str:
        """The package the launcher runs (`npx -y @scope/pkg@1.2` -> `@scope/pkg@1.2`)."""
        command, args = self.effective
        launcher = Path(command).name
        positional = [a for a in args if not a.startswith("-")]
        if launcher in ("npx", "pnpx", "bunx", "uvx", "pipx") and positional:
            return (
                positional[0]
                if launcher != "pipx" or positional[0] != "run"
                else (positional[1] if len(positional) > 1 else "")
            )
        if launcher == "docker" and "run" in positional:
            images = [a for a in positional if a != "run"]
            return images[0] if images else ""
        return ""

    @property
    def pinned_version(self) -> str | None:
        """The version the config pins, or None if it floats."""
        pkg = self.package
        if not pkg:
            return None
        launcher = Path(self.effective[0]).name
        if launcher == "docker":
            if "@sha256:" in pkg:
                return pkg.split("@sha256:")[1][:16]
            tag = pkg.rsplit(":", 1)[1] if ":" in pkg.split("/")[-1] else ""
            return tag if tag and tag != "latest" else None
        if launcher in ("uvx", "pipx"):
            match = re.search(r"==([\w.]+)", pkg)
            return match.group(1) if match else None
        # npm: @scope/name@1.2.3 or name@1.2.3 — the leading @ of a scope is not a pin.
        body = pkg[1:] if pkg.startswith("@") else pkg
        if "@" in body:
            version = body.rsplit("@", 1)[1]
            return version if version and version not in ("latest", "next") else None
        return None

    def to_json(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "config": self.config,
            "transport": self.transport,
            "launch": self.launch,
            "package": self.package or None,
            "pinned_version": self.pinned_version,
            # Names only: an env value is where a config keeps its token.
            "env_keys": sorted(self.env),
        }


def _strip_jsonc(text: str) -> str:
    """JSON with comments and trailing commas (VS Code's settings and mcp.json) as JSON.

    Comments are removed only outside strings, so a URL's ``//`` survives.
    """
    out: list[str] = []
    i, n, in_string = 0, len(text), False
    while i < n:
        ch = text[i]
        if in_string:
            out.append(ch)
            if ch == "\\" and i + 1 < n:
                out.append(text[i + 1])
                i += 2
                continue
            if ch == '"':
                in_string = False
            i += 1
            continue
        if ch == '"':
            in_string = True
            out.append(ch)
            i += 1
        elif text.startswith("//", i):
            end = text.find("\n", i)
            i = n if end == -1 else end
        elif text.startswith("/*", i):
            end = text.find("*/", i + 2)
            i = n if end == -1 else end + 2
        else:
            out.append(ch)
            i += 1
    return re.sub(r",(\s*[}\]])", r"\1", "".join(out))


def _load_config(path: Path) -> dict[str, Any] | None:
    """A client config file as a dict: JSON, JSON with comments, or Codex's TOML."""
    try:
        text = path.read_text(errors="ignore")
    except OSError:
        return None
    if path.suffix == ".toml":
        import tomllib

        try:
            data: Any = tomllib.loads(text)
        except ValueError:
            return None
    else:
        try:
            data = json.loads(text)
        except ValueError:
            try:
                data = json.loads(_strip_jsonc(text))
            except ValueError:
                return None
    return data if isinstance(data, dict) else None


def _server_block(data: dict[str, Any]) -> dict[str, Any]:
    """The servers a config declares at its top level, by name.

    ``mcpServers`` (Claude, Cursor, Windsurf, Gemini CLI, Cline), ``servers`` (VS Code's
    mcp.json), ``mcp.servers`` (VS Code's settings.json) and ``mcp_servers`` (Codex's
    config.toml).
    """
    block: dict[str, Any] = {}
    candidates = [data.get("mcpServers"), data.get("servers"), data.get("mcp_servers")]
    if isinstance(data.get("mcp"), dict):
        candidates.append(data["mcp"].get("servers"))
    for candidate in candidates:
        if isinstance(candidate, dict):
            for name, entry in candidate.items():
                block.setdefault(str(name), entry)
    return block


def _decl(name: str, entry: Any, label: str) -> McpServerDecl:
    entry = entry if isinstance(entry, dict) else {}
    url = str(entry.get("url") or entry.get("serverUrl") or entry.get("httpUrl") or "")
    transport = str(entry.get("type") or entry.get("transport") or "")
    if not transport:
        transport = "http" if url else "stdio"
    args = entry.get("args") or []
    headers = entry.get("headers") or entry.get("http_headers")
    return McpServerDecl(
        name=name,
        config=label,
        command=str(entry.get("command") or ""),
        args=[str(a) for a in args] if isinstance(args, list) else [],
        url=url,
        transport=transport,
        headers=headers if isinstance(headers, dict) else {},
        env=entry.get("env") if isinstance(entry.get("env"), dict) else {},
        oauth=any(entry.get(k) for k in ("oauth", "auth", "bearer_token_env_var")),
    )


def _label(path: Path, root: Path | None) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve())) if root else str(path)
    except ValueError:
        return str(path)


def parse_mcp_config(path: Path, *, root: Path | None = None) -> list[McpServerDecl]:
    """Every server one config file declares. Unreadable or non-MCP config -> []."""
    data = _load_config(path)
    if data is None:
        return []
    label = _label(path, root)

    blocks: list[dict[str, Any]] = [_server_block(data)]
    # A user-level config may keep per-project servers under projects.<path>.mcpServers.
    projects = data.get("projects")
    if isinstance(projects, dict):
        for project in projects.values():
            if isinstance(project, dict) and isinstance(project.get("mcpServers"), dict):
                blocks.append(project["mcpServers"])

    servers: list[McpServerDecl] = []
    seen: set[str] = set()
    for block in blocks:
        for name, entry in block.items():
            if name in seen:
                continue
            seen.add(name)
            servers.append(_decl(str(name), entry, label))
    return servers


def mcp_loadouts(path: Path, *, label: str) -> list[tuple[str, list[McpServerDecl]]]:
    """The sets of servers from one config that a single client session loads together.

    Servers in one loadout share a model, so together they can make a lethal trifecta
    that none of them is alone. Most configs are one loadout. Claude Code's
    ``~/.claude.json`` is several: its top-level servers load in every project, and
    each ``projects.<path>.mcpServers`` block loads only in that project, alongside the
    top-level ones. Treating the whole file as one set would report a trifecta between
    two projects' servers that are never loaded at the same time.
    """
    data = _load_config(path)
    if data is None:
        return []
    everywhere = [_decl(str(n), e, label) for n, e in _server_block(data).items()]
    loadouts: list[tuple[str, list[McpServerDecl]]] = []
    if everywhere:
        loadouts.append((label, everywhere))
    projects = data.get("projects")
    if isinstance(projects, dict):
        for project_path, project in projects.items():
            if not isinstance(project, dict) or not isinstance(project.get("mcpServers"), dict):
                continue
            local = [_decl(str(n), e, label) for n, e in project["mcpServers"].items()]
            if not local:
                continue
            names = {d.name for d in local}
            merged = local + [d for d in everywhere if d.name not in names]
            loadouts.append((f"{label} (project {project_path})", merged))
    return loadouts


def find_mcp_configs(root: Path) -> list[Path]:
    """The MCP client configs at a repository's root, in :data:`KNOWN_MCP_CONFIGS`
    order. Only files that exist; nothing is walked below these fixed locations."""
    return [root / row.path for row in KNOWN_MCP_CONFIGS if (root / row.path).is_file()]


def declared_mcp_servers(root: Path, config: Path | None = None) -> list[McpServerDecl]:
    """Every server the repository's MCP configs declare (or ``config`` alone), once
    each by name: the first config to declare a name, in :func:`find_mcp_configs`
    order, wins."""
    declared: dict[str, McpServerDecl] = {}
    for path in [config] if config is not None else find_mcp_configs(root):
        for decl in parse_mcp_config(path, root=root):
            declared.setdefault(decl.name, decl)
    return list(declared.values())


def _haystack(decl: McpServerDecl) -> set[str]:
    words = set(tokens(decl.name)) | {decl.name.lower()}
    for part in (decl.package, decl.url, decl.command):
        if part:
            lowered = part.lower()
            words |= set(tokens(lowered)) | {lowered}
            # "@modelcontextprotocol/server-filesystem" -> "filesystem";
            # "mcp-server-fetch" -> "fetch".
            tail = lowered.split("/")[-1].split("@")[0].split("==")[0].split(":")[0]
            words.add(tail)
            for prefix in ("server-", "mcp-server-", "mcp-"):
                if tail.startswith(prefix):
                    words.add(tail[len(prefix) :])
            for suffix in ("-mcp-server", "-mcp", "-server", "_mcp"):
                if tail.endswith(suffix):
                    words.add(tail[: -len(suffix)])
    return words


def classify_mcp_server(decl: McpServerDecl) -> Capabilities:
    """Classify a server from how it is declared. Unknown is said, never guessed."""
    words = _haystack(decl)
    for markers, flags, phrases, source, action in _KNOWN_SERVERS:
        if words & set(markers):
            return Capabilities(
                flags=set(flags),
                phrases=dict(phrases),
                data_noun=None,
                source=source,
                action=action,
            )
    if words & set(_INERT_SERVERS):
        return Capabilities()
    return Capabilities(known=False)


def server_hygiene(decl: McpServerDecl) -> list[dict[str, str]]:
    """Problems visible in the config itself, no tool list needed."""
    issues: list[dict[str, str]] = []
    if decl.url:
        if decl.url.startswith("http://") and not re.match(
            r"http://(localhost|127\.0\.0\.1|\[::1\])", decl.url
        ):
            issues.append(
                {
                    "type": "plaintext_remote",
                    "severity": "high",
                    "detail": "remote server over plain http — traffic and tokens are readable",
                }
            )
        has_auth = any(k.lower() in ("authorization", "x-api-key", "api-key") for k in decl.headers)
        if not has_auth and not re.search(r"[?&](key|token|api_key)=", decl.url):
            # Over HTTPS, no header is the normal shape of a remote server: the MCP
            # standard for remote servers is an OAuth login the client runs and keeps
            # out of the config. Said for information, not as something to fix. Over
            # plain http (already high above) it stays something to check.
            if decl.oauth:
                issues.append(
                    {
                        "type": "remote_without_auth",
                        "severity": "info",
                        "detail": "signs in with OAuth, set up in the config",
                    }
                )
            elif decl.url.startswith("https://"):
                issues.append(
                    {
                        "type": "remote_without_auth",
                        "severity": "info",
                        "detail": "no auth header in the config: remote servers normally "
                        "sign in with OAuth, which the client keeps out of the config — "
                        "check it asked you to log in",
                    }
                )
            else:
                issues.append(
                    {
                        "type": "remote_without_auth",
                        "severity": "medium",
                        "detail": "remote server with no auth header in the config — anyone "
                        "who can reach it can call it, or it relies on an OAuth login this "
                        "scan cannot see",
                    }
                )
    elif decl.command and decl.pinned_version is None:
        launcher = Path(decl.effective[0]).name
        if launcher in ("npx", "pnpx", "bunx", "uvx", "pipx", "docker"):
            issues.append(
                {
                    "type": "unpinned_server",
                    "severity": "medium",
                    "detail": f"no version pinned ({launcher} fetches whatever is newest) "
                    "— its tools can change after you review them",
                }
            )
    for key, value in decl.env.items():
        text = str(value)
        if (
            text
            and not text.startswith("${")
            and re.search(r"(?:sk-|ghp_|github_pat_|xox[bpa]-|AKIA|AIza)[\w-]{8,}", text)
        ):
            issues.append(
                {
                    "type": "secret_in_config",
                    "severity": "high",
                    "detail": f"{key} holds a literal credential in the config file",
                }
            )
    broad = {"/", "~", "$HOME", "${HOME}", "/Users", "/home", "C:\\"}
    if any(arg in broad for arg in decl.args):
        issues.append(
            {
                "type": "broad_filesystem_access",
                "severity": "high",
                "detail": "given the whole disk or home directory, not a project folder",
            }
        )
    return issues


# ---------------------------------------------------------------------------
# The trifecta
# ---------------------------------------------------------------------------


@dataclass
class Member:
    """One tool or server taking part in a trifecta group."""

    name: str
    caps: Capabilities
    file: str
    line: int


def trifecta_sentence(
    label: str, members: list[Member], *, unknown: Iterable[str] = ()
) -> tuple[str, dict[str, list[str]]] | None:
    """The plain-English finding for one group, or None if the group lacks a leg.

    ``label`` names the group (a file, a directory, a config file). Returns the
    sentence and, per flag, which members supply it.
    """
    by_flag: dict[str, list[Member]] = {f: [] for f in FLAGS}
    for member in members:
        for flag in member.caps.flags:
            by_flag[flag].append(member)
    # Lead with the channel that carries data *out*: it is the one that makes the
    # sentence true, and the one the containment hint should name.
    by_flag[EXFIL].sort(key=lambda m: not (m.caps.action or "").startswith("send"))
    if not all(by_flag[f] for f in FLAGS):
        return None

    def clause(flag: str) -> str:
        # Group members that say the same thing: "can send email (send_email, reply_email)".
        groups: dict[str, list[str]] = {}
        for member in by_flag[flag]:
            phrase = member.caps.phrases.get(flag, FLAG_LABEL[flag])
            groups.setdefault(phrase, []).append(member.name)
        parts = []
        for phrase, names in list(groups.items())[:2]:
            more = ", …" if len(names) > 3 else ""
            parts.append(f"{phrase} ({', '.join(names[:3])}{more})")
        return " or ".join(parts)

    private = by_flag[PRIVATE][0].caps
    data = f"{private.data_noun} data" if private.data_noun else "private data"
    source = next((m.caps.source for m in by_flag[UNTRUSTED] if m.caps.source), "that content")
    action = next((m.caps.action for m in by_flag[EXFIL] if m.caps.action), "send {data} out")
    sentence = (
        f"{label}: {clause(PRIVATE)}, {clause(UNTRUSTED)}, and {clause(EXFIL)}. "
        f"An instruction hidden in {source} could {action.format(data=data)}."
    )
    unknown = list(unknown)
    if unknown:
        sentence += (
            f" ({len(unknown)} more server(s) here could not be classified: "
            f"{', '.join(unknown[:4])}.)"
        )
    evidence = {f: [m.name for m in by_flag[f]] for f in FLAGS}
    return sentence, evidence


def containment_hint(
    evidence: dict[str, list[str]], *, mcp: bool = False, agent: str | None = None
) -> str:
    """The next command, naming the tool that should be contained and, when the scan
    knows it, the agent that holds it (its slug, as `agentfox up` registers it).

    Without an agent the command still has to be one a reader can complete, so the
    placeholder is spelled as one (AGENT) and said to be the agent's name.
    """
    channel = (evidence.get(EXFIL) or ["<tool>"])[0]
    who = agent or "AGENT"
    where = "" if agent else " (AGENT: the name the agent is registered under)"
    if mcp:
        return (
            "Contain it: don't load these servers together in one client, or put the "
            f"agent behind AgentFox and run `agentfox permit grant {who} "
            f"mcp:{channel}/* --max-taint user`{where} so nothing read from the web "
            f"reaches '{channel}' without an approval."
        )
    return (
        f"Contain it: `agentfox permit grant {who} {channel} --max-taint user`{where} "
        f"(anything derived from untrusted content needs an approval before it reaches "
        f"{channel}). Under `agentfox.auto()` it is recorded while Tool containment "
        "watches, and stopped once `agentfox policy enforce tool-containment` makes it block."
    )
