"""What `agentfox up` can set up, one component per line of the "what to include" list.

A component has three parts:

* ``unavailable`` — why it cannot be picked here (a remote target, no Enterprise, no
  GitHub remote), or "" when it can. Shown greyed out with the reason, so a person
  sees what exists and what it would take, rather than a shorter list.
* ``ask`` — its follow-up questions. All of them run before anything is changed, so
  a person answers everything first and then watches it happen.
* ``apply`` — the change itself, through the run's backend. A failure is reported
  and the next component still runs.

Defaults come from the scan: a component is pre-ticked when the repository shows a
reason for it.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import webbrowser
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import httpx
from rich.console import Console
from rich.markup import escape

from agentfox.apps.cli.wizard.backend import BackendError, Edition, Local
from agentfox.apps.cli.wizard.detect import STATE_DIR, Context, git_ignore
from agentfox.apps.cli.wizard.prompt import Choice, Prompter
from agentfox.apps.cli.wizard.targets import Target
from agentfox.capabilities.onboarding.project_files import _AUTO_MARK, insert_auto  # noqa: F401

IMPACTS = ("read", "write", "high_impact", "irreversible")

#: Safety modes: the second question, after what to include.
MODES = (
    Choice(
        "observe",
        "Watch first",
        "Policies record what they would block and block nothing. Destructive commands, "
        "protected paths and tampering are still stopped.",
    ),
    Choice(
        "defaults",
        "Shipped defaults",
        "Tool containment blocks (a payment with no stated task waits for a person); "
        "detectors watch.",
    ),
    Choice(
        "enforce",
        "Enforce everything",
        "Every policy blocks what it would block. For a project you already trust.",
    ),
)


@dataclass
class Outcome:
    component: str
    status: str  # "done" | "skipped" | "failed"
    detail: str


@dataclass
class Run:
    ctx: Context
    target: Target
    prompter: Prompter
    console: Console
    agent: str
    mode: str = "observe"
    #: Start background processes (hook daemon, local API). Off for --no-start and tests.
    start: bool = True
    interactive: bool = False
    #: The components chosen, so one can tell whether another will run.
    picked: list[str] = field(default_factory=list)
    #: Per-component answers from `ask`, keyed by component key.
    answers: dict[str, Any] = field(default_factory=dict)
    env: dict[str, str] = field(default_factory=dict)
    outcomes: list[Outcome] = field(default_factory=list)
    next_steps: list[tuple[str, str]] = field(default_factory=list)
    #: After the first look: review, tighten. Listed below `next_steps`.
    later_steps: list[tuple[str, str]] = field(default_factory=list)
    running: list[str] = field(default_factory=list)
    #: The tools of the agent being set up and the agents it hands work to, as the
    #: scan found them; None when the scan found no agent to scope them to (then every
    #: tool in the repository is the agent's).
    system_tools: list[str] | None = None
    #: The agents of that system (scan keys), same None rule: an agent another uses as
    #: a tool is declared for this agent only when it is one of them.
    system_members: list[str] | None = None
    _edition: Edition | None = field(default=None, repr=False)

    @property
    def edition(self) -> Edition:
        """What the control plane can do, asked once."""
        if self._edition is None:
            try:
                self._edition = self.target.backend.edition()
            except BackendError:
                self._edition = Edition("open-source")
        return self._edition

    def say(self, text: str) -> None:
        self.console.print(f"    {text}")

    def done(self, component: str, detail: str) -> None:
        self.outcomes.append(Outcome(component, "done", detail))
        self.console.print(f"  [green]✓[/] {detail}")

    def skipped(self, component: str, detail: str) -> None:
        self.outcomes.append(Outcome(component, "skipped", detail))
        self.console.print(f"  [dim]–[/] {detail}")

    def failed(self, component: str, detail: str) -> None:
        self.outcomes.append(Outcome(component, "failed", detail))
        self.console.print(f"  [red]✗[/] {escape(detail)}")


@dataclass
class Component:
    key: str
    label: str
    note: Callable[[Run], str]
    unavailable: Callable[[Run], str]
    recommended: Callable[[Run], bool]
    apply: Callable[[Run], None]
    ask: Callable[[Run], None] | None = None
    #: An AgentFox Enterprise feature: left out of the list where it is not available,
    #: rather than shown greyed out, so a first run is not a list of upsells.
    enterprise: bool = False


def _never(_run: Run) -> str:
    return ""


def plural(n: int, word: str) -> str:
    if n == 1:
        return f"{n} {word}"
    return f"{n} {word[:-1]}ies" if word.endswith("y") else f"{n} {word}s"


# ---------------------------------------------------------------------------
# Background processes
# ---------------------------------------------------------------------------


def _spawn(run: Run, name: str, args: list[str]) -> bool:
    """Start ``agentfox <args>`` detached, logging to .agentfox/logs/<name>.log."""
    logs = run.ctx.root / STATE_DIR / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    log = (logs / f"{name}.log").open("ab")
    env = {**os.environ, **run.env}
    try:
        process = subprocess.Popen(
            [sys.executable, "-m", "agentfox.apps.cli.main", *args],
            stdout=log,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            cwd=run.ctx.root,
            env=env,
            start_new_session=True,
        )
    except OSError as exc:
        run.say(f"[red]could not start {name}:[/] {exc}")
        return False
    (run.ctx.root / STATE_DIR / f"{name}.pid").write_text(str(process.pid))
    for entry in (f"{STATE_DIR}/logs/", f"{STATE_DIR}/*.pid"):
        git_ignore(run.ctx.root, entry)
    run.running.append(f"{name} (pid {process.pid}, log .agentfox/logs/{name}.log)")
    return True


def _api_up(url: str) -> bool:
    try:
        return httpx.get(f"{url}/api/health", timeout=2).status_code == 200
    except httpx.HTTPError:
        return False


def _started_here(run: Run, name: str) -> bool:
    """A background process `up` started for this project, still alive."""
    try:
        pid = int((run.ctx.root / STATE_DIR / f"{name}.pid").read_text())
        os.kill(pid, 0)
    except (OSError, ValueError):
        return False
    return True


def _ensure_local_api(run: Run) -> bool:
    """The local API is up on this machine's database: one `up` started for this
    project, one any `agentfox serve` of this installation runs on the same database
    (another project's `up`, say: every project shares ~/.agentfox), or a new one.
    Something else answering on the port is not claimed, and is described as what it
    is known to be, never guessed at."""
    if _api_up(run.target.api_url):
        if _started_here(run, "serve"):
            return True
        from agentfox.apps.cli.commands.root import running_serve
        from agentfox.core.config import get_settings

        record = running_serve()
        port = int(run.target.api_url.rsplit(":", 1)[-1].split("/")[0] or 0)
        if record and int(record.get("port") or 0) == port:
            if record.get("database") == get_settings().database_url:
                run.say(
                    f"[dim]reusing the API already running at {run.target.api_url} "
                    f"(pid {record['pid']}) — same database[/]"
                )
                return True
            run.say(
                f"[yellow]{run.target.api_url} is an `agentfox serve` (pid {record['pid']}) "
                f"on another database[/] ({record.get('database')}). Stop it, or run `up` "
                "with the same AGENTFOX_DATABASE_URL."
            )
            return False
        run.say(
            f"[yellow]something else answers at {run.target.api_url}[/] — not an "
            "`agentfox serve` this installation started (a self-hosted stack, or another "
            "program on the port). Stop it, or connect to it: "
            "`agentfox up --target self-hosted`."
        )
        return False
    if not run.start:
        run.next_steps.append(("agentfox serve", "the gateway and API, for the integrations above"))
        return False
    if not _spawn(run, "serve", ["serve"]):
        return False
    import time

    for _ in range(40):
        if _api_up(run.target.api_url):
            return True
        time.sleep(0.25)
    return False


# ---------------------------------------------------------------------------
# Scan report
# ---------------------------------------------------------------------------


def _scan_note(run: Run) -> str:
    return "counts and top-level folders only — never code, paths or line numbers"


def _scan_label(run: Run) -> str:
    """The repository's name in a recorded scan: its proposals are ``<label>/<agent>``."""
    return run.ctx.github_repo or run.ctx.project


def _register(run: Run) -> None:
    """Register the agent `up` runs under as the agent the scan finds in the same code:
    the name the scan gives it (``<repo>/<agent>``, so the scan's proposal lands on this
    agent instead of beside it, see ``registry.service.propose_from_scan``), its
    framework, the tools it is handed (what `agentfox test redteam` attacks through),
    and the repository `agentfox init` maps it from. Development: it runs here."""
    from agentfox.capabilities.onboarding.mapper import _project_name, project_name_for
    from agentfox.platform.registry.service import slugify

    spec = next((a for a in run.ctx.report.agents if slugify(a.name or a.key) == run.agent), None)
    tools = list(spec.tools) if spec is not None else []
    if "tools" in run.picked:
        # `_tools_apply` grants each found tool to this agent: declared alike.
        tools += list(run.answers.get("tools") or _inferred(run))
    run.target.backend.register_agent(
        run.agent,
        environment="development",
        framework=spec.framework if spec is not None else None,
        name=(f"{_scan_label(run)}/{spec.name or slugify(spec.key)}" if spec is not None else None),
        declared_tools=list(dict.fromkeys(tools)) or None,
        # Its app's name (nearest pyproject), as `init` and a submitted scan group it.
        project=(
            project_name_for(run.ctx.root, spec.file)
            if spec is not None
            else _project_name(run.ctx.root)
        ),
    )


def _apply_scan(run: Run) -> None:
    # A local database is this machine: each agent's tool names may go there, so its
    # project shows its tools before any traffic. Never to a server or Cloud.
    local = isinstance(run.target.backend, Local)
    payload = run.ctx.report.to_submission_payload(source="check", tool_names=local)
    payload["label"] = _scan_label(run)
    # Each recorded scan proposes its own draft agents and policies, so the same scan
    # sent again would pile up duplicates for someone to review. Per destination: a
    # scan recorded locally has not reached a team server or Cloud.
    # What was found, not how many files were read: `up`'s own files change that count.
    found = {k: v for k, v in payload.items() if k != "files_scanned"}
    fingerprint = hashlib.sha256(json.dumps(found, sort_keys=True).encode()).hexdigest()[:16]
    recorded = dict(run.ctx.saved.get("scans") or {})
    where = run.target.backend.where
    run.answers["scans"] = recorded
    if recorded.get(where) == fingerprint:
        run.done("scan-report", "scan unchanged since it was last recorded here; not sent again")
        return
    try:
        # Its drafts run where `up` set things up: development, unless saved otherwise.
        result = run.target.backend.submit_scan(
            payload, environment=run.ctx.saved.get("environment", "development")
        )
    except BackendError as exc:
        run.failed("scan-report", str(exc))
        return
    recorded[where] = fingerprint
    summary = result.get("summary", {})
    run.done(
        "scan-report",
        f"scan recorded: {plural(len(summary.get('agents_proposed') or []), 'draft agent')}, "
        f"{plural(len(summary.get('policies_proposed') or []), 'proposed policy')} to review",
    )


# ---------------------------------------------------------------------------
# Coding agents (Claude Code, Codex)
# ---------------------------------------------------------------------------


def _coding_note(run: Run) -> str:
    present = [h.display for h in run.ctx.harnesses if h.present]
    return (
        f"found {', '.join(present)}" if present else "none found here; installs the hooks anyway"
    )


def _coding_recommended(run: Run) -> bool:
    """Pre-ticked only where governing the coding agent is clearly the point: its hooks
    are already installed, or the repository is set up for a coding agent (its config
    or instructions file) and holds no agent of its own. A Python agent's repository
    that happens to have a CLAUDE.md is about the Python agent; hooks, tool grants and
    a background daemon for Claude Code there are opt-in (`--with coding-agents`)."""
    harnesses = run.ctx.harnesses
    if any(h.hooked for h in harnesses):
        return True
    return any(h.in_repo for h in harnesses) and not run.ctx.is_agent_project


def _coding_ask(run: Run) -> None:
    harnesses = run.ctx.harnesses
    present = [h.name for h in harnesses if h.present] or [harnesses[0].name]
    if len(harnesses) > 1:
        picked = run.prompter.multiselect(
            "Which coding agents?",
            [Choice(h.name, h.display, "in use here" if h.present else "") for h in harnesses],
            run.ctx.saved.get("harnesses") or present,
        )
    else:
        picked = present
    run.answers["coding-agents"] = picked
    servers = _coding_mcp_servers(run, picked)
    if servers:
        shown = ", ".join(servers[:5]) + ("…" if len(servers) > 5 else "")
        # Asked only once the coding agent is in (pre-ticked because this repository is
        # set up for one, or picked by the person), so yes is the answer that keeps the
        # agent they chose to govern working. Nothing is granted on a run that did not
        # choose coding agents.
        run.answers["coding-mcp"] = run.prompter.confirm(
            f"Let the coding agent use the MCP servers it loads ({shown})? Without a grant "
            "every MCP tool call is refused; with one, each call is still checked",
            default=True,
        )


#: `agentfox scan machine`'s client name for each harness.
_HARNESS_CLIENT = {"claude": "Claude Code", "codex": "Codex"}


def _coding_mcp_servers(run: Run, harnesses: list[str]) -> list[str]:
    """The MCP servers these coding agents load: the repository's, and the ones their
    user-level configs add on this machine."""
    names = {decl.name for decl in _mcp_decls(run)}
    clients = {_HARNESS_CLIENT.get(h) for h in harnesses}
    if run.ctx.machine is not None:
        names |= {s["server"] for s in run.ctx.machine.servers if s["client"] in clients}
    return sorted(names)


def _coding_apply(run: Run) -> None:
    from agentfox import harnesses
    from agentfox.core.db import init_db, session_scope
    from agentfox.harnesses.base import InstallError
    from agentfox.harnesses.baseline import install_baseline
    from agentfox.platform.policy.coding import enable_for_agent

    if run.target.remote:
        # The hooks decide on this machine, so they need this machine's packs too.
        from agentfox.apps.cli.onboarding import setup_workspace

        setup_workspace(run.ctx.root, "development", brief=True)
    init_db()
    for name in run.answers.get("coding-agents", []):
        adapter = harnesses.get(name)
        slug = f"{run.agent}-{name}"
        try:
            with session_scope() as session:
                baseline = install_baseline(
                    session, harness=name, agent_slug=slug, environment="development", grant=True
                )
            changes = adapter.install(run.ctx.root, "project", agent=slug)
            for change in changes:
                if change.action != "unchanged":
                    change.apply()
            with session_scope() as session:
                enable_for_agent(session, slug)
        except (InstallError, OSError) as exc:
            run.failed("coding-agents", f"{adapter.display_name}: {exc}")
            continue
        written = [
            str(c.path.relative_to(run.ctx.root)) for c in changes if c.action != "unchanged"
        ]
        run.done(
            "coding-agents",
            f"{adapter.display_name} hooks → agent [bold]{slug}[/], "
            + (
                f"{plural(len(baseline.tools_granted), 'built-in tool')} granted"
                if baseline.tools_granted
                else "built-in tools already granted"
            )
            + (f" [dim]({', '.join(written)})[/]" if written else " [dim](already installed)[/]"),
        )
        if run.answers.get("coding-mcp"):
            # Into this machine's database whatever the target: the hooks decide here.
            servers = _coding_mcp_servers(run, [name])
            local = Local()
            added = [n for n in servers if local.grant(slug, f"mcp__{n}__*")]
            if servers:
                run.say(
                    f"[green]granted[/] the tools of {plural(len(servers), 'MCP server')} "
                    f"to {slug}: {', '.join(servers)}"
                    + ("" if added else " [dim](already granted)[/]")
                )
    if not run.answers.get("coding-agents"):
        return
    from agentfox.hooks import ping
    from agentfox.hooks.client import remove_stale_socket

    running = ping()
    if running:
        run.say("[dim]hook daemon already running[/]")
    elif remove_stale_socket():
        run.say("[dim]removed the socket a stopped hook daemon left behind[/]")
    if running:
        pass
    elif run.start and _spawn(run, "hooks-daemon", ["admin", "hooks", "daemon"]):
        # Said only once it answers: a hook that runs before then reports the call
        # unchecked, so "started" on a daemon still loading would be untrue.
        import time

        for _ in range(40):
            if ping():
                run.say("[green]hook daemon started[/]")
                break
            time.sleep(0.25)
        else:
            run.say(
                "[yellow]hook daemon is still starting[/] — calls go unchecked until it "
                "answers; `agentfox admin hooks status` says when, "
                "`.agentfox/logs/hooks-daemon.log` says why not"
            )
    else:
        run.next_steps.append(
            (
                "agentfox admin hooks daemon",
                "keep it running: the hooks report unchecked without it",
            )
        )
    if run.target.remote:
        run.say(
            "[dim]Hooks decide on this machine and record here; your coding agent's decisions "
            "do not appear in the remote dashboard.[/]"
        )


# ---------------------------------------------------------------------------
# A Python agent: agentfox.auto()
# ---------------------------------------------------------------------------


def _python_unavailable(run: Run) -> str:
    if run.target.remote:
        return "auto() records on this machine; pick the gateway option for a remote control plane"
    return ""


def _python_agents(run: Run) -> list[str]:
    """The agents the scan found in Python, whatever they are built on (LangGraph,
    CrewAI, the OpenAI Agents SDK …): auto() is the one line for a Python process, so
    each is a reason to offer it, even with no direct model call in the code."""
    return [a.name for a in run.ctx.report.agents if a.file.endswith(".py")]


def _python_recommended(run: Run) -> bool:
    return run.ctx.python_calls > 0 or bool(_python_agents(run))


def _python_note(run: Run) -> str:
    agents = _python_agents(run)
    if agents:
        return f"{plural(len(agents), 'agent')} in Python ({', '.join(agents[:3])})"
    n = run.ctx.python_calls
    if n:
        return f"{plural(n, 'model call')} in Python"
    return "no Python agent or model call found"


def _python_ask(run: Run) -> None:
    files = [str(p.relative_to(run.ctx.root)) for p in run.ctx.entry_points]
    # The file that starts the agent being set up (`--agent`, a saved answer or the
    # scan's pick) is the default, and on the list even when it ranks below the top 5.
    preferred = run.answers.pop("entry-default", None)
    if preferred and preferred not in files and (run.ctx.root / preferred).is_file():
        files.insert(0, preferred)
    first = preferred if preferred in files else (files[0] if files else None)
    choices = [Choice(f, f, "starts your agent" if f == first else "") for f in files]
    choices.append(Choice("none", "Don't edit my code", "show the line to add instead"))
    # The agent being set up decides the file: a saved answer is another run's (in a
    # monorepo, another app's entry file), used only when this run picked none.
    default = (preferred if preferred in files else None) or (
        run.ctx.saved.get("entry_point") or first or "none"
    )
    if default not in {c.key for c in choices}:
        default = choices[0].key
    run.answers["python-app"] = run.prompter.select(
        "Add `agentfox.auto()` to which file? (the one that starts your agent)", choices, default
    )


def _auto_lines(run: Run) -> str:
    # No `mode=` whatever the choice: the policies' modes decide (`auto()`'s default
    # "policy" mode), so "Watch first" watches and `agentfox policy enforce <key>`
    # starts blocking with nothing to edit. `mode="observe"` would never raise
    # whatever the policies say, which made that suggested next step a no-op.
    return f'import agentfox\n\nagentfox.auto("{run.agent}")  # added by `agentfox up`\n'


def unwatched_frameworks(run: Run) -> list[str]:
    """The frameworks of the agent being set up (or, when the scan found none for it,
    of the repository) whose model calls `auto()` cannot see (see
    `autoguard.environment.UNPATCHED_FRAMEWORKS`)."""
    from agentfox.capabilities.discovery.agents import UNPATCHED_FRAMEWORKS
    from agentfox.platform.registry.service import slugify

    mine = {
        a.framework
        for a in run.ctx.report.agents
        if slugify(a.name or a.key) == run.agent or a.key == run.agent
    }
    found = mine or set(run.ctx.report.frameworks)
    return sorted(f for f in found if f in UNPATCHED_FRAMEWORKS)


def _unwatched_warning(run: Run) -> None:
    from agentfox.capabilities.discovery.agents import UNPATCHED_FRAMEWORKS

    for framework in unwatched_frameworks(run):
        run.say(
            f"[yellow]{framework}'s model calls are NOT governed by auto()[/] — it calls "
            f"its model through {UNPATCHED_FRAMEWORKS[framework]}, which auto() does not "
            "patch. Route them through the gateway instead: "
            "[cyan]agentfox up --with gateway[/]"
        )


def _python_apply(run: Run) -> None:
    _register(run)
    _unwatched_warning(run)
    choice = run.answers.get("python-app", "none")
    block = _auto_lines(run)
    if choice == "none":
        run.skipped(
            "python-app", f"agent {run.agent} registered; add these lines to your entry point:"
        )
        for line in block.strip().splitlines():
            if line:
                run.say(f"[cyan]{escape(line)}[/]")
        return
    path = run.ctx.root / choice
    try:
        changed = insert_auto(path, block)
    except OSError as exc:
        run.failed("python-app", f"{choice}: {exc}")
        return
    if changed:
        run.done("python-app", f'{choice} now calls [bold]agentfox.auto("{run.agent}")[/]')
    else:
        run.done("python-app", f"{choice} already calls agentfox.auto()")
        named = _auto_names(path.read_text(errors="ignore"))
        if run.agent not in named:
            # Unnamed, auto() names the agent after the script that runs (`main`,
            # `drive`), not the agent registered here, and its calls land elsewhere.
            run.say(
                f"[yellow]it does not name {run.agent}[/] — make it "
                f'[cyan]agentfox.auto("{run.agent}")[/] so its calls land on the agent '
                "registered here"
            )
    run.answers["python-file"] = choice


_AUTO_CALL = re.compile(r"""agentfox\.auto\(\s*(?:agent\s*=\s*)?(?:["']([^"']+)["'])?""")


def _auto_names(text: str) -> set[str]:
    """The agent names the `agentfox.auto(...)` calls in ``text`` pass ("" for none)."""
    return {m.group(1) or "" for m in _AUTO_CALL.finditer(text)}


# ---------------------------------------------------------------------------
# Any language: the gateway
# ---------------------------------------------------------------------------


def _gateway_note(run: Run) -> str:
    where = "your control plane" if run.target.remote else "a local gateway on :8080"
    return f"OpenAI/Anthropic base URL and /v1/guard/tool_call via {where}"


def _gateway_recommended(run: Run) -> bool:
    return run.ctx.other_calls > 0 or (run.target.remote and run.ctx.python_calls > 0)


def _gateway_apply(run: Run) -> None:
    api = run.target.api_url
    run.env.update(
        {
            "OPENAI_BASE_URL": f"{api}/v1",
            "ANTHROPIC_BASE_URL": api,
            "AGENTFOX_AGENT": run.agent,
        }
    )
    _register(run)
    if not run.target.remote and not _ensure_local_api(run):
        run.say("[yellow]the local gateway is not running yet[/]")
    elif not run.target.remote:
        run.say(f"[green]gateway running[/] at {api}")
    run.done("gateway", f"model clients routed through {api} [dim](.agentfox/agentfox.env)[/]")
    run.say(f"[dim]send the header[/] X-AgentFox-Agent: {run.agent}")
    if run.target.remote:
        run.say(
            "[dim]use your AgentFox API key as the client's API key "
            "(OPENAI_API_KEY / ANTHROPIC_API_KEY = $AGENTFOX_API_KEY); the gateway holds "
            "the provider key[/]"
        )


# ---------------------------------------------------------------------------
# Tool containment: declare what was found
# ---------------------------------------------------------------------------


def _tools_unavailable(run: Run) -> str:
    if run.ctx.tool_names or run.ctx.agent_tools:
        return ""
    return "no tool definitions found in this repository"


def _tools_note(run: Run) -> str:
    own, every = len(_own_tools(run)), len(run.ctx.tool_names)
    if own < every:
        note = f"{plural(own, 'tool')} of {run.agent}'s ({every} in all); impact inferred"
    else:
        note = f"{plural(every, 'tool')} found; impact inferred from the name"
    if run.ctx.agent_tools:
        note += f"; {plural(len(run.ctx.agent_tools), 'agent')} used as a tool"
    return note


def _own_tools(run: Run) -> list[str]:
    """The tools to declare and grant: the agent's own and its sub-agents' when the
    scan tied tools to agents, every tool found otherwise. A folder of separate
    examples does not hand one agent the tools of seventeen others."""
    if run.system_tools is None:
        return run.ctx.tool_names
    # Every tool the system is handed, a library tool with no definition here
    # (`SerperDevTool()`) included: the plan said "2 tools of its own", so 2 are declared.
    return sorted(set(run.system_tools))


def _inferred(run: Run) -> dict[str, str]:
    from agentfox.platform.registry.impact import infer_impact

    details = {s.name: s.detail for s in run.ctx.report.tools if s.name}
    return {
        name: infer_impact(name, {"description": details.get(name, "")}, cautious=True)
        for name in _own_tools(run)
    }


def _tools_ask(run: Run) -> None:
    impacts = _inferred(run)
    # No by default: one question per tool is the longest part of a first run, and an
    # inferred impact is cautious (an unknown verb reads as irreversible) and listed
    # for review by `agentfox declare list` and `agentfox doctor`.
    if run.interactive and run.prompter.confirm(
        f"Review the impact of each of the {len(impacts)} tools now? (otherwise they are "
        "marked inferred, for `agentfox doctor` to flag)",
        default=False,
    ):
        choices = [Choice(i, i) for i in IMPACTS]
        for name in list(impacts):
            impacts[name] = run.prompter.select(f"{name} — what can it do?", choices, impacts[name])
    run.answers["tools"] = impacts


def _tools_apply(run: Run) -> None:
    impacts = run.answers.get("tools") or _inferred(run)
    if not impacts and not run.ctx.agent_tools:
        run.skipped(
            "tools",
            f"{run.agent} has no tools of its own; the "
            f"{plural(len(run.ctx.tool_names), 'tool')} found belong to other agents here",
        )
        return
    added = kept = 0
    for name, impact in impacts.items():
        try:
            if run.target.backend.declare_tool(name, impact=impact, description=""):
                added += 1
            else:
                kept += 1
        except BackendError as exc:
            run.failed("tools", str(exc))
            return
    # An agent another uses as a tool (`agent.as_tool(...)`, AutoGen's `AgentTool`) is
    # one of the system's own parts: `auto()` records a call to it as a delegation,
    # and declared and granted here it is never "tried without permission" on a route
    # that cannot tell (the gateway). It reaches nothing itself; the sub-agent's own
    # tools are declared above and decided on their own.
    members = None if run.system_members is None else set(run.system_members)
    subagents = {
        n: c
        for n, c in run.ctx.agent_tools.items()
        if n not in impacts and (members is None or c in members)
    }
    tools_added = added
    for name, child in subagents.items():
        try:
            if run.target.backend.declare_tool(
                name, impact="read", description=f"runs the {child} agent (an agent used as a tool)"
            ):
                added += 1
            else:
                kept += 1
        except BackendError as exc:
            run.failed("tools", str(exc))
            return
    granted = ""
    if {"python-app", "gateway"} & set(run.picked):
        # Declared and granted: the agent may call its own tools, and what still stops a
        # call is containment (a tainted argument to an irreversible tool), not a
        # missing grant on day one.
        try:
            for name in [*impacts, *subagents]:
                run.target.backend.grant(run.agent, name)
            granted = f", granted to {run.agent}"
        except BackendError as exc:
            run.failed("tools", str(exc))
    risky = sorted(n for n, i in impacts.items() if i in ("high_impact", "irreversible"))
    run.done(
        "tools",
        # Tools and the sub-agents it calls as tools, counted apart: "3 tools" for one
        # tool and two `AgentTool(sub-agent)` read as three things it can do.
        f"declared {plural(tools_added, 'tool')}"
        + (
            f" and {plural(added - tools_added, 'sub-agent')} it calls as tools"
            if added > tools_added
            else ""
        )
        + (f", kept {kept} already declared" if kept else "")
        + granted
        + (f" — {len(risky)} irreversible/high-impact: {', '.join(risky[:5])}" if risky else ""),
    )
    run.later_steps.append(
        ("agentfox declare list", "check each inferred impact; fix with `agentfox declare tool`")
    )


# ---------------------------------------------------------------------------
# MCP servers
# ---------------------------------------------------------------------------


def _mcp_decls(run: Run) -> list[Any]:
    from agentfox.capabilities.discovery.exposure import declared_mcp_servers

    return declared_mcp_servers(run.ctx.root)


def _mcp_unavailable(run: Run) -> str:
    return "" if run.ctx.mcp_names or _mcp_decls(run) else "no MCP client config in this repository"


def _mcp_note(run: Run) -> str:
    names = sorted({d.name for d in _mcp_decls(run)} | set(run.ctx.mcp_names))
    shown = ", ".join(names[:4]) + ("…" if len(names) > 4 else "")
    return f"register {shown}" + (
        " and watch them for tool drift" if run.edition.enterprise else ""
    )


def _mcp_apply(run: Run) -> None:
    decls = _mcp_decls(run)
    count = 0
    for decl in decls:
        try:
            run.target.backend.register_mcp_server(
                decl.name, url=decl.url, transport=decl.transport
            )
            count += 1
        except BackendError as exc:
            run.failed("mcp", str(exc))
    if count:
        run.done("mcp", f"registered {plural(count, 'MCP server')}")
        run.next_steps.append(
            ("agentfox scan mcp", "what each server can reach, and how it is pinned")
        )


# ---------------------------------------------------------------------------
# AgentFox inside your AI client
# ---------------------------------------------------------------------------


def _client_unavailable(run: Run) -> str:
    if run.target.remote:
        return "the MCP server reads this machine's database"
    return ""


def _client_apply(run: Run) -> None:
    path = run.ctx.root / ".mcp.json"
    try:
        data = json.loads(path.read_text()) if path.is_file() else {}
    except ValueError:
        run.failed("ai-client", ".mcp.json is not valid JSON; not touching it")
        return
    servers = data.setdefault("mcpServers", {})
    if "agentfox" in servers:
        run.done("ai-client", "AgentFox already in .mcp.json")
        return
    servers["agentfox"] = {"command": "agentfox", "args": ["serve", "mcp"]}
    path.write_text(json.dumps(data, indent=2) + "\n")
    run.done(
        "ai-client", "added AgentFox to .mcp.json — ask your AI client about findings and approvals"
    )


# ---------------------------------------------------------------------------
# Every pull request: the GitHub Action
# ---------------------------------------------------------------------------

WORKFLOW_PATH = Path(".github") / "workflows" / "agentfox.yml"

#: The workflow `up` writes: the repository's own GitHub Action (action.yml), the same
#: scan as `agentfox scan`, failing a pull request that adds a trifecta or a bad skill.
WORKFLOW = """\
# Written by `agentfox up`. Annotates lethal trifectas, ungoverned model calls and
# poisoned skills on every pull request; `fail-on` decides what fails the check.
name: AgentFox

on:
  pull_request:

permissions:
  contents: read

jobs:
  scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: architsharm/agentfox@main
        with:
          fail-on: trifecta,skills
"""


def _ci_unavailable(run: Run) -> str:
    top = run.ctx.git_root
    if top is not None and top != run.ctx.root.resolve():
        # GitHub reads workflows from the repository's top-level .github/ only; one
        # written into a subfolder is a file that never runs.
        try:
            where = str(run.ctx.root.resolve().relative_to(top)) + "/"
        except ValueError:
            where = "this folder"
        return (
            f"{where} is inside the repository at {top}, and GitHub only runs workflows "
            f"from its top-level .github/ — run `agentfox up --with ci` there"
        )
    if run.ctx.github_repo or (run.ctx.root / ".github").is_dir():
        return ""
    return "not a GitHub repository (no origin on github.com, no .github/)"


def _ci_apply(run: Run) -> None:
    reason = _ci_unavailable(run)
    if reason:  # --with ci in a subfolder: say why, write nothing
        run.skipped("ci", f"GitHub Action not written: {reason}")
        return
    path = run.ctx.root / WORKFLOW_PATH
    if path.exists():
        run.done("ci", f"{WORKFLOW_PATH} already exists, left alone")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(WORKFLOW)
    run.done("ci", f"wrote {WORKFLOW_PATH} — every pull request is scanned; commit it to start")


# ---------------------------------------------------------------------------
# Enterprise: monitoring and compliance
# ---------------------------------------------------------------------------


def _enterprise_reason(run: Run, feature: str) -> str:
    if feature in run.edition.features:
        return ""
    if run.target.key == "local":
        return "AgentFox Enterprise — `pip install agentfox ./ee` from the repository, or use Cloud"
    if run.target.key == "self-hosted":
        return "needs AgentFox Enterprise on the server"
    return "not enabled for this workspace"


def _monitor_unavailable(run: Run) -> str:
    reason = _enterprise_reason(run, "monitoring")
    if reason:
        return reason
    return "" if run.ctx.github_repo else "no GitHub remote (origin) to watch"


def _monitor_apply(run: Run) -> None:
    repo = run.ctx.github_repo or ""
    try:
        created = run.target.backend.add_monitor("github_repo", repo, name=repo)
    except BackendError as exc:
        run.failed("monitoring", f"{repo}: {exc}")
        return
    run.done("monitoring", f"watching {repo}" + ("" if created else " (already watched)"))
    if run.target.key == "local":
        run.next_steps.append(("agentfox admin jobs run-due", "put on cron: it runs the monitors"))


def _compliance_apply(run: Run) -> None:
    if run.target.remote:
        where = (
            f"{run.target.dashboard_url}/app/compliance"
            if run.target.dashboard_url
            else "the Compliance page of your dashboard"
        )
        run.done("compliance", f"included on this control plane — posture and evidence: {where}")
        return
    from agentfox.core import extensions
    from agentfox.core.db import init_db, session_scope

    posture = extensions.service("compliance.posture")
    if posture is None:
        run.failed("compliance", "AgentFox Enterprise is not installed")
        return
    init_db()
    with session_scope() as session:
        result = posture(session)
    counts = result.get("counts") or {}
    pending = counts.get("not_computed", 0)
    scored = ", ".join(
        f"{v} {k.replace('_', ' ')}" for k, v in counts.items() if v and k != "not_computed"
    )
    run.done(
        "compliance",
        f"{plural(result.get('controls', 0), 'control')} loaded"
        + (f": {scored}" if scored else "")
        + (f" [dim]({pending} not scored yet)[/]" if pending else ""),
    )
    if pending:
        run.next_steps.append(
            ("agentfox admin catalog compute", "score every control against what is running")
        )
    run.next_steps.append(
        ("agentfox report", "posture against EU AI Act, ISO 42001, SOC 2, NIST AI RMF")
    )
    run.next_steps.append(
        ("agentfox report evidence", "a signed evidence package an auditor can verify")
    )


# ---------------------------------------------------------------------------
# View
# ---------------------------------------------------------------------------


#: Said wherever a local install would otherwise be pointed at a dashboard it lacks.
NO_LOCAL_DASHBOARD = (
    "a pip install has no web dashboard: the local API serves JSON and its docs. For the "
    "dashboard, sign in to AgentFox Cloud (`agentfox up --target cloud`) or self-host it "
    "(`agentfox up --target self-hosted`)"
)


def _view_label_note(run: Run) -> str:
    if run.target.dashboard_url:
        return run.target.dashboard_url
    return (
        f"starts the API in the background: JSON at {run.target.api_url}/api, docs at "
        "/docs. No web dashboard on this machine; that is Cloud or self-hosted"
    )


def _view_recommended(run: Run) -> bool:
    # Locally there is no dashboard to open, and the API is one more background
    # process; `agentfox findings` reads the same database without it.
    return bool(run.target.dashboard_url) or run.target.remote


def _view_apply(run: Run) -> None:
    url = run.target.dashboard_url
    if not url and run.target.remote:
        run.skipped(
            "view",
            f"control plane at {run.target.api_url}; no dashboard address given "
            "(`agentfox up` again to add one)",
        )
        return
    if not url:
        if not _ensure_local_api(run):
            reason = "--no-start" if not run.start else "the port is taken"
            run.skipped("view", f"local API not started ({reason})")
            return
        url = f"{run.target.api_url}/docs"
        run.done("view", f"API running at {run.target.api_url} — JSON, with its docs at {url}")
        run.say(f"[dim]{NO_LOCAL_DASHBOARD}[/]")
    else:
        url = f"{url}/app"
        run.done("view", f"dashboard: {url}")
    if (
        run.interactive
        and run.target.dashboard_url
        and run.prompter.confirm("Open it in your browser now?", default=True)
    ):
        webbrowser.open(url)


# ---------------------------------------------------------------------------
# Detection models: which classifier, and Llama Guard, downloaded now
# ---------------------------------------------------------------------------

#: The prompt-injection models offered, as (Hugging Face id, label, note). The first
#: is the default and needs no licence; the gated ones are Meta's (Llama licence).
_INJECTION_CHOICES = (
    ("leolee99/PIGuard", "PIGuard (default)", "MIT licence, no account needed"),
    (
        "meta-llama/Llama-Prompt-Guard-2-22M",
        "Prompt Guard 2 22M",
        "Meta, about 3x faster on CPU; gated: accept the Llama licence on Hugging Face",
    ),
    (
        "meta-llama/Llama-Prompt-Guard-2-86M",
        "Prompt Guard 2 86M",
        "Meta, multilingual; gated: accept the Llama licence on Hugging Face",
    ),
)
_LLAMA_GUARD_CHOICES = (
    ("none", "No Llama Guard", "the default checks only"),
    ("meta-llama/Llama-Guard-3-1B", "Llama Guard 3 1B", "safety categories; gated, CPU is fine"),
    ("meta-llama/Llama-Guard-3-8B", "Llama Guard 3 8B", "safety categories; gated, wants a GPU"),
)


def _gated(model_id: str) -> bool:
    return model_id.startswith("meta-llama/")


def _models_unavailable(run: Run) -> str:
    if run.target.remote:
        return ""  # chosen here, downloaded where the gateway runs (see _models_apply)
    import importlib.util

    if importlib.util.find_spec("huggingface_hub") is None:
        return "needs `pip install 'agentfox[classifiers]'`"
    return ""


def _models_note(run: Run) -> str:
    return "PIGuard, Meta Prompt Guard 2 or Llama Guard, self-hosted"


def _models_ask(run: Run) -> None:
    injection = run.prompter.select(
        "Which prompt-injection classifier?",
        [Choice(i, label, note) for i, label, note in _INJECTION_CHOICES],
        run.ctx.saved.get("injection_model") or _INJECTION_CHOICES[0][0],
    )
    guard = run.prompter.select(
        "Add Llama Guard as a safety check?",
        [Choice(i, label, note) for i, label, note in _LLAMA_GUARD_CHOICES],
        run.ctx.saved.get("llama_guard") or "none",
    )
    accepted = True
    if _gated(injection) or guard != "none":
        run.say(
            "Meta's models are gated: accept the Llama licence on each model's Hugging Face "
            "page, and give this machine a token with access (HF_TOKEN or `huggingface-cli "
            "login`). Nothing is sent to Meta; the weights run here."
        )
        accepted = run.prompter.confirm("I have accepted the Llama licence for these", False)
    run.answers["models"] = {"injection": injection, "guard": guard, "accepted": accepted}


def _models_apply(run: Run) -> None:
    from agentfox.core.config import get_settings

    answer = run.answers.get("models") or {"injection": _INJECTION_CHOICES[0][0], "guard": "none"}
    injection, guard = answer["injection"], answer["guard"]
    gated = _gated(injection) or guard != "none"
    if gated and not answer.get("accepted"):
        run.skipped("models", "kept PIGuard: Meta's licence was not accepted")
        injection, guard, gated = _INJECTION_CHOICES[0][0], "none", False
    env = {"AGENTFOX_PROMPT_INJECTION_CLASSIFIER_MODEL": injection}
    detectors = list(get_settings().enabled_detectors)
    if guard != "none":
        env["AGENTFOX_LLAMA_GUARD_MODEL"] = guard
        if "safety.restricted" not in detectors:
            detectors.append("safety.restricted")
        env["AGENTFOX_ENABLED_DETECTORS"] = json.dumps(detectors)
    if gated:
        env["AGENTFOX_ACCEPT_RESTRICTED_MODEL_LICENSES"] = "1"
    run.env.update(env)
    keys = ["injection.classifier"] + (["safety.restricted"] if guard != "none" else [])
    if run.target.remote:
        for key in keys:
            run.next_steps.append(
                (f"agentfox admin detectors pull {key}", "on the host the gateway runs on")
            )
        run.done("models", f"{injection} chosen; set the same variables on your gateway")
        return
    from agentfox.capabilities.detection.adapters.classifiers import (
        PromptInjectionClassifierDetector,
        RestrictedClassifierDetector,
    )

    chosen = [(injection, PromptInjectionClassifierDetector(model_id=injection))]
    if guard != "none":
        chosen.append((guard, RestrictedClassifierDetector(model_id=guard)))
    for model, detector in chosen:
        failure = _pull_model(detector)
        if failure:
            run.failed("models", f"{model}: {failure}")
        else:
            run.done("models", f"[bold]{model}[/] downloaded and selected")


def _pull_model(detector: Any) -> str:
    """Download ``detector``'s models; the reason it failed, or ''."""
    from agentfox.capabilities.detection.models import GatedModel, pull

    try:
        pull(detector)
        return ""
    except GatedModel as exc:
        return str(exc)
    except Exception as exc:  # a download error is reported, never fatal to `up`
        return f"{type(exc).__name__}: {exc}"


# ---------------------------------------------------------------------------
# The catalogue
# ---------------------------------------------------------------------------

CATALOGUE: tuple[Component, ...] = (
    Component(
        "coding-agents",
        "Coding agents — Claude Code / Codex hooks",
        _coding_note,
        _never,
        _coding_recommended,
        _coding_apply,
        _coding_ask,
    ),
    Component(
        "python-app",
        "Your Python agent — one line, agentfox.auto()",
        _python_note,
        _python_unavailable,
        _python_recommended,
        _python_apply,
        _python_ask,
    ),
    Component(
        "gateway",
        "Any language — route model calls through the gateway",
        _gateway_note,
        _never,
        _gateway_recommended,
        _gateway_apply,
    ),
    Component(
        "tools",
        "Tool containment — declare the tools found",
        _tools_note,
        _tools_unavailable,
        lambda r: bool(_own_tools(r) or r.ctx.agent_tools),
        _tools_apply,
        _tools_ask,
    ),
    Component(
        "mcp",
        "MCP servers — register what your clients run",
        _mcp_note,
        _mcp_unavailable,
        lambda r: True,
        _mcp_apply,
    ),
    Component(
        "models",
        "Detection models — choose and download (PIGuard, Prompt Guard 2, Llama Guard)",
        _models_note,
        _models_unavailable,
        lambda r: False,
        _models_apply,
        _models_ask,
    ),
    Component(
        "scan-report",
        "Record this scan — draft agents and proposed policies to review",
        _scan_note,
        _never,
        lambda r: True,
        _apply_scan,
    ),
    Component(
        "ci",
        "Every pull request — the AgentFox GitHub Action",
        lambda r: "fails a PR that adds a lethal trifecta or a poisoned skill",
        _ci_unavailable,
        lambda r: False,
        _ci_apply,
    ),
    Component(
        "monitoring",
        "Keep watching — re-check this repo on every push",
        lambda r: r.ctx.github_repo or "",
        _monitor_unavailable,
        # Opt-in: a first run sets up the agent, not a governance programme.
        lambda r: False,
        _monitor_apply,
        enterprise=True,
    ),
    Component(
        "compliance",
        "Compliance and evidence — EU AI Act, ISO 42001, SOC 2, NIST",
        lambda r: "posture, risk register, signed evidence packages",
        lambda r: _enterprise_reason(r, "compliance"),
        lambda r: False,
        _compliance_apply,
        enterprise=True,
    ),
    Component(
        "ai-client",
        "Ask AgentFox from your AI client — MCP server in .mcp.json",
        lambda r: "findings, approvals and policy, from Claude Code or Cursor",
        _client_unavailable,
        lambda r: False,
        _client_apply,
    ),
    Component(
        "view",
        "Open the dashboard, or start the local API",
        _view_label_note,
        _never,
        _view_recommended,
        _view_apply,
    ),
)

BY_KEY = {c.key: c for c in CATALOGUE}


def _apply_declared_modes(run: Run) -> None:
    """ "Shipped defaults": each pack in the mode it declares. A new workspace starts
    every pack watching (`setup_workspace`); this is the choice that makes tool
    containment block, the one pack that declares enforce. Only ever upgrades: a pack
    someone switched to blocking stays blocking (see `apply_mode`)."""
    from agentfox.platform.policy import load_available

    try:
        modes = run.target.backend.policy_modes()
        declared = {doc.key: doc.mode for doc in load_available()}
    except BackendError as exc:
        run.failed("mode", str(exc))
        return
    changed = []
    for key, mode in sorted(modes.items()):
        want = declared.get(key, mode)
        if want == mode or want != "enforce":
            continue
        try:
            run.target.backend.set_policy_mode(key, want)
            changed.append(key)
            modes[key] = want
        except BackendError as exc:
            run.failed("mode", f"{key} ({exc})")
    blocking = sorted(k for k, m in modes.items() if m == "enforce")
    run.done(
        "mode",
        "policies in their shipped modes"
        + (f" — {', '.join(blocking)} blocks" if blocking else " — none blocks yet")
        + (f" [dim](changed {', '.join(changed)})[/]" if changed else ""),
    )


def apply_mode(run: Run) -> None:
    """Put the policies in the chosen safety mode.

    Never downgrades. A pack that blocks was switched to blocking by a person
    (`agentfox policy enforce`, Start blocking, or an earlier "enforce" here), and
    running `up` again, which only adds what is new, must not quietly put it back to
    watching. New packs are bound watching (`setup_workspace`); "Watch first" leaves
    every mode as it is, the other two choices only turn blocking on. Demoting is
    `agentfox policy observe <key>`."""
    if run.mode == "defaults":
        _apply_declared_modes(run)
        return
    want = "observe" if run.mode == "observe" else "enforce"
    try:
        modes = run.target.backend.policy_modes()
    except BackendError as exc:
        run.failed("mode", str(exc))
        return
    changed, refused = [], []
    for key, mode in sorted(modes.items()):
        if mode == want or want == "observe":
            continue
        try:
            run.target.backend.set_policy_mode(key, want)
            changed.append(key)
        except BackendError as exc:
            refused.append(f"{key} ({exc})")
    blocking = sorted(k for k, m in modes.items() if m == "enforce" or k in changed)
    if want == "observe":
        watching = len(modes) - len(blocking)
        text = f"{plural(watching, 'policy')} watching — recorded, not blocked yet"
        if blocking:
            text += f"; kept blocking: {', '.join(blocking)}"
    else:
        text = f"{plural(len(modes), 'policy')} in enforce — every policy blocks"
    run.done("mode", text + (f" [dim](changed {', '.join(changed)})[/]" if changed else ""))
    for item in refused:
        run.failed("mode", item)
    if want == "observe" and "tool-containment" not in blocking:
        run.later_steps.append(
            (
                "agentfox policy enforce tool-containment",
                "when the decisions look right: start blocking",
            )
        )
