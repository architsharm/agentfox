"""The three commands a new user runs, and nothing else.

The rest of the CLI is thirteen verbs (`agentfox --help`) over about a hundred
subcommands, which is right for an operator running a governance programme and
wrong for the first ten minutes. Someone
evaluating this should be able to type three words and understand their exposure:

    agentfox init      # set everything up
    agentfox scan      # scan the repo and highlight what is ungoverned
    agentfox doctor    # is the runtime configured the way I think it is?

Every one of them is safe to run: `init` is idempotent, `check` reads source without
importing it, and `doctor` only reports. None of them can break a running system, so
nobody has to read the docs before trying one.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import typer
from rich.console import Console
from rich.markup import escape
from rich.panel import Panel
from rich.table import Table

from agentfox.apps.cli._style import SEVERITY_COLOUR, display_path, short_id

console = Console()


def plural(n: int, word: str) -> str:
    return f"{n} {word}{'' if n == 1 else 's'}"


_CONFIG_TEMPLATE = """# AgentFox configuration.
# Everything here has a safe default; this file exists so the defaults are visible
# rather than implicit. The [agentfox] table is read from the working directory;
# environment variables (AGENTFOX_*) override it.

[agentfox]
environment = "{environment}"

# Default mode for a policy that does not declare its own. `agentfox init` starts every
# shipped pack in observe; `agentfox policy enforce <key>` starts one blocking.
default_policy_mode = "{default_policy_mode}"

# Zero egress: no model call leaves this machine unless you turn it on.
allow_egress = {allow_egress}

# The whole pre-flight pipeline's latency ceiling, in milliseconds.
enforcement_budget_ms = {enforcement_budget_ms}

# Where a tool call's provenance is read from, for the taint rules.
#   "session"  - the worst untrusted content anywhere in the run so far, or in the
#                call's own arguments. Contains more; escalates more benign calls.
#   "argument" - only what the call's own arguments were copied from.
# Every published number was measured under "session". docs/getting-started.md, step 5b.
taint_scope = "{taint_scope}"
"""

# What each policy mode means to someone who has not read the PRD.
_MODE_MEANING = {
    "observe": "recorded, nothing blocked",
    "enforce": "violations are blocked now",
}


def _config_text(environment: str) -> str:
    """Render the template from the real Settings defaults, so the file never drifts
    from what the runtime does when the file is absent."""
    from agentfox.core.config import Settings

    fields = Settings.model_fields
    return _CONFIG_TEMPLATE.format(
        environment=environment,
        default_policy_mode=fields["default_policy_mode"].default,
        allow_egress=str(fields["allow_egress"].default).lower(),
        enforcement_budget_ms=fields["enforcement_budget_ms"].default,
        taint_scope=fields["taint_scope"].default,
    )


def _session():
    """A session on an initialised database. `init_db` is idempotent, and without it
    a command run before `agentfox init` dies on "no such table"."""
    from agentfox.core.db import init_db, session_scope

    init_db()
    return session_scope()


#: What `agentfox scan` writes in the severity column. Short enough for a table and
#: still a word, so the row survives a terminal with no colour and a pasted log.
_SEVERITY_MARK = {
    "critical": "CRITICAL",
    "high": "high",
    "medium": "medium",
    "low": "low",
    "info": "info",
}


def _fit_path(file: str, line: int, width: int) -> str:
    """``src/agentfox/apps/gateway/routes/inline.py:42`` shortened from the *left*.

    The previous rendering cut from the right, which removed the filename and the
    line number — the two parts of the path that are the point of printing it. When a
    path will not fit, leading directories are dropped and the cut is marked.
    """
    label = f"{file}:{line}"
    if len(label) <= width:
        return label
    parts = label.split("/")
    for index in range(1, len(parts)):
        candidate = "…/" + "/".join(parts[index:])
        if len(candidate) <= width:
            return candidate
    # A single filename longer than the column: keep its end, which carries the
    # extension and the line number.
    return "…" + label[-(width - 1) :]


def _print_next_steps(steps: list[tuple[str, str]]) -> None:
    """A command that ends without a next action makes the reader do the synthesis."""
    table = Table(show_header=False, box=None, padding=(0, 2))
    for command, why in steps:
        table.add_row(f"[bold cyan]{command}[/]", f"[dim]{why}[/]")
    console.print()
    console.print(Panel(table, title="[bold]Next[/]", title_align="left", border_style="dim"))


def database_error_hint(exc: BaseException, url: str = "") -> str:
    """One readable sentence for a database that will not open, instead of a traceback.

    The case that motivated it: a Postgres database created with ``SQL_ASCII``
    encoding returns its server version as bytes, and the driver fails with "cannot
    use a string pattern on a bytes-like object", which says nothing about encoding.
    """
    text = f"{type(exc).__name__}: {exc}"
    lowered = text.lower()
    if "sql_ascii" in lowered or "bytes-like object" in lowered or "bytes pattern" in lowered:
        return (
            "the Postgres database is not UTF8-encoded (SQL_ASCII). AgentFox needs a UTF8 "
            "database: create it with `CREATE DATABASE agentfox ENCODING 'UTF8' "
            "TEMPLATE template0;` and point AGENTFOX_DATABASE_URL at it."
        )
    if "could not connect" in lowered or "connection refused" in lowered:
        return f"could not connect to the database at {url or 'AGENTFOX_DATABASE_URL'} ({exc})"
    if "no module named" in lowered and "psycopg" in lowered:
        return "the Postgres driver is not installed: `pip install 'agentfox[postgres]'`."
    return text


def init(
    path: Path = typer.Option(
        Path("."), "--path", "-p", help="Where to write agentfox.toml. Default: here."
    ),
    environment: str = typer.Option(
        "development",
        "--env",
        "-e",
        help="Name this deployment: development, staging or production. It decides "
        "how strictly `agentfox doctor` grades authentication.",
    ),
    demo: bool = typer.Option(
        False,
        "--demo",
        help="Also load the demo fixtures: three agents and an eval suite. No traffic is "
        "recorded; run `agentfox demo` afterwards for sample traces and findings.",
    ),
    key: str = typer.Option(
        "",
        "--key",
        help="Your workspace key (dashboard: Get started → Create a key); with --server and "
        "no --key, AGENTFOX_API_KEY is used, which keeps the key out of `ps` and your "
        "shell history. Maps the agent in "
        "this repo (reading the code, never running it), reports its names and shapes, and "
        "stays connected to run the attack tests on this machine: those do run your agent, "
        "with every tool faked.",
    ),
    server: str = typer.Option(
        "",
        "--server",
        envvar="AGENTFOX_SERVER",
        help="The AgentFox API to report to. Default: http://127.0.0.1:8080.",
    ),
) -> None:
    """Connect this repo to your account (--key), or set up locally.

    Without --key: prepares the local database and policies.

    Idempotent and safe to run twice. Without --key it is offline and edits no code;
    `agentfox up` is the guided setup that also adds `agentfox.auto()`.

    Creates the database, applies migrations, loads the control catalog and the
    shipped policy packs, every one watching (observe) until you switch it to blocking
    with `agentfox policy enforce <key>`; coding-agent only for agents this repo's
    coding-harness hooks govern. Destructive commands and tampering with AgentFox
    are refused from the start; a tool an agent was not granted is refused once
    tool-containment blocks. It writes an
    agentfox.toml carrying the real runtime defaults so they are visible rather than
    implicit. AGENTFOX_* environment variables override that file.
    """
    if not key and server:
        # The key from the environment, so it is in neither `ps` nor the shell's
        # history: `export AGENTFOX_API_KEY=...` then `agentfox init --server ...`.
        # Only with a server named: a plain `init` sets up this machine, even in a
        # shell where the app's own key is exported.
        import os

        key = os.environ.get("AGENTFOX_API_KEY", "").strip()
    if key:
        from agentfox.capabilities.onboarding.client import connect

        connect(key, server or "http://127.0.0.1:8080", path)
        return
    setup_workspace(path, environment, demo=demo)
    _print_next_steps(
        [
            (
                "agentfox demo",
                "look around first: a thirteen-step walkthrough, in a database of its own",
            ),
            ("agentfox scan", "scan this repo and see what is ungoverned"),
            (
                "agentfox up",
                'registers your agents and adds agentfox.auto("<agent>") to the file that '
                "starts one, under the name the scan prints",
            ),
            ("agentfox doctor", "check containment readiness, not just detectors"),
        ]
    )


def setup_workspace(
    path: Path, environment: str, *, demo: bool = False, brief: bool = False
) -> None:
    """What `init` does, without its closing advice: `agentfox up` runs this as its
    first step and gives its own. ``brief`` prints one line instead of the pack list,
    for a caller that sets the modes and hooks itself and reports them after."""
    from rich.markup import escape
    from sqlalchemy import select

    from agentfox.capabilities.compliance import load_catalog, sync_catalog
    from agentfox.core.config import get_settings
    from agentfox.core.db import init_db, session_scope
    from agentfox.core.models import Policy
    from agentfox.harnesses import hooked_agents
    from agentfox.platform.policy import current_binding, load_available, save_policy
    from agentfox.platform.policy.coding import retire_tool_wildcard, scope_coding_pack

    if not Path(path).is_dir():
        # Checked first, so a typo does not leave a half-initialised database behind
        # and then fail on the write with a FileNotFoundError traceback.
        console.print(
            f"[red]--path {escape(str(path))} is not a directory[/] — create it first, "
            "or point --path at an existing one."
        )
        raise typer.Exit(2)

    settings = get_settings()
    say = (lambda *_args, **_kwargs: None) if brief else console.print
    say("[bold]Setting up AgentFox[/]")

    try:
        init_db()
    except Exception as exc:
        console.print(
            "[red]database could not be set up:[/] "
            + escape(database_error_hint(exc, settings.database_url))
        )
        raise typer.Exit(1) from None
    say(f"  [green]✓[/] database ready  [dim]{settings.database_url}[/]")

    with session_scope() as session:
        summary = sync_catalog(session)
        catalog = load_catalog()
        say(
            f"  [green]✓[/] {summary['controls_created'] + summary['controls_updated']} controls "
            f"across {len(catalog.get('frameworks', []))} frameworks  "
            f"[dim]v{catalog.get('version')} ({catalog.get('review_status')})[/]"
        )

        # The project's own packs too, not just the shipped ones: a team
        # that keeps policy in `.agentfox/policies/` expects `init` to
        # install it, and a pack the loader can see but `init` ignores is
        # a policy that silently does nothing.
        # The coding-agent pack only for agents a coding harness runs: see
        # policy/coding.py for why a wildcard binding was the wrong default.
        documents, coding_agents = scope_coding_pack(load_available(), hooked_agents(path))
        if coding_agents == []:
            retire_tool_wildcard(session)
        # A new workspace starts every pack watching, tool-containment included: a
        # rule that holds a normal $50 transfer for a person on the first day blocks a
        # real customer. Blocking is a step the user takes (`agentfox policy enforce
        # tool-containment`, or Start blocking in the dashboard). A pack already
        # installed keeps the mode it is in, so running `init` again never changes it.
        # A destructive statement (`rm -rf ~/`) and tampering with AgentFox are
        # refused whatever mode the packs are in; a missing grant follows
        # tool-containment's mode (`platform.policy.containment_mode`).
        modes: dict[str, str] = {}
        kept: set[str] = set()
        for document in documents:
            existing = session.scalar(select(Policy).where(Policy.key == document.key))
            if existing is not None and current_binding(session, existing.id)[0] is not None:
                kept.add(document.key)
            policy, _version = save_policy(
                session,
                document,
                author="init",
                notes="loaded by agentfox init",
                bind_mode="observe",
                keep_mode=True,
            )
            live, _ = current_binding(session, policy.id)
            modes[document.key] = live.mode if live is not None else "observe"
        say(f"  [green]✓[/] {plural(len(documents), 'policy pack')} loaded")
        for document in sorted(documents, key=lambda d: d.key):
            mode = modes[document.key]
            colour = "red" if mode == "enforce" else "yellow"
            meaning = _MODE_MEANING.get(mode, "")
            # Kept: a pack someone switched to blocking stays blocking on a rerun.
            note = "  [dim](kept)[/]" if document.key in kept and mode != "observe" else ""
            say(f"      {document.key:<24} [{colour}]{mode}[/]  [dim]{meaning}[/]{note}")
        if coding_agents:
            say(f"      [dim]coding-agent applies to: {', '.join(coding_agents)}[/]")
        elif coding_agents == []:
            say(
                "      [dim]coding-agent not enabled — no coding-agent hooks in this repo. "
                "`agentfox admin hooks install --agent <slug> --write` turns it on for that "
                "agent.[/]"
            )
        enforcing = [d.key for d in documents if modes[d.key] == "enforce"]
        if enforcing:
            say(
                f"      [dim]{', '.join(enforcing)} blocks — "
                "demote with `agentfox policy observe <key>`.[/]"
            )
        elif "tool-containment" in modes:
            say(
                "      [dim]Destructive commands and tampering are still refused. When the "
                "would-block decisions look right: "
                "`agentfox policy enforce tool-containment`.[/]"
            )

    config_path = Path(path) / "agentfox.toml"
    if config_path.exists():
        say(f"  [dim]·[/] {config_path.name} already exists, left alone")
    else:
        config_path.write_text(_config_text(environment))
        say(f"  [green]✓[/] wrote {config_path.name}")

    if demo:
        from agentfox.fixtures.seed import seed

        with session_scope() as session:
            seed(session)
        say("  [green]✓[/] demo fixtures loaded")
        say(
            "    [dim]agents, policies and an eval suite; no traffic yet. "
            "`agentfox demo` sends sample requests through them.[/]"
        )
    if brief:
        console.print(
            f"  [green]✓[/] workspace ready  [dim]{len(documents)} policy packs, "
            f"{len(catalog.get('frameworks', []))} control frameworks[/]"
        )


def check(
    path: Path = typer.Argument(Path("."), help="Directory to scan. Default: here."),
    as_json: bool = typer.Option(
        False, "--json", help="Full records for scripts: every site, whole paths, no table."
    ),
    limit: int = typer.Option(15, "--limit", "-n", help="How many sites to show, worst first."),
    fail_on_ungoverned: bool = typer.Option(
        False,
        "--fail",
        help="Exit non-zero if any model call is ungoverned (for CI). Only that: a "
        "critical finding such as a lethal trifecta is reported, not failed on.",
    ),
    submit: bool | None = typer.Option(
        None,
        "--submit/--no-submit",
        help="Send a redacted summary (counts and structure only, never file "
        "contents) to a running control plane for a fuller dashboard report. "
        "Optional — omit both flags to be asked interactively.",
    ),
    include_tests: bool = typer.Option(
        False,
        "--include-tests",
        help="Also report what tests, docs and benchmarks define. Left out by default: "
        "they build stand-in agents and tools nobody deploys (secrets are reported "
        "everywhere either way).",
    ),
) -> None:
    """Scan a repository and highlight everything worth governing.

    Static only: reads the source, never imports or runs it. Importing the target
    would execute arbitrary code from a repo the operator may not trust, and would
    fail on anything with an import-time side effect — which is most real
    applications. Stays entirely local unless `--submit` (or an interactive "yes")
    opts into sending a redacted summary — see `cli/submit.py`.
    """
    from agentfox.apps.cli._scan_view import print_surface, print_trifectas
    from agentfox.apps.cli.submit import maybe_submit_report
    from agentfox.capabilities.discovery.repo import scan

    report = scan(path, include_tests=include_tests)
    if as_json:
        console.print_json(json.dumps(report.to_json(), default=str))
        if submit:
            maybe_submit_report(report, source="check", explicit=True, console=Console(stderr=True))
        raise typer.Exit(1 if fail_on_ungoverned and report.ungoverned else 0)

    # The trifecta comes first: it is the one finding that reads as a breach scenario
    # rather than an inventory line, and the reader who stops after one screen should
    # stop after reading it.
    print_trifectas(console, report)
    console.print(
        f"[bold]Scanned[/] {plural(report.files_scanned, 'file')} in "
        f"[dim]{display_path(report.root)}[/]",
        soft_wrap=True,
    )
    if report.excluded_files:
        console.print(
            f"  [dim]left out {plural(report.excluded_files, 'test, docs or benchmark file')}"
            " (read for secrets only); --include-tests reports them[/]"
        )
    if report.frameworks:
        console.print(f"  [dim]built on:[/] {', '.join(report.frameworks)}")
    # The agents one line each, single-agent repos included: "we found your agent" is
    # the first thing a newcomer wants confirmed. By key, the one name the edges below,
    # `up` and auto() use. A multi-agent system is proposed as one agent per agent, so
    # who hands work to whom follows.
    from rich.markup import escape

    if report.agents:
        console.print(f"\n  [bold]Found {plural(len(report.agents), 'agent')}[/]")
        groups = _agent_groups(report.agents)
        if len(report.agents) > 8 and len(groups) > 3:
            # A repository of many examples: one line per directory reads; the first
            # eight agents of the first example do not.
            for directory, specs in groups[:12]:
                tools = len({t for a in specs for t in a.tools})
                console.print(
                    f"    [bold]{escape(directory)}/[/]  {plural(len(specs), 'agent')}"
                    + (f" · {plural(tools, 'tool')}" if tools else "")
                    + f"  [dim]{escape(', '.join(a.key for a in specs[:3]))}"
                    + (", …" if len(specs) > 3 else "")
                    + "[/]"
                )
            if len(groups) > 12:
                console.print(
                    f"    [dim]... and {len(groups) - 12} more directories; "
                    "`--json` lists every agent[/]"
                )
        else:
            for spec in report.agents[:8]:
                model = spec.model or ("default model" if spec.default_model else "")
                detail = " · ".join(
                    part
                    for part in (
                        spec.framework,
                        model,
                        plural(len(spec.tools), "tool") if spec.tools else "",
                    )
                    if part
                )
                console.print(
                    f"    [bold]{escape(spec.key)}[/]  {escape(detail)}  "
                    f"[dim]{escape(spec.file)}:{spec.line}[/]"
                )
            if len(report.agents) > 8:
                more = len(report.agents) - 8
                console.print(f"    [dim]... and {more} more; `--json` lists them all[/]")
            for line in report.agent_summary()[1:]:
                console.print(f"    [dim]{escape(line)}[/]")

    calls = len(report.model_calls)
    ungoverned = len(report.ungoverned)
    if calls:
        tone = "red" if ungoverned else "green"
        console.print(
            f"\n  [{tone}]{ungoverned}[/] of [bold]{calls}[/] model call sites are "
            f"ungoverned  [dim]({report.coverage:.0%} covered)[/]"
        )
    print_surface(
        console,
        report,
        limit=max(limit, 12),
        more_hint=f"agentfox scan --limit {len(report.tools) + len(report.mcp_servers)}",
    )
    counts = report.by_kind()
    # Tools, servers and trifectas were each shown above in their own words.
    shown = ("model_call", "tool", "mcp_server", "lethal_trifecta")
    other = {k: v for k, v in counts.items() if k not in shown}
    if other:
        console.print(
            "  [dim]also found:[/] "
            # Pluralise. "16 shell call" reads as a truncation bug on the first
            # command a new user runs, which is the worst place to have one.
            + ", ".join(
                f"{v} {k.replace('_', ' ')}{'' if v == 1 else 's'}" for k, v in other.items()
            )
        )

    # Trifectas and tools were each shown above, in their own words; the table is
    # for everything else, worst first.
    listed = [site for site in report.ranked() if site.kind not in ("lethal_trifecta", "tool")]
    ranked = listed[:limit] if limit else listed
    if ranked:
        # A budget for the path column, so the paths can be shortened deliberately
        # (from the left, filename last) instead of being cut by the renderer at
        # whatever column happened to be left over.
        # Only as wide as the longest path needs: a fixed half of an 80-column terminal
        # left `app.py:3` padded to 40 columns and folded the call site mid-token.
        budget = max(28, min(52, console.width // 2))
        needed = max(len(f"{site.file}:{site.line}") for site in ranked)
        where_width = max(8, min(needed, budget))
        table = Table(box=None, padding=(0, 1), header_style="dim")
        table.add_column("severity", no_wrap=True)
        table.add_column("where", no_wrap=True, width=where_width)
        # Fold rather than the default ellipsis: a call site cut to
        # "run_completion(.…" is the one field that says which site this is.
        table.add_column("what", ratio=1, overflow="fold")
        for site in ranked:
            colour = SEVERITY_COLOUR.get(site.severity, "dim")
            # The severity is spelled out, not signalled by the colour of a dot. A
            # hard-coded credential and an ordinary call site rendered as the same
            # glyph in any terminal without colour, and in every copied transcript.
            mark = (
                "[green]governed[/]"
                if site.governed
                else f"[{colour}]{_SEVERITY_MARK.get(site.severity, site.severity)}[/]"
            )
            # No slice: the detail is what tells you which call site this is, and a
            # row ending mid-word reads as a rendering fault, not as a finding.
            where = _fit_path(site.file, site.line, where_width)
            table.add_row(mark, f"[dim]{where}[/]", site.detail)
        console.print()
        console.print(table)
        if len(listed) > len(ranked):
            # A hint has to be a command someone can run. "(--limit)" is a flag name.
            target = "" if str(path) == "." else f" {path}"
            # Say WHAT is not shown, not just how many.
            #
            # Found running this against browser-use, a real repository: the
            # headline read "32 of 32 model call sites" and this line read "33
            # more not shown", which cannot both be true of the same population
            # and left the reader to work out that the table also holds the 16
            # shell calls. It counts findings; the headline counts model calls.
            # Naming the unit reconciles them without changing either number.
            hidden = len(listed) - len(ranked)
            console.print(
                f"  [dim]{plural(hidden, 'more finding')} not shown, across every kind above. "
                f"See all of them:[/] [cyan]agentfox scan{target} "
                f"--limit {len(listed)}[/]"
            )

    if report.errors:
        console.print(f"\n  [yellow]{plural(len(report.errors), 'file')} could not be parsed[/]")
        for error in report.errors[:3]:
            console.print(f"    [dim]{error}[/]")

    console.print()
    console.print(
        Panel(
            _next_action(report, path),
            border_style="cyan",
            title="[bold]Next[/]",
            title_align="left",
        )
    )

    maybe_submit_report(report, source="check", explicit=submit, console=console)

    if fail_on_ungoverned and report.ungoverned:
        raise typer.Exit(1)
    if fail_on_ungoverned and report.trifectas:
        # Exit 0 below a CRITICAL reads as a pass in CI: say what --fail checked.
        console.print(
            f"  [yellow]--fail passed:[/] it checks for ungoverned model calls only (none "
            f"here). The {plural(len(report.trifectas), 'critical lethal trifecta')} above "
            "is not part of it."
        )


def _agent_groups(agents: list[Any]) -> list[tuple[str, list[Any]]]:
    """Agents by the directory that holds them, two levels deep (`examples/basic`), in
    the order the scan found them."""
    groups: dict[str, list[Any]] = {}
    for spec in agents:
        parts = Path(spec.file).parts[:-1]
        groups.setdefault("/".join(parts[:2]) or ".", []).append(spec)
    return list(groups.items())


def _next_action(report: Any, root: Path | None = None) -> str:
    """The scan's Next panel: one command that acts on what was found, then the why.

    A scan that ends in advice ("add auto() to your entry point") leaves the reader
    to work out the steps; `agentfox up` already does them, in watch mode. Once `up`
    has run here (its answers are in `.agentfox/up.json`), offering it again would
    be the wrong step: the next one is running the app and reading what it recorded.
    """
    if report.inconclusive or not (report.agents or report.tools or report.governable):
        return report.next_step()
    from agentfox.apps.cli.wizard.detect import load_answers

    saved = load_answers(root) if root is not None else {}
    if saved.get("agent"):
        agent = saved["agent"]
        entry = saved.get("entry_point")
        run = (
            f"run your app ({entry} calls agentfox.auto)"
            if entry and entry != "none"
            else "run your app"
        )
        lines = [
            f"Set up with `agentfox up` as [bold]{agent}[/] ({saved.get('mode', 'observe')}).",
            f"Next: {run}, then [bold cyan]agentfox findings[/] for what it recorded and "
            f"[bold cyan]agentfox test redteam {agent}[/] to attack-test it.",
        ]
        others = {s.file for s in report.ungoverned if s.file.endswith(".py")} - {entry}
        if others:
            lines.append(
                f"[dim]{plural(len(others), 'other file')} with ungoverned calls "
                "(other agents, or code auto() in your entry point does not load). "
                "`agentfox up` again to change what is set up.[/]"
            )
        return "\n".join(lines)
    why = report.next_step(suggest_auto=False)
    count = len(report.agents)
    what = "this agent" if count == 1 else f"these {count} agents" if count else "this repository"
    # Said only when `up` will offer it: Python call sites auto() patches.
    auto = (
        " adds `agentfox.auto()` to your entry point,"
        if any(site.file.endswith(".py") for site in report.ungoverned)
        else ""
    )
    return (
        f"Start watching {what}: [bold cyan]agentfox up[/]\n"
        f"[dim]It registers your agents, declares their tools,{auto} and starts in watch "
        "mode: nothing is blocked until you say so.[/]\n\n" + why
    )


def doctor(
    as_json: bool = typer.Option(
        False,
        "--json",
        help="One record per check, for CI. Exits non-zero on a failed check either way.",
    ),
) -> None:
    """Is the runtime configured the way you think it is?

    Reports only — it changes nothing. Every line is a fact about this deployment, and
    each one names the consequence rather than the setting, because "fail_mode=open"
    means nothing to someone who has not read the PRD.
    """
    from agentfox.capabilities.detection import available_detectors
    from agentfox.core.config import get_settings, is_development
    from agentfox.core.db import session_scope
    from agentfox.core.models import (
        AccessScopeRule,
        Agent,
        Capability,
        Decision,
        Finding,
        KnowledgeBoundary,
        Tool,
        Trace,
    )
    from agentfox.platform.providers import available_providers

    settings = get_settings()
    checks: list[tuple[str, str, str]] = []
    # What a fresh local install looks like is said as information, not as a warning:
    # a first run that opens on seven yellow marks reads as broken. The same states in
    # staging or production stay warnings, since there they are decisions not taken.
    dev = is_development(settings)
    default_state = "info" if dev else "warn"

    def add(state: str, what: str, detail: str) -> None:
        checks.append((state, what, detail))

    # The account first: with a key configured, `auto()` and the CLI use it, so a
    # wrong key or an unreachable server is the failure that matters most.
    account_findings = _check_account(add)

    try:
        from agentfox.core.db import init_db

        init_db()
        with session_scope() as session:
            agents = session.query(Agent).count()
            traces = session.query(Trace).count()
            decisions = session.query(Decision).count()
            findings = session.query(Finding).filter_by(status="open").count()
            boundaries = session.query(KnowledgeBoundary).count()
            tools_declared = session.query(Tool).count()
            tools_acting = (
                session.query(Tool)
                .filter(Tool.impact.in_(["write", "high_impact", "irreversible"]))
                .count()
            )
            grants = session.query(Capability).count()
            # `agentfox up` declares the tools it found with an impact guessed from the
            # name, marked inferred, and says doctor will flag them until confirmed.
            from agentfox.platform.registry.service import impact_source_of

            inferred = sorted(
                tool.key
                for tool in session.query(Tool).all()
                if impact_source_of(tool) == "inferred"
            )
            scoped_tables = session.query(AccessScopeRule).count()
            enforcing = (
                session.query(Decision).filter_by(mode="enforce").count() if decisions else 0
            )
        add("ok", "database", f"reachable — {plural(agents, 'agent')}, {plural(traces, 'trace')}")
    except Exception as exc:
        add("bad", "database", f"unreachable: {database_error_hint(exc, settings.database_url)}")
        agents = traces = decisions = findings = boundaries = enforcing = 0
        tools_declared = tools_acting = grants = scoped_tables = 0
        inferred = []

    if decisions == 0:
        add(
            "info",
            "traffic",
            "no decisions recorded — nothing has been governed yet. "
            "Add `agentfox.auto()` to your entry point.",
        )
    elif enforcing == 0:
        add(
            "warn",
            "enforcement",
            f"{plural(decisions, 'decision')}, all in observe mode — recorded, nothing blocked. "
            "That is the safe default, not a finished configuration.",
        )
    else:
        add("ok", "enforcement", f"{enforcing} of {decisions} decisions enforced")

    # Authentication first: it is the check most likely to be wrong and most costly
    # when it is, and a deployment that fails it does not need to read the rest.
    from agentfox.platform.identity.operators import header_identity_allowed

    if header_identity_allowed():
        local = settings.environment.lower() in ("development", "dev", "test", "local")
        if local:
            # Plain words for someone who has never started a server: the mechanism
            # (the identity header, the seeded admin) only matters once one is exposed.
            add(
                "info",
                "authentication",
                "development: a server started here (`agentfox serve`) answers API calls "
                "without a token, so anyone who can reach this port can act as its owner. "
                "Fine on this machine; set AGENTFOX_AUTH_MODE=token before anyone else "
                "can reach it.",
            )
        else:
            add(
                "bad",
                "authentication",
                f"development auth is on in {settings.environment} "
                f"(auth_mode={settings.auth_mode}): anyone who can reach this port can act "
                "as any user, named in X-AgentFox-User, with no token. Set "
                "AGENTFOX_AUTH_MODE=token.",
            )
    else:
        add("ok", "authentication", "API tokens required; the identity header is refused")

    from agentfox.core.config import insecure_production_secrets

    secret_problems = insecure_production_secrets(settings)
    if secret_problems:
        add(
            "bad",
            "secrets",
            "the gateway will refuse to start: " + " ".join(secret_problems),
        )
    elif is_development(settings):
        add(
            "ok",
            "secrets",
            "development: the published default secrets are allowed here, and refused "
            "(the gateway will not start) in any other environment",
        )
    else:
        add("ok", "secrets", "service secret and audit signing key are set")

    # Key rotation: a previous key is a temporary state, and this line says whether it
    # is still needed. Fingerprints only; a key value is never printed.
    from agentfox.core.crypto import InvalidEncryptionKey, keyring

    if settings.token_encryption_key:
        try:
            keyring()
        except InvalidEncryptionKey as exc:
            add("bad", "encryption key", str(exc))
    try:
        from agentfox.platform.keys.rotation import status_summary

        rotation = status_summary(fresh=True)
    except Exception as exc:  # noqa: BLE001 - doctor reports, it does not crash
        rotation = {}
        add("warn", "key rotation", f"could not be checked: {type(exc).__name__}")
    if rotation:
        detail = ", ".join(f"{k.replace('_', ' ')}: {v}" for k, v in rotation.items())
        states = set(rotation.values())
        if "misconfigured" in states:
            add("bad", "key rotation", detail + " — `agentfox admin keys status` says why")
        elif "pending" in states:
            add(
                "warn",
                "key rotation",
                detail + " — data is still on a previous key. Run `agentfox admin keys "
                "rotate` (the job runner also does it); keep the previous key until done.",
            )
        elif "complete" in states:
            add("ok", "key rotation", detail + " — the previous keys can now be removed")
        else:
            add("ok", "key rotation", "no previous key configured; nothing to rotate")

    # Containment before detection, deliberately. Every published adversarial-robustness
    # result says a determined attacker eventually gets past content inspection; what is
    # left at that moment is what an agent is *allowed to do*. That is declared, not
    # detected, so a deployment that has declared nothing is undefended in the case that
    # actually matters — however many detectors it has loaded.
    if tools_declared == 0:
        # "bad" only once something has actually run: a fresh install has declared
        # nothing because nothing has happened yet, which is a starting state, not a
        # misconfiguration. A deployment with live traffic and no declarations is the
        # real failure, and it gets the hard verdict.
        add(
            "bad" if decisions else "info",
            "containment",
            "no tools declared — nothing constrains what an agent may do when a detector "
            "misses. Declare them with `agentfox declare tool <key> --impact ...`."
            + (" Traffic is already being governed without them." if decisions else ""),
        )
    elif tools_acting == 0:
        add(
            "warn",
            "containment",
            f"{plural(tools_declared, 'tool')} declared, none of them "
            "write/high-impact/irreversible — if this agent can act, its impact tiers are "
            "understated and containment rules cannot fire.",
        )
    elif grants == 0:
        add(
            "warn",
            "containment",
            f"{plural(tools_acting, 'acting tool')} declared but no capability grants — least "
            "privilege is unconfigured, so policy is the only thing standing in the way. "
            "Grant them with `agentfox permit grant <agent> <tool> --limit ...`.",
        )
    else:
        add(
            "ok",
            "containment",
            f"{tools_acting} of {plural(tools_declared, 'tool')} can act, "
            f"{plural(grants, 'capability grant')} — an action outside these is refused "
            "whether or not a detector fires",
        )

    if inferred:
        shown = ", ".join(inferred[:4]) + (
            f" and {len(inferred) - 4} more" if len(inferred) > 4 else ""
        )
        add(
            "warn",
            "tool impacts",
            f"{plural(len(inferred), 'tool impact')} guessed from the name, not confirmed: "
            f"{shown}. Check each with `agentfox declare list tools` and confirm or correct "
            "it with `agentfox declare tool <name> --impact <impact>`.",
        )

    add(
        "ok" if scoped_tables else default_state,
        "data scope",
        f"{plural(scoped_tables, 'table')} declared row-scoped"
        if scoped_tables
        else "no table row-scoping declared — a query across every customer's rows reads "
        "as ordinary. Declare with `agentfox declare scope <table> --column ...`.",
    )

    # What runs is enabled ∩ available (see DetectorPipeline.select). Listing every
    # *available* detector showed ones nobody enabled (pii.presidio) and hid the
    # enabled ones that cannot run (a classifier without its model), which is the
    # one thing this line exists to say.
    from agentfox.capabilities.detection import all_detectors

    live = available_detectors()
    enabled = list(dict.fromkeys(settings.enabled_detectors))
    running = sorted(k for k in enabled if k in live)
    missing = [k for k in enabled if k not in live]
    known = all_detectors()

    def _why(key: str) -> str:
        detector = known.get(key)
        if detector is None:
            return "no such detector"
        reason = getattr(detector, "unavailable_reason", None)
        reason = reason() if callable(reason) else reason
        return str(reason or "its dependency is not installed")

    detail = f"{len(running)} running: {', '.join(running) or 'none'}"
    if missing:
        detail += "; enabled but unavailable: " + ", ".join(
            f"{key} ({_why(key)})" for key in missing
        )
    # An enabled detector that needs an optional extra or a model download is the
    # default install, not a fault: said as information locally, with the fix.
    # A name that is no detector at all is a mistake in the config, and stays a warning.
    unknown = [k for k in missing if k not in known]
    add(
        "bad" if not running else "warn" if unknown else default_state if missing else "ok",
        "detectors",
        detail,
    )

    providers = available_providers()
    # available_providers() returns a dict; comparing it to a set was always False,
    # so the offline-only message never showed.
    if set(providers) == {"echo"}:
        add(
            "ok",
            "providers",
            "offline only (echo) for the gateway's own proxy routes. Calls your app "
            "makes itself (agentfox.auto(), the SDK) still go to its provider; set "
            "AGENTFOX_ALLOW_EGRESS=1 and a key to let the gateway proxy calls too.",
        )
    else:
        add("ok", "providers", f"{', '.join(sorted(providers))}")

    add(
        default_state if settings.fail_mode == "open" else "ok",
        "detector failure",
        "fail-open: a detector that times out lets the request through and records the gap"
        if settings.fail_mode == "open"
        else "fail-closed: a degraded detector blocks the request",
    )

    if boundaries == 0:
        add(
            default_state,
            "answerability",
            "no knowledge boundary declared — nothing stops an agent answering a "
            "question it has no data for.",
        )
    else:
        add("ok", "answerability", f"{boundaries} boundary/boundaries declared")

    if account_findings is not None:
        findings = account_findings
    if findings:
        add("warn", "findings", f"{findings} open — run `agentfox findings`")
    else:
        add("ok", "findings", "none open")

    failed = any(state == "bad" for state, _w, _d in checks)

    if as_json:
        console.print_json(
            json.dumps([{"state": s, "check": c, "detail": d} for s, c, d in checks])
        )
        # Same exit contract as the table: JSON mode is what CI uses, so it is the
        # mode that most needs to fail on a bad check.
        raise typer.Exit(1 if failed else 0)

    console.print("[bold]Runtime check[/]")
    marks = {"ok": "[green]✓[/]", "info": "[cyan]i[/]", "warn": "[yellow]![/]", "bad": "[red]✗[/]"}
    table = Table(box=None, padding=(0, 2), show_header=False)
    for state, what, detail in checks:
        # Escaped: details quote install hints such as `agentfox[classifiers]`, which Rich
        # read as a markup tag and printed as `pip install 'agentfox'`.
        table.add_row(marks[state], f"[bold]{what}[/]", escape(detail))
    console.print(table)

    if failed:
        raise typer.Exit(1)


def _check_account(add: Any) -> int | None:
    """The account check `doctor` leads with: which server and key the CLI and
    `agentfox.auto()` use, whether the server answers, whether the key is accepted, and
    which workspace it belongs to. Returns the account's open findings, or None when
    there is no usable account (the local count stands)."""
    import os

    from agentfox.apps.cli.account import AccountError, configured, local_label

    account = configured()
    if account is None:
        url = os.environ.get("AGENTFOX_URL") or os.environ.get("AGENTFOX_API_URL")
        if os.environ.get("AGENTFOX_DATABASE_URL"):
            add("info", "account", f"none: AGENTFOX_DATABASE_URL is set, so {local_label()}")
        elif os.environ.get("AGENTFOX_LOCAL"):
            add("info", "account", f"not used: AGENTFOX_LOCAL is set, so {local_label()}")
        elif url:
            add(
                "warn",
                "account",
                f"AGENTFOX_URL is {url} but no AGENTFOX_API_KEY is set: the CLI and "
                "auto() use this machine's database. `agentfox login` connects the key.",
            )
        else:
            add(
                "info",
                "account",
                f"none — the CLI and auto() use this machine ({local_label()}). "
                "`agentfox login` connects your AgentFox account.",
            )
        return None
    try:
        me = account.me()
        open_findings = len(
            account.get("/api/findings", status="open", limit=10_000).get("findings") or []
        )
    except AccountError as exc:
        add("bad", "account", f"{exc} (key from {account.origin})")
        return None
    add(
        "ok",
        "account",
        f"{account.url} accepts the key — workspace {me.get('workspace') or me.get('org_id')}, "
        f"{me.get('email') or me.get('id')} ({me.get('role')}); key from {account.origin}",
    )
    return open_findings


#: Worst first. `agentfox scan` advertises this list as ranked by severity, and for
#: a long time it was ordered by creation time instead.
SEVERITY_RANK = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}


def _finding_types(as_json: bool) -> None:
    """The finding-type registry (`platform/ledger/finding_types.py`), packs' types included."""
    from rich.table import Table

    from agentfox.platform.ledger.finding_types import all_types

    entries = all_types()
    if as_json:
        console.print_json(json.dumps([entry.to_json() for entry in entries]))
        return
    table = Table(box=None, pad_edge=False)
    for column in ("type", "severity", "owner", "title"):
        table.add_column(column, style="bold" if column == "type" else None)
    for entry in entries:
        colour = SEVERITY_COLOUR.get(entry.severity, "dim")
        table.add_row(
            entry.type,
            f"[{colour}]{entry.severity}[/]",
            f"[dim]{entry.owner}[/]",
            entry.title,
        )
    console.print(table)
    console.print("\n[dim]`agentfox findings --types --json` adds what each one means.[/]")


def findings_cmd(
    severity: str | None = typer.Option(
        None,
        "--severity",
        "-s",
        help="Show only this severity: critical, high, medium, low or info.",
    ),
    limit: int = typer.Option(20, "--limit", "-n", help="How many findings to show, worst first."),
    as_json: bool = typer.Option(
        False,
        "--json",
        help="Full records for scripts: whole ids, fingerprints, subjects and timestamps.",
    ),
    types: bool = typer.Option(
        False,
        "--types",
        help="List every finding type instead: what each means, its usual severity, who raises it.",
    ),
) -> None:
    """What the platform found. The list `agentfox.auto()` tells you to read.

    Ordered worst first, then most recently seen. A finding that keeps happening is
    one row with a count, not one row per occurrence, so the length of this list is
    the number of distinct problems. `--types` lists the kinds of finding there are.
    """
    if types:
        _finding_types(as_json)
        return

    if severity and severity not in SEVERITY_RANK:
        console.print(
            f"[red]unknown severity '{severity}'[/]. Use one of: {', '.join(SEVERITY_RANK)}"
        )
        raise typer.Exit(2)

    from agentfox.apps.cli import account as _account

    remote = _account.use(console, quiet=as_json)
    if remote is not None:
        rows, total = _account_findings(remote, severity, limit)
    else:
        rows, total = _local_findings(severity, limit)

    _print_findings(rows, total, severity, as_json, remote is not None)


#: The most open findings fetched from the account to rank. The route orders by
#: creation time; the CLI ranks worst first, so it ranks the whole open set it gets.
ACCOUNT_FETCH = 2000


def _account_findings(remote: Any, severity: str | None, limit: int) -> tuple[list[dict], int]:
    """The account's open findings (`GET /api/findings`), ranked as the local query is."""
    from agentfox.apps.cli.account import AccountError, fail

    try:
        body = remote.get(
            "/api/findings", status="open", severity=severity or None, limit=ACCOUNT_FETCH
        )
    except AccountError as exc:
        fail(console, exc)
    found = body.get("findings") or []
    found.sort(key=lambda f: f.get("last_seen_at") or f.get("created_at") or "", reverse=True)
    found.sort(key=lambda f: SEVERITY_RANK.get(f.get("severity") or "", 9))
    rows = [
        {
            "id": f["id"],
            "type": f.get("type"),
            "severity": f.get("severity"),
            "title": f.get("title"),
            "subject": f"{f.get('subject_type')}:{f.get('subject_id')}",
            "at": f.get("created_at"),
            "occurrences": f.get("occurrences"),
            "fingerprint": f.get("fingerprint"),
            "last_seen_at": f.get("last_seen_at"),
        }
        for f in found[:limit]
    ]
    return rows, len(found)


def _local_findings(severity: str | None, limit: int) -> tuple[list[dict], int]:
    from sqlalchemy import case, func, select

    from agentfox.core.models import Finding

    with _session() as session:
        # Ranked in SQL, not after the fact: sorting the page the database happened to
        # return would show the worst of twenty rows, not the twenty worst rows.
        rank = case(SEVERITY_RANK, value=Finding.severity, else_=9)
        recency = func.coalesce(Finding.last_seen_at, Finding.created_at)
        stmt = select(Finding).where(Finding.status == "open")
        if severity:
            stmt = stmt.where(Finding.severity == severity)
        total = session.scalar(select(func.count()).select_from(stmt.subquery()))
        rows = [
            {
                "id": f.id,
                "type": f.type,
                "severity": f.severity,
                "title": f.title,
                "subject": f"{f.subject_type}:{f.subject_id}",
                "at": f.created_at.isoformat(),
                "occurrences": f.occurrences,
                "fingerprint": f.fingerprint,
                "last_seen_at": f.last_seen_at.isoformat() if f.last_seen_at else None,
            }
            for f in session.scalars(stmt.order_by(rank, recency.desc()).limit(limit))
        ]
    return rows, total or 0


def _print_findings(
    rows: list[dict], total: int, severity: str | None, as_json: bool, on_account: bool
) -> None:
    if as_json:
        console.print_json(json.dumps(rows, default=str))
        return
    if not rows:
        scope = f" at severity '{severity}'" if severity else ""
        console.print(f"[green]No open findings{scope}.[/]")
        return

    # Narrow padding and a merged severity/count column so the title keeps enough
    # width to wrap between words on an 80-column terminal instead of inside one.
    table = Table(box=None, padding=(0, 1), header_style="dim")
    table.add_column("id", no_wrap=True)
    table.add_column("severity", no_wrap=True)
    table.add_column("type", no_wrap=True)
    # No slice: a type cut to "INJECTION.INSTRUCTION_OVER" names a category that does
    # not exist, and nothing can be grepped for it.
    table.add_column("what", ratio=1)
    for row in rows:
        colour = SEVERITY_COLOUR.get(row["severity"], "dim")
        occurrences = row["occurrences"] or 1
        seen = f" [bold]{occurrences}x[/]" if occurrences > 1 else ""
        table.add_row(
            f"[dim]{short_id(row['id'])}[/]",
            f"[{colour}]{row['severity']}[/]{seen}",
            f"[dim]{row['type']}[/]",
            row["title"],
        )
    console.print(table)

    repeats = sum((row["occurrences"] or 1) for row in rows)
    shown = f"{len(rows)} of {total}" if total and total > len(rows) else str(len(rows))
    console.print(
        f"\n  [dim]{shown} open finding{'' if max(total or 0, len(rows)) == 1 else 's'}"
        + (f", {repeats} occurrences in total" if repeats > len(rows) else "")
        + ".[/]"
    )

    steps: list[tuple[str, str]] = []
    if total and total > len(rows):
        steps.append((f"agentfox findings --limit {total}", "show the rest of them"))
    worst = min(rows, key=lambda r: SEVERITY_RANK.get(r["severity"], 9))["severity"]
    if not severity and worst in ("critical", "high"):
        steps.append((f"agentfox findings --severity {worst}", f"just the {worst} ones"))
    steps.append((f"agentfox findings show {rows[0]['id'][-8:]}", "one finding in full, by id"))
    steps.append(("agentfox findings --json", "whole ids, fingerprints and subjects"))
    steps.append(("agentfox doctor", "check the runtime configuration that produced these"))
    if not on_account:
        steps.append(
            (
                "agentfox serve",
                "control plane on http://127.0.0.1:8080, the full detail view",
            )
        )
    _print_next_steps(steps)


def login(
    server: str = typer.Option(
        "",
        "--server",
        help="Your AgentFox gateway address, shown beside the key on Get started. "
        "Default: AGENTFOX_URL.",
    ),
    key: str = typer.Option(
        "",
        "--key",
        help="A workspace key (Get started → Create a key). Default: AGENTFOX_API_KEY, "
        "else asked for without echoing it, which keeps it out of `ps` and your history.",
    ),
    path: Path = typer.Option(
        Path("."), "--path", "-p", help="The project to connect. Default: here."
    ),
) -> None:
    """Connect this project to your AgentFox account with one key, from the terminal.

    Checks the key against the server, then saves it in `.agentfox/agentfox.env`
    (owner-only, git-ignored) exactly as `agentfox init --key` does. From then on
    `agentfox.auto()` reports to the account and `findings`, `agents`, `permit`,
    `declare`, `policy`, `report` and `test suites` read and write it.
    """
    import os
    import sys

    from agentfox.apps.cli.account import Account, AccountError, keys_page
    from agentfox.capabilities.onboarding.project_files import read_env, write_env
    from agentfox.core.config import api_key_from_env, api_url_from_env

    saved = read_env(path)
    server = (server or api_url_from_env(os.environ, saved) or "").strip()
    key = (key or api_key_from_env(os.environ) or "").strip()
    interactive = sys.stdin.isatty()
    if not server:
        if not interactive:
            console.print(
                "[red]No server given.[/] Pass --server with the gateway address shown "
                "on Get started in the AgentFox dashboard, or set AGENTFOX_URL."
            )
            raise typer.Exit(2)
        server = console.input("Gateway address (shown on Get started): ").strip()
    if not key:
        where = keys_page(server)
        if not interactive:
            console.print(
                f"[red]No key given.[/] Make one on {escape(where)}, then "
                "`export AGENTFOX_API_KEY=...` and run `agentfox login` again."
            )
            raise typer.Exit(2)
        console.print(f"Make a key on {escape(where)} and paste it here.")
        key = console.input("Key: ", password=True).strip()

    account = Account(url=server, key=key)
    try:
        me = account.me()
    except AccountError as exc:
        console.print(f"[red]{escape(str(exc))}[/] Nothing was saved.")
        raise typer.Exit(1) from None
    env = write_env(
        path, {"AGENTFOX_URL": account.url, "AGENTFOX_API_KEY": key}, by="agentfox login"
    )
    workspace = me.get("workspace") or me.get("org_id")
    console.print(
        f"[green]✓[/] Connected to [bold]{escape(account.url)}[/] as "
        f"{escape(str(me.get('email') or me.get('id')))} ({me.get('role')}), "
        f"workspace [bold]{escape(str(workspace))}[/]."
    )
    console.print(f"  [dim]Key saved in {escape(str(env))} (owner-only, git-ignored).[/]")
    _print_next_steps(
        [
            ("agentfox doctor", "check the key, the server and the runtime"),
            ("agentfox findings", "what your account has found"),
            ("agentfox up", "add agentfox.auto() to your app so its calls reach the account"),
        ]
    )


def findings_show(
    finding_id: str = typer.Argument(
        ..., help="The finding's id: whole, or the tail `agentfox findings` prints."
    ),
    as_json: bool = typer.Option(False, "--json", help="The whole record, for scripts."),
) -> None:
    """One finding in full: its whole id, what it is about, when, and the evidence."""
    from sqlalchemy import select

    from agentfox.apps.cli import account as _account
    from agentfox.apps.cli._style import match_id
    from agentfox.core.models import Finding

    remote = _account.use(console, quiet=as_json)
    if remote is not None:
        record = _account_finding(remote, finding_id)
    else:
        record = _local_finding(finding_id, select, match_id, Finding)
    _print_finding(record, as_json)


def _account_finding(remote: Any, finding_id: str) -> dict[str, Any]:
    """One finding from the account: the whole id, or the tail `findings` prints."""
    from agentfox.apps.cli._style import match_id
    from agentfox.apps.cli.account import AccountError, fail

    try:
        listed = remote.get("/api/findings", limit=ACCOUNT_FETCH).get("findings") or []
        ids = [f["id"] for f in listed if match_id(finding_id, f["id"])]
        if finding_id not in ids and not ids:
            ids = [finding_id]  # maybe resolved or old: ask for it by the id given
        if len(ids) > 1:
            console.print(
                f"[yellow]'{escape(finding_id)}' matches {len(ids)} findings[/]; give more "
                "of the id: " + ", ".join(ids[:5])
            )
            raise typer.Exit(2)
        f = remote.get(f"/api/findings/{ids[0]}")
    except AccountError as exc:
        if exc.status == 404:
            console.print(
                f"[red]no finding '{escape(finding_id)}'[/] — `agentfox findings` lists them"
            )
            raise typer.Exit(2) from None
        fail(console, exc)
    return {
        "id": f["id"],
        "type": f.get("type"),
        "severity": f.get("severity"),
        "status": f.get("status"),
        "title": f.get("title") or "",
        "subject": f"{f.get('subject_type')}:{f.get('subject_id')}",
        "occurrences": f.get("occurrences") or 1,
        "created_at": f.get("created_at"),
        "last_seen_at": f.get("last_seen_at"),
        "controls": list(f.get("controls") or []),
        "evidence": f.get("evidence") or {},
        "fingerprint": None,
    }


def _local_finding(finding_id: str, select: Any, match_id: Any, Finding: Any) -> dict[str, Any]:  # noqa: N803
    with _session() as session:
        matches = [f for f in session.scalars(select(Finding)) if match_id(finding_id, f.id)]
        if not matches:
            console.print(
                f"[red]no finding '{escape(finding_id)}'[/] — `agentfox findings` lists them"
            )
            raise typer.Exit(2)
        if len(matches) > 1:
            console.print(
                f"[yellow]'{escape(finding_id)}' matches {len(matches)} findings[/]; give more "
                "of the id: " + ", ".join(f.id for f in matches[:5])
            )
            raise typer.Exit(2)
        f = matches[0]
        record = {
            "id": f.id,
            "type": f.type,
            "severity": f.severity,
            "status": f.status,
            "title": f.title,
            "subject": f"{f.subject_type}:{f.subject_id}",
            "occurrences": f.occurrences or 1,
            "created_at": f.created_at.isoformat() if f.created_at else None,
            "last_seen_at": f.last_seen_at.isoformat() if f.last_seen_at else None,
            "controls": list(f.control_keys or []),
            "evidence": f.evidence_json or {},
            "fingerprint": f.fingerprint,
        }
    return record


def _print_finding(record: dict[str, Any], as_json: bool) -> None:
    if as_json:
        console.print_json(json.dumps(record, default=str))
        return
    colour = SEVERITY_COLOUR.get(record["severity"], "dim")
    console.print(f"[bold]{escape(record['title'])}[/]")
    # The id on a line of its own, whole and unstyled, so it copies cleanly.
    console.print(record["id"], soft_wrap=True, highlight=False)
    rows = [
        ("severity", f"[{colour}]{record['severity']}[/]"),
        ("type", record["type"]),
        ("status", record["status"]),
        ("about", escape(record["subject"])),
        ("seen", f"{plural(record['occurrences'], 'time')}, first {record['created_at']}"),
    ]
    if record["last_seen_at"]:
        rows.append(("last seen", record["last_seen_at"]))
    if record["controls"]:
        rows.append(("controls", ", ".join(record["controls"])))
    table = Table(box=None, padding=(0, 2), show_header=False)
    table.add_column(style="dim", no_wrap=True)
    table.add_column(overflow="fold")
    for name, value in rows:
        table.add_row(name, value)
    console.print(table)
    if record["evidence"]:
        console.print("\n[dim]evidence[/]")
        console.print_json(json.dumps(record["evidence"], default=str))


def register(app: typer.Typer) -> None:
    """Attach the onboarding commands as top-level verbs."""
    app.command(name="login")(login)
    app.command(name="init")(init)
    app.command(name="check")(check)
    app.command(name="doctor")(doctor)
    app.command(name="findings")(findings_cmd)
