"""`agentfox policy` — write the rules, simulate them on recorded traffic, turn them on."""

from __future__ import annotations

import datetime as dt
import os
import re
from pathlib import Path

import typer
from rich.markup import escape
from rich.table import Table

from agentfox.apps.cli._style import SEVERITY_COLOUR
from agentfox.apps.cli.commands._shared import _emit, _session, console
from agentfox.apps.cli.commands.packs import packs_app

policy_app = typer.Typer(
    help="Write rules, try them on recorded traffic, then turn them on.",
    no_args_is_help=True,
)
policy_app.add_typer(packs_app, name="packs")


@policy_app.command("list")
def policy_list() -> None:
    """List policies and their enforcement mode."""
    from sqlalchemy import select

    from agentfox.apps.cli import account as _account
    from agentfox.core.models import Policy, PolicyVersion
    from agentfox.platform.policy import current_binding

    table = Table(box=None, pad_edge=False)
    for column in ("policy", "version", "mode", "rules"):
        table.add_column(column, style="bold" if column == "policy" else None)

    remote = _account.use(console)
    if remote is not None:
        try:
            policies = remote.get("/api/policies").get("policies") or []
            business = [
                r["mode"]
                for r in remote.get("/api/business/rules").get("rules") or []
                if r.get("enabled")
            ]
        except _account.AccountError as exc:
            _account.fail(console, exc)
        for policy in policies:
            if policy.get("latest_version") is None:
                continue
            mode = policy.get("mode") or "unbound"
            shown = policy.get("bound_version") or policy["latest_version"]
            version = f"v{shown}"
            if policy.get("bound_version") and policy["bound_version"] != policy["latest_version"]:
                version += f" [dim](v{policy['latest_version']} saved, not live)[/]"
            table.add_row(
                policy["key"],
                version,
                f"[green]{mode}[/]" if mode == "enforce" else f"[yellow]{mode}[/]",
                str(policy.get("rules", 0)),
            )
        _business_row(table, business)
        console.print(table)
        return

    with _session() as session:
        for policy in session.scalars(select(Policy).order_by(Policy.key)):
            latest = session.scalars(
                select(PolicyVersion)
                .where(PolicyVersion.policy_id == policy.id)
                .order_by(PolicyVersion.version.desc())
            ).first()
            if latest is None:
                continue
            # The live binding, whichever version it points at — mid-canary or after
            # a rollback that is not the newest version.
            binding, bound = current_binding(session, policy.id)
            mode = binding.mode if binding else "unbound"
            shown = bound or latest
            version = f"v{shown.version}"
            if bound is not None and bound.id != latest.id:
                version += f" [dim](v{latest.version} saved, not live)[/]"
            table.add_row(
                policy.key,
                version,
                f"[green]{mode}[/]" if mode == "enforce" else f"[yellow]{mode}[/]",
                str(len((shown.compiled_json or {}).get("rules", []))),
            )
        # Business rules (approval limits) are rules too, stored apart from the
        # packs; the dashboard counts them in Your rules, so they are counted here.
        _business_row(table, _business_modes(session))
        console.print(table)


def _business_row(table: Table, business: list[str]) -> None:
    if business:
        modes = set(business)
        mode = modes.pop() if len(modes) == 1 else "mixed"
        table.add_row(
            "business rules",
            "—",
            f"[green]{mode}[/]" if mode == "enforce" else f"[yellow]{mode}[/]",
            str(len(business)),
        )


def _business_modes(session) -> list[str]:
    """Each enabled business rule's mode, one entry per rule."""
    from agentfox.capabilities.business.store import rule_entries

    return [e["enforcement"] for e in rule_entries(session)]


@policy_app.command("lint")
def policy_lint(
    files: list[Path] | None = typer.Argument(
        None,
        help="Policy files to lint, as org-level layers in the order given. "
        "Without files, lints every bound policy layer.",
    ),
) -> None:
    """Lint the policy hierarchy, or policy files. Exits 1 on critical or high findings.

    This is the half of hierarchical policy that produces the 87% misconfiguration
    reduction — composition without a linter just moves the confusion somewhere
    harder to see. Pass files to check them before they are loaded, e.g. in CI.
    """
    from agentfox.platform.policy import lint_all, lint_documents, lint_summary

    if files:
        report = lint_summary(lint_documents([_read_policy_file(path) for path in files]))
    else:
        with _session() as session:
            report = lint_all(session)
    _print_lint(report)
    if not report["passed"]:
        console.print("\n[bold red]LINT FAIL[/] — critical/high findings block the build")
        raise typer.Exit(1)
    if report["findings"]:
        console.print("\n[green]LINT PASS[/] [dim](advisory findings only)[/]")


def _effective_columns(rows: list[dict], width: int) -> dict[str, int]:
    """Which columns `policy effective` shows, and how wide, for a terminal ``width``.

    Every column but the title is shown whole. The title gets what is left, and is left
    out when that is too little to read; `overrides` only appears when a rule has one.
    """
    names = ["rule", "effect", "mode", "from"]
    if any(row["overrides"] != "—" for row in rows):
        names.append("overrides")
    widths = {n: max([len(n), *(len(str(row[n])) for row in rows)]) for n in names}
    used = sum(widths.values()) + 2 * len(widths)  # one space either side of each column
    room = min(48, width - used - 2)
    columns: dict[str, int] = {"rule": widths["rule"]}
    if room >= 16:
        columns["title"] = room
    columns.update({n: widths[n] for n in names[1:]})
    return columns


def _rule_title(rule: dict) -> str:
    """What a person calls the rule: its title or description, one line."""
    text = str(rule.get("title") or rule.get("description") or "").strip()
    return " ".join(text.split()) or "—"


def _read_policy_file(path: Path):
    from agentfox.platform.policy import PolicyDocument

    try:
        return PolicyDocument.from_yaml(path.read_text())
    except Exception as exc:
        console.print(f"[red]invalid:[/] {path}: {' '.join(str(exc).split())}")
        raise typer.Exit(1) from exc


def _print_lint(report: dict) -> None:
    if not report["findings"]:
        console.print("[green]no policy issues[/]")
        return

    table = Table(box=None, pad_edge=False)
    for column in ("severity", "code", "rule", "level", "message"):
        table.add_column(column, style="bold" if column == "code" else None)
    order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    for finding in sorted(report["findings"], key=lambda f: order.get(f["severity"], 9)):
        colour = SEVERITY_COLOUR.get(finding["severity"], "dim")
        table.add_row(
            f"[{colour}]{finding['severity']}[/]",
            finding["code"],
            finding["rule_id"],
            finding["level"] or "—",
            finding["message"][:74],
        )
    console.print(table)
    console.print(f"  [dim]{report['counts']}[/]")


@policy_app.command("effective")
def policy_effective(
    agent: str | None = None,
    team: str | None = None,
    user: str | None = None,
    environment: str | None = typer.Option(
        None,
        "--environment",
        help="Environment to resolve for. Defaults to the one the gateway resolves "
        "the agent in: its registered environment, or production without --agent.",
    ),
) -> None:
    """Show the policy actually in force for a subject, and where each rule came from.

    Opacity is what makes layered policy dangerous, so the resolver explains itself.
    Business rules (approval limits) are listed too, from `business`.
    """
    from agentfox.apps.cli import account as _account
    from agentfox.capabilities.business.store import effective_entries
    from agentfox.platform.policy import effective_for, runtime_environment

    remote = _account.use(console)
    if remote is not None:
        try:
            explanation = remote.get(
                "/api/policies/effective",
                agent=agent,
                team=team,
                user=user,
                environment=environment,
            )
        except _account.AccountError as exc:
            _account.fail(console, exc)
        environment = explanation.get("environment") or environment or "production"
    else:
        with _session() as session:
            environment = environment or runtime_environment(session, agent)
            effective = effective_for(
                session, agent_slug=agent, environment=environment, team=team, user=user
            )
            explanation = effective.explain()
            explanation["rules"] = [*explanation["rules"], *effective_entries(session, agent)]

    # Per layer, not one mode for the lot: "mode enforce" whenever any layer
    # enforced read as though every rule listed was enforcing.
    console.print(
        f"[bold]effective policy[/] in [bold]{environment}[/] — "
        f"default {explanation['default_effect']}"
    )
    if explanation["layer_modes"]:
        console.print("  [dim]layers:[/]")
        for layer in explanation["layer_modes"]:
            colour = "green" if layer["mode"] == "enforce" else "yellow"
            console.print(
                f"    {layer['level']}:{layer['scope']}({layer['compose']})  "
                f"{layer['policy']}  [{colour}]{layer['mode']}[/]"
            )
        console.print()
    else:
        console.print("  [dim]layers: none[/]\n")

    rows = [
        {
            "rule": rule["rule_id"],
            "title": _rule_title(rule),
            "effect": rule["effect"],
            "mode": rule["enforcement"],
            "from": rule["source"],
            "overrides": ", ".join(rule["overrides"]) or "—",
        }
        for rule in explanation["rules"]
    ]
    columns = _effective_columns(rows, console.width)
    table = Table(box=None, pad_edge=False)
    for column, width in columns.items():
        # One line per rule, every id, effect and mode whole: only the title gives way
        # to the terminal's width, and at 80 columns it is left out rather than cut to
        # "A query …" while the mode read "observ".
        table.add_column(
            column,
            style="bold" if column == "rule" else ("dim" if column == "title" else None),
            no_wrap=True,
            overflow="ellipsis" if column == "title" else "fold",
            min_width=None if column == "title" else width,
            max_width=width if column == "title" else None,
        )
    for row in rows:
        table.add_row(*(row[column] for column in columns))
    console.print(table)
    if "title" not in columns and rows:
        console.print(
            "  [dim]rule titles are left out at this width; a wider terminal shows them[/]"
        )

    if explanation["rejected"]:
        console.print("\n[bold yellow]rejected layer rules[/]")
        for rejected in explanation["rejected"]:
            console.print(
                f"  [yellow]{rejected['rule_id']}[/] at {rejected['level']}:"
                f"{rejected['scope']} — {rejected['reason'][:88]}"
            )

    if explanation.get("unloadable_policies"):
        console.print("\n[bold red]bound but unloadable — not in force[/]")
        for entry in explanation["unloadable_policies"]:
            console.print(f"  [red]{entry['key']} v{entry['version']}[/] — {entry['error'][:88]}")


@policy_app.command("simulate")
def policy_simulate(
    key: str | None = typer.Argument(
        None,
        help="A policy already loaded (`agentfox policy list`): replay its live version, "
        "the simulation `policy enforce` needs before it blocks. Or give --file.",
    ),
    file: Path | None = typer.Option(None, "--file", "-f", help="Candidate policy YAML."),
    agent: str | None = typer.Option(None, "--agent", help="Replay one agent's traffic only."),
    since_days: int = typer.Option(30, "--since-days", help="How far back to replay."),
    limit: int = typer.Option(1000, "--limit", help="The most recorded calls to replay."),
) -> None:
    """Replay recorded traffic against a candidate policy, or a loaded one by key.

    Exits non-zero when the change would newly block production traffic, so it can
    gate a policy PR the same way `agentfox test gate` gates a code PR.
    """
    from agentfox.apps.cli import account as _account
    from agentfox.platform.policy import PolicyDocument, record_simulation, simulate

    if (key is None) == (file is None):
        raise typer.BadParameter("give a policy key or --file, not both", param_hint="KEY")
    if file is not None and not file.is_file():
        console.print(f"[red]No policy file at {escape(str(file))}.[/] Pass the YAML to simulate.")
        raise typer.Exit(2)
    remote = _account.use(console)
    if remote is not None:
        try:
            body = file.read_text() if file is not None else _live_body(remote, key or "")
            result = remote.post(
                "/api/policies/simulate",
                {"body": body, "agent": agent, "since_days": since_days, "limit": limit},
            )
        except _account.AccountError as exc:
            _account.fail(console, exc)
        name = key or PolicyDocument.from_yaml(body).key
        newly = {
            k: result.get(k) or [] for k in ("newly_blocked", "newly_escalated", "newly_allowed")
        }
        _print_simulation(
            name,
            result.get("replayed", 0),
            result.get("unchanged", 0),
            newly,
            bool(result.get("risky")),
        )
        return

    if file is not None:
        try:
            PolicyDocument.from_yaml(file.read_text())
        except Exception as exc:  # noqa: BLE001 - any parse or schema error, said in one line
            why = escape(str(exc))[:200]
            console.print(f"[red]{escape(str(file))} isn't a policy AgentFox can read:[/] {why}")
            raise typer.Exit(2) from None
    with _session() as session:
        if file is not None:
            candidate = PolicyDocument.from_yaml(file.read_text())
        else:
            candidate = PolicyDocument.from_yaml(_local_live_body(session, key or ""))
        diff = simulate(
            session,
            candidate,
            agent_slug=agent,
            since=dt.datetime.now(dt.UTC) - dt.timedelta(days=since_days),
            limit=limit,
        )
        record_simulation(session, candidate, diff, run_by="cli")
    _print_simulation(
        candidate.key,
        diff.replayed,
        diff.unchanged,
        {
            "newly_blocked": diff.newly_blocked,
            "newly_escalated": diff.newly_escalated,
            "newly_allowed": diff.newly_allowed,
        },
        diff.risky,
    )


def _unknown_policy(key: str, known: list[str]) -> None:
    # "unknown policy" with no list leaves the reader guessing at a key they have
    # never seen written down.
    console.print(f"[red]unknown policy '{key}'[/]")
    if known:
        console.print(f"  known policies: {', '.join(sorted(known))}")
        console.print("  [dim]`agentfox policy list` shows each one's mode.[/]")
    else:
        console.print("  no policies loaded yet. Run `agentfox init` to load the shipped packs.")
    raise typer.Exit(1)


def _live_body(remote, key: str) -> str:
    """The YAML of the version of ``key`` in force on the account (newest when unbound)."""
    from agentfox.apps.cli.account import AccountError

    try:
        policy = remote.get(f"/api/policies/{key}")
    except AccountError as exc:
        if exc.status != 404:
            raise
        _unknown_policy(key, [p["key"] for p in remote.get("/api/policies").get("policies") or []])
    return policy.get("live_body") or policy.get("body") or ""


def _local_live_body(session, key: str) -> str:
    from sqlalchemy import select

    from agentfox.core.models import Policy, PolicyVersion
    from agentfox.platform.policy import current_binding

    policy = session.scalar(select(Policy).where(Policy.key == key))
    if policy is None:
        _unknown_policy(key, [p.key for p in session.scalars(select(Policy))])
    _binding, bound = current_binding(session, policy.id)
    version = (
        bound
        or session.scalars(
            select(PolicyVersion)
            .where(PolicyVersion.policy_id == policy.id)
            .order_by(PolicyVersion.version.desc())
        ).first()
    )
    return version.body if version else ""


def _print_simulation(
    name: str, replayed: int, unchanged: int, newly: dict[str, list], risky: bool
) -> None:
    console.print(f"[bold]{name}[/] simulated against {replayed} decisions")
    console.print(f"  unchanged        {unchanged}")
    console.print(f"  newly blocked    [red]{len(newly['newly_blocked'])}[/]")
    console.print(f"  newly escalated  [yellow]{len(newly['newly_escalated'])}[/]")
    console.print(f"  newly allowed    [green]{len(newly['newly_allowed'])}[/]")
    for label, colour, records in (
        ("would block", "red", newly["newly_blocked"]),
        ("would escalate", "yellow", newly["newly_escalated"]),
        ("would allow", "green", newly["newly_allowed"]),
    ):
        for record in records[:10]:
            why = (record["reasons"] or [""])[0] or (
                f"was {record['was']}; no longer fires: "
                + (", ".join(record.get("no_longer_fires") or []) or "—")
            )
            console.print(
                f"    [{colour}]{label}[/] {record['agent'] or '—'} {record['surface']} "
                f"{record['tool'] or ''} — {why[:80]}"
            )
        if len(records) > 10:
            console.print(f"    [dim]… and {len(records) - 10} more {label}[/]")
    if risky:
        console.print(
            "\n[bold red]This change would block production traffic. "
            "Review before promoting to enforce.[/]"
        )
        raise typer.Exit(1)
    console.print("\n[green]No production traffic would newly block.[/]")


@policy_app.command("enforce")
def policy_enforce(key: str) -> None:
    """Promote a policy from observe to enforce.

    KEY is a policy key (`agentfox policy list`) or a library applied per agent
    (`basic`, `tool-containment`): every agent's copy of it is switched.
    """
    _set_mode(key, "enforce")
    _warn_observe_lines(Path.cwd())


#: Directories never searched for `agentfox.auto(...)` lines: installs and VCS.
_SKIP_DIRS = {".git", ".venv", "venv", "env", "node_modules", "site-packages", "__pycache__"}


def observe_lines(root: Path, limit: int = 5000) -> list[tuple[Path, int, str]]:
    """The `agentfox.auto(..., mode="observe")` lines under ``root``: (file, line
    number, line). Such a line never raises, whatever the policies' modes, so
    `policy enforce` changes nothing for that process. Earlier versions of
    `agentfox up` wrote it."""
    found: list[tuple[Path, int, str]] = []
    seen = 0
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS and not d.startswith(".")]
        for name in filenames:
            if not name.endswith(".py"):
                continue
            seen += 1
            if seen > limit:
                return found
            path = Path(dirpath) / name
            try:
                text = path.read_text(errors="ignore")
            except OSError:
                continue
            if "agentfox.auto(" not in text:
                continue
            lines = text.splitlines()
            # Calls in the code, not mentions in a comment or a docstring.
            for number in _observe_calls(text):
                found.append((path, number, lines[number - 1].strip()))
    return found


def _observe_calls(text: str) -> list[int]:
    """Line numbers of `agentfox.auto(..., mode="observe")` calls in this source."""
    import ast

    try:
        tree = ast.parse(text)
    except (SyntaxError, ValueError):
        return []
    return sorted(
        node.lineno
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "auto"
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == "agentfox"
        and any(
            k.arg == "mode" and isinstance(k.value, ast.Constant) and k.value.value == "observe"
            for k in node.keywords
        )
    )


def _warn_observe_lines(root: Path) -> None:
    """Say which `auto(mode="observe")` lines keep blocking off, and the edit."""
    from rich.markup import escape

    for path, number, line in observe_lines(root):
        try:
            where = path.relative_to(root)
        except ValueError:
            where = path
        fixed = re.sub(r""",?\s*mode\s*=\s*["']observe["']""", "", line).replace("(,", "(")
        console.print(
            f"[yellow]{escape(str(where))}:{number} calls agentfox.auto with "
            f'mode="observe", which never blocks whatever the policies say.[/] '
            f"For this to take effect there, change the line to: [cyan]{escape(fixed)}[/]"
        )


@policy_app.command("observe")
def policy_observe(key: str) -> None:
    """Demote a policy from enforce to observe."""
    _set_mode(key, "observe")


def _set_mode(key: str, mode: str) -> None:
    from sqlalchemy import select

    from agentfox.apps.cli import account as _account
    from agentfox.core.models import Policy
    from agentfox.platform.ledger import chain
    from agentfox.platform.policy import set_mode

    remote = _account.use(console)
    if remote is not None:
        _account_set_mode(remote, key, mode)
        return

    with _session() as session:
        binding = set_mode(session, key, mode)
        if binding is None:
            # A library applied per agent (the dashboard's Libraries, `basic` the basic
            # guardrails) lives in one copy per agent, `agent.<slug>.<key>`: switch
            # them all, so the command the docs and `auto()` give works there too.
            copies = sorted(
                k
                for k in session.scalars(select(Policy.key).where(Policy.key.like("agent.%")))
                if k.count(".") >= 2 and k.split(".", 2)[2] == key
            )
            for copy in copies:
                set_mode(session, copy, mode)
                chain.append(
                    session,
                    f"policy.mode_{mode}",
                    actor_type="user",
                    actor_id="cli",
                    subject_type="policy",
                    subject_id=copy,
                    payload={"mode": mode, "library": key},
                )
                console.print(f"[green]{copy}[/] → [bold]{mode}[/]")
            if copies:
                return
            # A shipped pack this workspace never loaded (a workspace set up from the
            # dashboard has the per-agent libraries instead): load it in that mode.
            from agentfox.platform.policy import load_available, save_policy

            shipped = next((d for d in load_available() if d.key == key), None)
            if shipped is not None:
                save_policy(
                    session,
                    shipped,
                    author="cli",
                    notes="loaded by agentfox policy",
                    bind_mode=mode,
                )
                binding = set_mode(session, key, mode)
        if binding is None:
            _unknown_policy(key, [p.key for p in session.scalars(select(Policy))])
        chain.append(
            session,
            f"policy.mode_{mode}",
            actor_type="user",
            actor_id="cli",
            subject_type="policy",
            subject_id=key,
            payload={"mode": mode},
        )
    console.print(f"[green]{key}[/] → [bold]{mode}[/]")


def _account_set_mode(remote, key: str, mode: str) -> None:
    """Change the mode on the account, through the route the dashboard uses: blocking
    needs a recorded simulation of exactly the rules that would block, as Start
    blocking does in the dashboard (`policy simulate <key>` records one)."""
    from agentfox.apps.cli.account import AccountError, fail

    try:
        changed = remote.post(f"/api/policies/{key}/mode", {"mode": mode})
    except AccountError as exc:
        if exc.status == 404:
            try:
                known = [p["key"] for p in remote.get("/api/policies").get("policies") or []]
            except AccountError:
                known = []
            # A library applied per agent lives in one copy per agent
            # (`agent.<slug>.<key>`): switch them all, as the local path does.
            copies = sorted(
                k
                for k in known
                if k.startswith("agent.") and k.count(".") >= 2 and k.split(".", 2)[2] == key
            )
            if not copies:
                _unknown_policy(key, known)
            for copy in copies:
                _account_set_mode(remote, copy, mode)
            return
        if exc.status == 409 and mode == "enforce":
            console.print(
                f"[yellow]{key} has not been simulated yet[/], so it is still watching. "
                "Blocking needs a replay of recent traffic first, as in the dashboard:"
            )
            console.print(f"  agentfox policy simulate {key}")
            console.print(f"  agentfox policy enforce {key}")
            raise typer.Exit(1) from None
        fail(console, exc)
    console.print(
        f"[green]{key}[/] → [bold]{changed.get('mode', mode)}[/]  [dim]in your account[/]"
    )


@policy_app.command("validate")
def policy_validate(file: Path) -> None:
    """Check, lint and compile a policy file without saving it.

    Runs the full lint (`policy lint FILE`), so a rule that can never fire or a
    condition naming an unknown value (`surface: [toolargs]`) fails validation.
    Exits 1 on a parse error or a critical/high finding.
    """
    from agentfox.platform.policy import compile_to_rego, lint_documents, lint_summary

    doc = _read_policy_file(file)
    report = lint_summary(lint_documents([doc]))
    if not report["passed"]:
        console.print(f"[red]invalid:[/] {doc.key} — {len(report['blocking'])} blocking finding(s)")
        _print_lint(report)
        raise typer.Exit(1)
    console.print(
        f"[green]valid[/] — {doc.key} v{doc.version}, {len(doc.rules)} rules, mode={doc.mode}"
    )
    console.print(f"  controls: {sorted({c for r in doc.rules for c in r.controls})}")
    console.print(f"  [dim]compiles to {len(compile_to_rego(doc).splitlines())} lines of Rego[/]")
    if report["findings"]:
        _print_lint(report)


@policy_app.command("export")
def policy_export(
    out: Path = typer.Option(None, "--out", "-o", help="Write to this file instead of stdout."),
) -> None:
    """Write every policy, custom rule and detector switch as one YAML file."""
    from agentfox.capabilities import workspace

    with _session() as session:
        text = workspace.dump(workspace.export_bundle(session))
    if out is None:
        typer.echo(text, nl=False)
        return
    out.write_text(text)
    console.print(f"[green]wrote[/] {out}")


@policy_app.command("apply")
def policy_apply(
    file: Path,
    yes: bool = typer.Option(False, "--yes", "-y", help="Apply without asking."),
) -> None:
    """Make the workspace match a file from `policy export`. Shows the plan first.

    Anything the file leaves out is left alone. A policy the file moves to enforce
    is simulated against the last week first.
    """
    from agentfox.capabilities import workspace

    try:
        bundle = workspace.parse(file.read_text())
    except (OSError, workspace.BundleError) as exc:
        console.print(f"[red]{exc}[/]")
        raise typer.Exit(1) from exc
    with _session() as session:
        the_plan = workspace.plan(session, bundle)
        changes = the_plan.changes
        if not changes:
            console.print("[green]Nothing to change.[/]")
            return
        table = Table(box=None, pad_edge=False)
        for column in ("", "kind", "key", "detail"):
            table.add_column(column)
        mark = {"new": "[green]+[/]", "changed": "[yellow]~[/]", "mode": "[yellow]~[/]"}
        for item in changes:
            table.add_row(mark[item.change], item.kind.replace("_", " "), item.key, item.detail)
        console.print(table)
        if not yes and not typer.confirm(f"Apply {len(changes)} change(s)?"):
            raise typer.Exit(1)
        applied = workspace.apply(session, bundle, actor="cli", reason=f"applied {file.name}")
        for key, sim in applied.simulations.items():
            counts = sim.get("counts", {})
            console.print(
                f"[bold]{key}[/] enforcing: {counts.get('newly_blocked', 0)} newly blocked "
                f"in {sim.get('replayed', 0)} replayed requests"
            )
    console.print(f"[green]Applied {len(changes)} change(s).[/]")


_STATUS_MARK = {
    "translated": "[green]translated[/]",
    "translated_with_note": "[yellow]with note[/]",
    "untranslatable": "[red]not translated[/]",
}


@policy_app.command("import")
def policy_import(
    file: Path = typer.Argument(..., help="Agent-governance rule YAML or a policy manifest."),
    source_format: str = typer.Option(
        "agent-governance",
        "--from",
        help="The format FILE is written in. Only `agent-governance` is read today.",
    ),
    bundle: Path | None = typer.Option(
        None,
        "--bundle",
        help="Directory of the manifest's Rego bundle. Default: the bundle path the "
        "manifest names, next to it.",
    ),
    apply_plan: bool = typer.Option(
        False, "--apply", help="Save the translated policies, in observe. Without it: plan only."
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Apply without asking."),
    as_json: bool = typer.Option(False, "--json", help="Print the plan (or result) as JSON."),
) -> None:
    """Translate a policy written for another engine; show the plan, or apply it in observe.

    Policies written for the Agent Governance Toolkit (rule YAML with `default_action`,
    or a policy manifest with its Rego bundle) can be imported. Every source rule is
    listed as translated, translated with a note, or not translatable with the reason.
    Nothing is enforced: imported policies are saved in observe, and turning one on
    still needs a simulation (`policy simulate`, then `policy enforce`).
    Exits 1 when the file cannot be read.
    """
    from agentfox.capabilities.detection.importers import agent_governance as importer
    from agentfox.platform.policy.compat.agent_governance import bundle_files

    if source_format != importer.TOOL:
        raise typer.BadParameter(f"choose {importer.TOOL}", param_hint="--from")
    try:
        source = file.read_text()
    except OSError as exc:
        console.print(f"[red]cannot read {file}:[/] {exc}")
        raise typer.Exit(1) from exc
    if bundle is not None:
        files = {
            str(path.relative_to(bundle)): path.read_text(errors="replace")
            for path in sorted(bundle.rglob("*.rego"))
        }
    else:
        files = bundle_files(file)
    translation = importer.plan(source, files)
    plan = importer.plan_json(translation)

    if translation.errors:
        if as_json:
            _emit(plan, True)
        else:
            for error in translation.errors:
                console.print(f"[red]{error}[/]")
            for problem in plan["schema_errors"][:20]:
                console.print(f"  {problem['path']}: {problem['message']}")
        raise typer.Exit(1)

    if not apply_plan:
        if as_json:
            _emit(plan, True)
        else:
            _print_import_plan(plan)
        return

    if not any(doc.rules for doc in translation.documents):
        console.print("[red]Nothing in this policy could be translated; nothing to apply.[/]")
        raise typer.Exit(1)
    if not as_json:
        _print_import_plan(plan)
        if not yes and not typer.confirm("Save the translated policies, in observe?"):
            raise typer.Exit(1)
    with _session() as session:
        result = importer.apply(session, translation, actor="cli")
    if as_json:
        _emit(result, True)
        return
    for saved in result["policies"]:
        console.print(
            f"[green]saved[/] {saved['key']} v{saved['version']} "
            f"({saved['rules']} rules) — live v{saved['live_version']}, {saved['mode']}"
        )
    console.print(
        "  [dim]Simulate before enforcing: `agentfox policy simulate`, then "
        "`agentfox policy enforce KEY`.[/]"
    )


def _print_import_plan(plan: dict) -> None:
    for default in plan["default_action"]:
        if default["unmatched_pass"]:
            console.print(f"[bold yellow]Unmatched calls pass[/] ({default['document']}): ")
            console.print(f"  {default['note']}")
        else:
            console.print(f"[bold]default[/] ({default['document']}): {default['note']}")
    table = Table(box=None, pad_edge=False)
    for column in ("status", "rule", "effect", "why"):
        table.add_column(column, style="bold" if column == "rule" else None)
    for item in plan["items"]:
        why = item["reason"] if item["status"] == "untranslatable" else "; ".join(item["notes"])
        table.add_row(
            _STATUS_MARK[item["status"]],
            item["source"][:60],
            item["effect"] or "—",
            (why or "—")[:240],
        )
    console.print(table)
    summary = plan["summary"]
    console.print(
        f"  {summary['translated']} translated, {summary['translated_with_note']} with a note, "
        f"{summary['untranslatable']} not translated; "
        f"{len(plan['patterns'])} text pattern(s) become custom rules"
    )
    for note in plan["notes"]:
        console.print(f"  [dim]{note}[/]")
    lint = plan["lint"]
    if lint["findings"]:
        _print_lint(lint)
    else:
        console.print("  [green]lint: no policy issues[/]")
