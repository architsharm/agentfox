"""Tamper-evident audit log (NOM-AUD-02).

"Immutable" in most products means "we did not build a DELETE endpoint". That does
not survive an auditor. This is a genuine hash chain:

    payload_digest = SHA-256(canonical_json(payload))
    subject_digest = SHA-256(subject_id or "")
    digest (v2)    = SHA-256(canonical_json(["agentfox.audit.v2", seq, occurred_at,
                             actor_type, actor_id, action, subject_type, subject_digest,
                             payload_digest, prev_digest]))

Every column an entry stores is covered, except its row id and ``org_id`` (the chain is
per tenant, so moving an entry to another chain already breaks both). Entries written
before v2 used ``SHA-256(seq | occurred_at | action | payload_digest | prev_digest)``
(v1), which left who acted and on what outside the digest. They still verify under v1,
but once a chain has a v2 entry no later entry may be v1, so a forger cannot relabel a
new entry as v1 to escape the attribution check.

with periodic checkpoints signed by a key held **outside** the application database,
and a verifier that detects insertion, deletion, reordering and mutation.

Two properties make it credible rather than decorative:

1. :func:`verify` is a **pure function over exported rows**. A third party can run
   it against an evidence package with no access to our systems.
2. There is no update or delete path anywhere in the codebase for ``AuditEntry``.

This is cheap to build correctly at the start and effectively impossible to
retrofit — the entries you already wrote were never chained.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import hmac
import json
from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from typing import Any

from sqlalchemy import func, select, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from agentfox.core.config import get_settings
from agentfox.core.crypto import key_fingerprint
from agentfox.core.models import AuditCheckpoint, AuditEntry, utcnow

#: prev_digest of the first entry. Fixed so an empty chain still verifies.
GENESIS = "0" * 64


def canonical_json(payload: Any) -> str:
    return json.dumps(
        payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str
    )


def sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def compute_payload_digest(payload: dict[str, Any]) -> str:
    return sha256(canonical_json(payload))


#: The digest scheme new entries are written under. See the module docstring.
DIGEST_VERSION = 2
_V2_TAG = "agentfox.audit.v2"


def _iso_utc(occurred_at: dt.datetime) -> str:
    return (
        occurred_at.astimezone(dt.UTC).isoformat()
        if occurred_at.tzinfo
        else occurred_at.isoformat()
    )


def compute_subject_digest(subject_id: str | None) -> str:
    """Stands in for ``subject_id`` in the v2 digest, so a scoped evidence package can
    withhold the id of an out-of-scope subject and the chain still verifies."""
    return sha256(subject_id or "")


def compute_digest(
    seq: int, occurred_at: dt.datetime, action: str, payload_digest: str, prev_digest: str
) -> str:
    """The v1 entry digest. Kept so entries written before v2 still verify."""
    ts = _iso_utc(occurred_at)
    return sha256(f"{seq}|{ts}|{action}|{payload_digest}|{prev_digest}")


def compute_digest_v2(
    seq: int,
    occurred_at: dt.datetime,
    *,
    actor_type: str | None,
    actor_id: str | None,
    action: str,
    subject_type: str | None,
    subject_digest: str,
    payload_digest: str,
    prev_digest: str,
) -> str:
    """The v2 entry digest: v1 plus who acted and on what."""
    return sha256(
        canonical_json(
            [
                _V2_TAG,
                int(seq),
                _iso_utc(occurred_at),
                actor_type or "",
                actor_id or "",
                action,
                subject_type or "",
                subject_digest,
                payload_digest,
                prev_digest,
            ]
        )
    )


# ---------------------------------------------------------------------------
# Redaction at capture
# ---------------------------------------------------------------------------

_SENSITIVE_KEYS = {
    "password",
    "secret",
    "token",
    "api_key",
    "apikey",
    "authorization",
    "key",
    "credential",
    "private_key",
    "access_key",
    "ssn",
}


def redact_payload(payload: Any, depth: int = 0) -> Any:
    """Strip obviously-sensitive values before they reach the chain.

    The audit log must not become the exact PII honeypot customers are afraid of.
    Detectors already store redacted samples with offsets; the
    chain stores structure and decisions, not raw content.
    """
    if depth > 8:
        return "<max-depth>"
    if isinstance(payload, dict):
        out: dict[str, Any] = {}
        for key, value in payload.items():
            if any(marker in str(key).lower() for marker in _SENSITIVE_KEYS):
                out[key] = "<redacted>"
            else:
                out[key] = redact_payload(value, depth + 1)
        return out
    if isinstance(payload, list):
        return [redact_payload(v, depth + 1) for v in payload[:200]]
    if isinstance(payload, str) and len(payload) > 2000:
        return payload[:2000] + f"…<truncated {len(payload) - 2000} chars>"
    return payload


# ---------------------------------------------------------------------------
# Append
# ---------------------------------------------------------------------------


_APPEND_ATTEMPTS = 5


def _lock_chain(session: Session, org_id: str | None) -> None:
    """Hold this chain's append lock until the transaction ends (Postgres only)."""
    bind = session.get_bind()
    if bind.dialect.name != "postgresql":
        return
    key = int.from_bytes(
        hashlib.sha256(f"audit:{org_id}".encode()).digest()[:8], "big", signed=True
    )
    session.execute(text("SELECT pg_advisory_xact_lock(:key)"), {"key": key})


def append(
    session: Session,
    action: str,
    *,
    actor_type: str = "system",
    actor_id: str | None = None,
    subject_type: str = "",
    subject_id: str | None = None,
    payload: dict[str, Any] | None = None,
    occurred_at: dt.datetime | None = None,
    org_id: str | None = None,
) -> AuditEntry:
    """Append one entry. The only write path for :class:`AuditEntry`.

    ``org_id`` names the chain this entry joins explicitly. It defaults to the
    session's own bound tenant (:func:`agentfox.core.tenancy.session_org`) — the ordinary
    case — but is accepted as an override for the one caller that has no ambient
    tenant to inherit: :mod:`agentfox.platform.ledger.system_log`, appending to the reserved
    system-level chain from inside :func:`agentfox.core.tenancy.system_scope`.

    The "last entry" lookup below filters on this org explicitly rather than trusting
    :mod:`agentfox.core.tenancy`'s session-level ``with_loader_criteria`` hook to have done
    it, because that hook is *disabled* for the whole session inside
    ``system_scope`` (by design — reading across every tenant needs an unfiltered
    query). A caller that binds the session to a real tenant and then appends from
    inside ``system_scope`` — exactly what minting an operator token does, since the
    recipient's tenant is only known after a cross-tenant lookup — would otherwise
    have this query see every tenant's rows merged into one sequence instead of just
    its own, computing a ``seq``/``prev_digest`` against whichever tenant's chain
    runs furthest, not the one the entry is actually joining.
    """
    settings = get_settings()
    payload = payload or {}
    if settings.redact_at_capture:
        payload = redact_payload(payload)

    from agentfox.core.tenancy import session_org

    target_org = org_id or session_org(session)

    ts = occurred_at or utcnow()
    payload_digest = compute_payload_digest(payload)

    # Two requests appending at once used to read the same "last entry" and both
    # claim its next `seq`; the second insert failed on the unique (org, seq) index
    # and its whole request returned a 500. On Postgres a transaction-scoped
    # advisory lock per chain serialises appends; elsewhere (SQLite, where the
    # database serialises writers) a collision re-reads the chain and tries again.
    _lock_chain(session, target_org)
    for attempt in range(_APPEND_ATTEMPTS):
        last = session.scalars(
            select(AuditEntry)
            .where(AuditEntry.org_id == target_org)
            .order_by(AuditEntry.seq.desc())
            .limit(1)
        ).first()
        seq = (last.seq + 1) if last else 1
        prev_digest = last.digest if last else GENESIS
        entry = AuditEntry(
            org_id=target_org,
            seq=seq,
            occurred_at=ts,
            actor_type=actor_type,
            actor_id=actor_id,
            action=action,
            subject_type=subject_type,
            subject_id=subject_id,
            payload_json=payload,
            payload_digest=payload_digest,
            prev_digest=prev_digest,
            digest=compute_digest_v2(
                seq,
                ts,
                actor_type=actor_type,
                actor_id=actor_id,
                action=action,
                subject_type=subject_type,
                subject_digest=compute_subject_digest(subject_id),
                payload_digest=payload_digest,
                prev_digest=prev_digest,
            ),
        )
        try:
            with session.begin_nested():
                session.add(entry)
                session.flush()
            break
        except IntegrityError:
            if attempt == _APPEND_ATTEMPTS - 1:
                raise

    if settings.audit_checkpoint_interval and seq % settings.audit_checkpoint_interval == 0:
        write_checkpoint(session, entry)
    return entry


def attribution(*, automated: bool, actor: str | None = None) -> dict[str, str]:
    """``actor_type``/``actor_id`` for an entry, splatted into :func:`append`.

    An automated change is recorded under the improvement loop's own identity and the
    distinct ``automation`` actor type — never as the person or operator who happened
    to trigger it — so the chain can always answer "did a human decide this?". A human
    step must name the human: an anonymous decision is refused rather than defaulted.
    Only attribution; it has no bearing on how an entry is hashed.
    """
    if automated:
        from agentfox.core.vocab import AUTOMATION_ACTOR_TYPE

        return {
            "actor_type": AUTOMATION_ACTOR_TYPE,
            "actor_id": get_settings().improvement_actor_id,
        }
    if not (actor or "").strip():
        raise ValueError("a human step must name the person who took it")
    return {"actor_type": "user", "actor_id": actor.strip()}


# ---------------------------------------------------------------------------
# Checkpoints
# ---------------------------------------------------------------------------


def sign(digest: str, key: str | None = None) -> str:
    """Sign with ``key``, or the current `audit_signing_key`. Never a previous key."""
    key = key or get_settings().audit_signing_key
    return hmac.new(key.encode(), digest.encode(), hashlib.sha256).hexdigest()


def signing_keys() -> list[str]:
    """Every key a checkpoint may verify under: the current one, then each previous
    one (`AGENTFOX_AUDIT_SIGNING_KEY_PREVIOUS`)."""
    settings = get_settings()
    return [settings.audit_signing_key, *settings.audit_signing_previous_keys]


def _as_keys(signing_key: str | Sequence[str] | None) -> list[str]:
    if signing_key is None:
        return signing_keys()
    if isinstance(signing_key, str):
        return [signing_key]
    return [k for k in signing_key if k]


def checkpoint_signer(checkpoint: dict[str, Any], keys: Sequence[str]) -> str | None:
    """The key in ``keys`` that produced this checkpoint's signature, or ``None``.

    The checkpoint's ``key_id`` (a :func:`~agentfox.core.crypto.key_fingerprint`) is
    only a hint for which key to try first — it is not signed, so it decides nothing.
    """
    hint = str(checkpoint.get("key_id") or "")
    ordered = sorted(keys, key=lambda k: key_fingerprint(k) != hint)
    given = str(checkpoint.get("signature", ""))
    for key in ordered:
        if hmac.compare_digest(sign(checkpoint["digest"], key), given):
            return key
    return None


def write_checkpoint(
    session: Session, entry: AuditEntry, key_id: str | None = None
) -> AuditCheckpoint:
    """Sign ``entry``'s digest with the current key. ``key_id`` defaults to that key's
    fingerprint, so a verifier knows which configured key to check it against."""
    key = get_settings().audit_signing_key
    checkpoint = AuditCheckpoint(
        # The entry's chain, explicitly: inside `system_scope` the session's bound
        # tenant may be a different one, and the stamp on flush would use that.
        org_id=entry.org_id,
        seq=entry.seq,
        digest=entry.digest,
        signature=sign(entry.digest, key),
        key_id=key_id or key_fingerprint(key),
    )
    session.add(checkpoint)
    session.flush()
    return checkpoint


def checkpoint_now(session: Session) -> AuditCheckpoint | None:
    last = session.scalars(select(AuditEntry).order_by(AuditEntry.seq.desc()).limit(1)).first()
    return write_checkpoint(session, last) if last else None


# ---------------------------------------------------------------------------
# Verification — a pure function over rows
# ---------------------------------------------------------------------------


@dataclass
class ChainBreak:
    seq: int
    # gap | prev_mismatch | digest_mismatch | payload_mismatch | subject_mismatch |
    # version_downgrade
    kind: str
    detail: str

    def to_json(self) -> dict[str, Any]:
        return {"seq": self.seq, "kind": self.kind, "detail": self.detail}


@dataclass
class VerificationResult:
    valid: bool = True
    entries_checked: int = 0
    first_seq: int | None = None
    last_seq: int | None = None
    breaks: list[ChainBreak] = field(default_factory=list)
    checkpoints_checked: int = 0
    checkpoint_failures: list[dict[str, Any]] = field(default_factory=list)

    @property
    def first_break(self) -> ChainBreak | None:
        return self.breaks[0] if self.breaks else None

    def to_json(self) -> dict[str, Any]:
        return {
            "valid": self.valid,
            "entries_checked": self.entries_checked,
            "first_seq": self.first_seq,
            "last_seq": self.last_seq,
            "breaks": [b.to_json() for b in self.breaks],
            "first_break": self.first_break.to_json() if self.first_break else None,
            "checkpoints_checked": self.checkpoints_checked,
            "checkpoint_failures": self.checkpoint_failures,
        }


def _row_digest(row: dict[str, Any], version: int) -> str:
    occurred = dt.datetime.fromisoformat(row["occurred_at"])
    if version >= 2:
        return compute_digest_v2(
            int(row["seq"]),
            occurred,
            actor_type=row.get("actor_type"),
            actor_id=row.get("actor_id"),
            action=row["action"],
            subject_type=row.get("subject_type"),
            subject_digest=str(row.get("subject_digest") or ""),
            payload_digest=row["payload_digest"],
            prev_digest=row["prev_digest"],
        )
    return compute_digest(
        int(row["seq"]), occurred, row["action"], row["payload_digest"], row["prev_digest"]
    )


def entry_to_row(entry: AuditEntry) -> dict[str, Any]:
    """Serialise an entry to the exact shape :func:`verify` consumes.

    ``digest_version`` is read off the stored digest (the scheme is not a column):
    whichever scheme reproduces it. A row that matches neither is exported as v2, so
    it fails verification rather than being excused as a legacy entry.
    """
    occurred = entry.occurred_at
    if occurred.tzinfo is None:
        occurred = occurred.replace(tzinfo=dt.UTC)
    row: dict[str, Any] = {
        "seq": entry.seq,
        "occurred_at": occurred.isoformat(),
        "actor_type": entry.actor_type,
        "actor_id": entry.actor_id,
        "action": entry.action,
        "subject_type": entry.subject_type,
        "subject_id": entry.subject_id,
        "subject_digest": compute_subject_digest(entry.subject_id),
        "payload": entry.payload_json,
        "payload_digest": entry.payload_digest,
        "prev_digest": entry.prev_digest,
        "digest": entry.digest,
    }
    legacy = _row_digest(row, 1) == entry.digest
    row["digest_version"] = 1 if legacy else DIGEST_VERSION
    return row


def verify(
    rows: Iterable[dict[str, Any]],
    checkpoints: Iterable[dict[str, Any]] | None = None,
    signing_key: str | Sequence[str] | None = None,
    expect_genesis: bool = True,
) -> VerificationResult:
    """Verify an exported chain. No database access, no shared state.

    ``signing_key`` is one key or several: a checkpoint is genuine if it verifies
    under any of them, which is what lets a chain that spans a key rotation verify.
    ``None`` means the configured keys (current, then previous).

    Detects:
      * **mutation**  — recomputed payload/entry digest differs (v2 entries: including
        actor and subject)
      * **downgrade** — a v1 entry after a v2 one
      * **deletion**  — a gap in ``seq``
      * **insertion** — ``prev_digest`` does not match the preceding entry
      * **reordering** — sequence numbers out of order
      * **checkpoint forgery** — signature or anchored digest mismatch
    """
    result = VerificationResult()
    ordered = sorted(rows, key=lambda r: int(r["seq"]))
    if not ordered:
        return result

    result.first_seq = int(ordered[0]["seq"])
    result.last_seq = int(ordered[-1]["seq"])
    prev_digest = GENESIS if (expect_genesis and result.first_seq == 1) else None
    expected_seq = result.first_seq
    seen_v2 = False

    for row in ordered:
        seq = int(row["seq"])
        result.entries_checked += 1

        if seq != expected_seq:
            result.breaks.append(
                ChainBreak(
                    seq, "gap", f"expected seq {expected_seq}, found {seq} — entries deleted"
                )
            )
            expected_seq = seq
        expected_seq += 1

        # A scoped evidence package withholds the payload of entries about agents
        # outside its scope. The entry digest still covers the payload digest, so
        # the chain linkage is verified; only the payload itself cannot be.
        recomputed_payload = (
            row["payload_digest"]
            if row.get("payload_withheld") and row.get("payload") is None
            else compute_payload_digest(row.get("payload") or {})
        )
        if recomputed_payload != row["payload_digest"]:
            result.breaks.append(
                ChainBreak(seq, "payload_mismatch", "payload does not match its recorded digest")
            )

        # v2 covers who acted and on what. A withheld subject ships only its digest;
        # otherwise the digest is re-derived from the id, so editing the id is caught.
        version = int(row.get("digest_version") or 1)
        if version >= 2:
            if row.get("subject_id") is None and row.get("payload_withheld"):
                subject_digest = str(row.get("subject_digest") or "")
            else:
                subject_digest = compute_subject_digest(row.get("subject_id"))
                if row.get("subject_digest") not in (None, subject_digest):
                    result.breaks.append(
                        ChainBreak(
                            seq, "subject_mismatch", "subject does not match its recorded digest"
                        )
                    )
            row = {**row, "subject_digest": subject_digest}
            seen_v2 = True
        elif seen_v2:
            result.breaks.append(
                ChainBreak(
                    seq,
                    "version_downgrade",
                    "a v1 entry after a v2 entry — an entry relabelled to skip the actor check",
                )
            )

        if _row_digest(row, version) != row["digest"]:
            result.breaks.append(
                ChainBreak(seq, "digest_mismatch", "entry digest does not match its contents")
            )

        if prev_digest is not None and row["prev_digest"] != prev_digest:
            result.breaks.append(
                ChainBreak(
                    seq,
                    "prev_mismatch",
                    "prev_digest does not match the preceding entry — insertion or reordering",
                )
            )
        prev_digest = row["digest"]

    by_seq = {int(r["seq"]): r for r in ordered}
    keys = _as_keys(signing_key)
    for checkpoint in checkpoints or []:
        result.checkpoints_checked += 1
        seq = int(checkpoint["seq"])
        if checkpoint_signer(checkpoint, keys) is None:
            result.checkpoint_failures.append(
                {"seq": seq, "reason": "signature mismatch — checkpoint forged or key changed"}
            )
            continue
        anchored = by_seq.get(seq)
        if anchored is None and result.last_seq is not None and seq > result.last_seq:
            result.checkpoint_failures.append(
                {
                    "seq": seq,
                    "reason": "a signed checkpoint names an entry past the end — entries removed",
                }
            )
        elif anchored and anchored["digest"] != checkpoint["digest"]:
            result.checkpoint_failures.append(
                {
                    "seq": seq,
                    "reason": "entry digest differs from signed checkpoint — history rewritten",
                }
            )

    result.valid = not result.breaks and not result.checkpoint_failures
    return result


def verify_range(
    session: Session, start_seq: int | None = None, end_seq: int | None = None
) -> VerificationResult:
    query = select(AuditEntry).order_by(AuditEntry.seq)
    if start_seq is not None:
        query = query.where(AuditEntry.seq >= start_seq)
    if end_seq is not None:
        query = query.where(AuditEntry.seq <= end_seq)
    entries = list(session.scalars(query))

    cp_query = select(AuditCheckpoint).order_by(AuditCheckpoint.seq)
    if start_seq is not None:
        cp_query = cp_query.where(AuditCheckpoint.seq >= start_seq)
    if end_seq is not None:
        cp_query = cp_query.where(AuditCheckpoint.seq <= end_seq)
    checkpoints = [
        {"seq": c.seq, "digest": c.digest, "signature": c.signature, "key_id": c.key_id}
        for c in session.scalars(cp_query)
    ]

    return verify(
        [entry_to_row(e) for e in entries],
        checkpoints,
        expect_genesis=start_seq in (None, 1),
    )


def chain_stats(session: Session) -> dict[str, Any]:
    total = session.scalar(select(func.count()).select_from(AuditEntry)) or 0
    last = session.scalars(select(AuditEntry).order_by(AuditEntry.seq.desc()).limit(1)).first()
    checkpoints = session.scalar(select(func.count()).select_from(AuditCheckpoint)) or 0
    return {
        "entries": total,
        "head_seq": last.seq if last else 0,
        "head_digest": last.digest if last else GENESIS,
        "checkpoints": checkpoints,
    }
